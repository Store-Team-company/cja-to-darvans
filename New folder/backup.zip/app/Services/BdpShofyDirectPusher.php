<?php

namespace App\Services;

use App\Services\BalencoDataPilot\ShofyImageUploadBridgeClient;
use App\Models\BdpProduct;
use App\Models\BdpProductVariation;
use App\Models\BdpCategoryMapping;
use App\Models\BdpSetting;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

class BdpShofyDirectPusher
{
    private string $connection = 'shofy';
    private array $columnsCache = [];
    private string $syncStatus = 'draft';
    private bool $copyVariationImages = true;
    private array $localizedImageCache = [];
    private array $imageCopyNotes = [];

    public function push(array $productIds, array $options = []): array
    {
        $this->syncStatus = in_array(($options['sync_status'] ?? config('balenco-data-pilot.sync_default_status', 'draft')), ['draft', 'published'], true)
            ? (string) ($options['sync_status'] ?? config('balenco-data-pilot.sync_default_status', 'draft'))
            : 'draft';
        $this->copyVariationImages = array_key_exists('copy_variation_images', $options)
            ? (bool) $options['copy_variation_images']
            : (bool) config('balenco-data-pilot.copy_variation_images_to_shofy', true);

        $this->imageCopyNotes = [];

        $this->configureConnection();
        $this->assertConnectionReady();

        $products = BdpProduct::with('variations')
            ->whereIn('id', $productIds)
            ->get();

        $summary = [
            'products' => 0,
            'variations' => 0,
            'errors' => [],
        ];

        foreach ($products as $product) {
            try {
                $result = DB::connection($this->connection)->transaction(function () use ($product) {
                    return $this->pushOne($product);
                });

                $product->forceFill([
                    'shofy_product_id' => $result['product_id'],
                    'shofy_pushed_at' => now(),
                    'shofy_variations_count' => $result['variations'],
                    'shofy_push_note' => trim(sprintf(
                        'Synced %d variations to Balenco as %s. Parent images/gallery were not pushed; variation images %s. %s',
                        $result['variations'],
                        $this->syncStatus,
                        $this->copyVariationImages ? 'were copied locally by color where possible' : 'used source URLs by color',
                        $this->imageCopyNotes ? ('Image copy notes: ' . implode(' | ', array_slice($this->imageCopyNotes, 0, 6))) : ''
                    )),
                    'balenco_sync_status' => $product->shofy_product_id ? 'updated_in_balenco' : 'synced_to_balenco',
                    'balenco_synced_at' => now(),
                    'balenco_sync_message' => sprintf('Product ID %d synced with %d variations.', $result['product_id'], $result['variations']),
                ])->save();

                $summary['products']++;
                $summary['variations'] += $result['variations'];
            } catch (Throwable $e) {
                $product->forceFill([
                    'balenco_sync_status' => 'sync_failed',
                    'balenco_sync_message' => $e->getMessage(),
                ])->save();

                $summary['errors'][] = $product->name . ': ' . $e->getMessage();
            }
        }

        return $summary;
    }

    private function pushOne(BdpProduct $product): array
    {
        $variations = $product->variations;
        if ($variations->isEmpty()) {
            throw new RuntimeException('No variations found for this product.');
        }

        $parentId = $this->findExistingParentId($product);
        $parentData = $this->parentPayload($product, $variations);

        if ($parentId) {
            // Never overwrite parent product/gallery images during update.
            // Balenco workflow: parent images are manually optimized and uploaded in Shofy.
            $updatePayload = $parentData;
            unset($updatePayload['image'], $updatePayload['images']);

            DB::connection($this->connection)->table('ec_products')->where('id', $parentId)->update($this->filterColumns('ec_products', $updatePayload));
            $this->deleteExistingVariations($parentId);
        } else {
            $parentId = DB::connection($this->connection)->table('ec_products')->insertGetId($this->filterColumns('ec_products', $parentData));
        }

        $this->syncSlug($parentId, $product);
        $this->syncAttributeSets($parentId);
        $this->syncCategories($parentId, $product);
        $this->syncTags($parentId, $product);

        // Clean any stale SEO meta before recreating variations. We will add SEO only to parent after variations are done.
        $this->cleanupSeoMetaForProductTree($parentId);

        // Build one image per color. Shoes should change images by color, not by size.
        // Example: Green / US 6, Green / US 7, Green / US 8 all reuse the same green image path.
        $colorImageMap = $this->colorImageMap($variations, $product);

        $defaultSet = false;
        $count = 0;

        foreach ($variations as $variation) {
            $colorAttributeId = $this->attributeId((string) $variation->color, (int) config('balenco-data-pilot.shofy_color_attribute_set_id'), 'color');
            $sizeLabel = $variation->size_us ?: $variation->size_raw;
            $sizeAttributeId = $this->attributeId((string) $sizeLabel, (int) config('balenco-data-pilot.shofy_size_attribute_set_id'), 'size');

            $variationImage = $colorImageMap[$this->colorKey((string) $variation->color)]
                ?? $variation->image
                ?? null;

            $variationProductId = DB::connection($this->connection)->table('ec_products')->insertGetId(
                $this->filterColumns('ec_products', $this->variationProductPayload($product, $variation, ++$count, $variationImage))
            );

            $variationLinkId = DB::connection($this->connection)->table('ec_product_variations')->insertGetId([
                'product_id' => $variationProductId,
                'configurable_product_id' => $parentId,
                'is_default' => (!$defaultSet && ($variation->is_default || $count === 1)) ? 1 : 0,
            ]);

            if (!$defaultSet && ($variation->is_default || $count === 1)) {
                $defaultSet = true;
            }

            DB::connection($this->connection)->table('ec_product_variation_items')->insert([
                ['attribute_id' => $colorAttributeId, 'variation_id' => $variationLinkId],
                ['attribute_id' => $sizeAttributeId, 'variation_id' => $variationLinkId],
            ]);
        }

        // SEO metadata belongs only to the configurable parent product, never to variation products.
        $this->syncSeoMeta($parentId, $product);

        return ['product_id' => $parentId, 'variations' => $count];
    }

    private function parentPayload(BdpProduct $product, $variations): array
    {
        $now = now();
        $minPrice = $variations->whereNotNull('price')->min('price') ?: $product->price ?: 0;
        $minSalePrice = $variations->whereNotNull('sale_price')->min('sale_price') ?: $product->sale_price;
        $qty = (int) ($variations->sum('quantity') ?: $product->quantity ?: config('balenco-data-pilot.default_variation_quantity', 100));
        // Parent images are intentionally not pushed from WooCommerce/CJA.
        // Upload the final 5-6 optimized product/gallery images manually in Shofy.
        $images = [];

        return [
            'name' => $product->name,
            'description' => $product->short_description ?: '',
            'content' => $product->content ?: $product->description ?: '',
            'status' => $this->syncStatus ?: ($product->status ?: 'draft'),
            'images' => json_encode($images),
            'sku' => $product->sku ?: '',
            'order' => 1,
            'quantity' => $qty,
            'allow_checkout_when_out_of_stock' => 0,
            'with_storehouse_management' => 1,
            'stock_status' => $product->stock_status ?: 'in_stock',
            'is_featured' => $product->is_featured ? 1 : 0,
            'brand_id' => 0,
            'is_variation' => 0,
            'sale_type' => 0,
            'price' => $minPrice,
            'sale_price' => $minSalePrice ?: null,
            'views' => 0,
            'created_at' => $now,
            'updated_at' => $now,
            'store_id' => null,
            'created_by_id' => (int) config('balenco-data-pilot.shofy_created_by_id', 1),
            'created_by_type' => config('balenco-data-pilot.shofy_created_by_type', 'Botble\\ACL\\Models\\User'),
            'approved_by' => 0,
            'image' => null,
            'product_type' => 'physical',
            'barcode' => '',
            'cost_per_item' => $product->cost_per_item ?: null,
            'generate_license_code' => 0,
            'license_code_type' => 'auto_generate',
            'minimum_order_quantity' => 0,
            'maximum_order_quantity' => 0,
            'notify_attachment_updated' => 0,
            'specification_table_id' => null,
        ];
    }

    private function variationProductPayload(BdpProduct $product, BdpProductVariation $variation, int $order, ?string $variationImage = null): array
    {
        $now = now();
        $variationImage = $variationImage ?: $variation->image ?: null;
        // Variation gallery should not inherit parent product gallery images.
        // One color image is enough and is reused for all sizes of that color.
        $gallery = $variationImage ? [$variationImage] : [];

        return [
            'name' => $product->name,
            'description' => '',
            'content' => '',
            'status' => $this->syncStatus ?: 'draft',
            'images' => json_encode($gallery),
            'sku' => $product->sku ?: $variation->sku ?: '',
            'order' => $order,
            'quantity' => (int) ($variation->quantity ?: config('balenco-data-pilot.default_variation_quantity', 100)),
            'allow_checkout_when_out_of_stock' => 0,
            'with_storehouse_management' => 1,
            'stock_status' => $variation->stock_status ?: 'in_stock',
            'is_featured' => 0,
            'brand_id' => 0,
            'is_variation' => 1,
            'sale_type' => 0,
            'price' => $variation->price ?: $product->price ?: 0,
            'sale_price' => $variation->sale_price ?: null,
            'views' => 0,
            'created_at' => $now,
            'updated_at' => $now,
            'store_id' => null,
            'created_by_id' => (int) config('balenco-data-pilot.shofy_created_by_id', 1),
            'created_by_type' => config('balenco-data-pilot.shofy_created_by_type', 'Botble\\ACL\\Models\\User'),
            'approved_by' => 0,
            'image' => $variationImage,
            'product_type' => 'physical',
            'barcode' => $variation->barcode ?: '',
            'cost_per_item' => $variation->cost_per_item ?: null,
            'generate_license_code' => 0,
            'license_code_type' => 'auto_generate',
            'minimum_order_quantity' => 0,
            'maximum_order_quantity' => 0,
            'notify_attachment_updated' => 0,
            'specification_table_id' => null,
        ];
    }


    private function colorImageMap($variations, BdpProduct $product): array
    {
        $map = [];

        foreach ($variations as $variation) {
            $key = $this->colorKey((string) $variation->color);
            if ($key === '') {
                continue;
            }

            $image = trim((string) $variation->image);
            if ($image === '') {
                continue;
            }

            // Keep the first image found for each color and reuse it for all sizes of that color.
            if (!isset($map[$key])) {
                $map[$key] = $this->copyVariationImages
                    ? $this->localizeVariationImage($image, $product, (string) $variation->color)
                    : $image;
            }
        }

        // Do not fall back to parent featured image. Parent images are managed manually in Shofy.
        return $map;
    }

    private function localizeVariationImage(string $imageUrl, BdpProduct $product, string $color): string
    {
        $imageUrl = trim($imageUrl);
        if ($imageUrl === '') {
            return $imageUrl;
        }

        $cacheKey = md5($imageUrl . '|' . $this->colorKey($color));
        if (isset($this->localizedImageCache[$cacheKey])) {
            return $this->localizedImageCache[$cacheKey];
        }

        /**
         * If the value is already a public /storage/... URL from sandbox, old store, or another domain,
         * do not keep that domain. Rebuild the URL on the fixed public image host:
         * https://store.balencousa.com/storage/...
         */
        $existingRelativePath = $this->relativePathFromShofyStorageUrl($imageUrl);
        if ($existingRelativePath !== null) {
            $rewritten = $this->publicVariationStorageUrl($existingRelativePath);
            $this->imageCopyNotes[] = "Rewrote {$color} variation storage URL to {$rewritten}";
            return $this->localizedImageCache[$cacheKey] = $rewritten;
        }

        if (!preg_match('#^https?://#i', $imageUrl)) {
            return $this->localizedImageCache[$cacheKey] = $imageUrl;
        }

        try {
            /**
             * Preferred and required path for CJ/external variation images:
             * store.balencousa.com/data-pilot-image-receiver.php downloads the real image
             * into store.balencousa.com public/storage and returns the public URL.
             */
            if ($this->shofyImageBridgeConfigured()) {
                $bridge = app(ShofyImageUploadBridgeClient::class);
                $result = $bridge->uploadRemoteImage($imageUrl, $product->name ?: $product->slug ?: 'balenco-product', $color);

                if (!empty($result['success'])) {
                    if (!empty($result['url'])) {
                        $publicUrl = $this->normalizeVariationImagePublicUrl((string) $result['url']);
                        $this->imageCopyNotes[] = "Bridge copied {$color} variation image to {$publicUrl}";
                        return $this->localizedImageCache[$cacheKey] = $publicUrl;
                    }

                    if (!empty($result['path'])) {
                        $publicUrl = $this->publicVariationStorageUrl((string) $result['path']);
                        $this->imageCopyNotes[] = "Bridge copied {$color} variation image to {$publicUrl}";
                        return $this->localizedImageCache[$cacheKey] = $publicUrl;
                    }
                }

                $this->imageCopyNotes[] = "Bridge failed for {$color}: " . (($result['message'] ?? null) ?: 'unknown error') . '; kept external image';
                return $this->localizedImageCache[$cacheKey] = $imageUrl;
            }

            /**
             * Keep the old filesystem fallback only for same-server setups.
             * If SHOFY_PUBLIC_STORAGE_PATH is not configured, keep source URL and show note.
             */
            $baseStoragePath = $this->shofyPublicStoragePath();
            if ($baseStoragePath === '') {
                $this->imageCopyNotes[] = "Missing image receiver bridge and SHOFY_PUBLIC_STORAGE_PATH; kept external image for {$color}";
                return $this->localizedImageCache[$cacheKey] = $imageUrl;
            }

            $subdir = trim((string) config('balenco-data-pilot.shofy_variation_image_subdir', 'products'), '/');
            $targetDir = rtrim($baseStoragePath, '/') . '/' . $subdir;
            if (!is_dir($targetDir)) {
                @mkdir($targetDir, 0775, true);
            }
            if (!is_dir($targetDir) || !is_writable($targetDir)) {
                $this->imageCopyNotes[] = "Storage folder not writable ({$targetDir}); kept external image for {$color}";
                return $this->localizedImageCache[$cacheKey] = $imageUrl;
            }

            $response = Http::timeout(35)
                ->retry(2, 500)
                ->withHeaders([
                    'User-Agent' => 'Mozilla/5.0 (compatible; BalencoDataPilot/0.6.3)',
                    'Accept' => 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
                    'Referer' => 'https://cjdropshipping.com/',
                ])
                ->get($imageUrl);

            $body = (string) $response->body();
            if (!$response->successful() || strlen($body) < 100) {
                $this->imageCopyNotes[] = "Download failed for {$color} image (HTTP {$response->status()}); kept external URL";
                return $this->localizedImageCache[$cacheKey] = $imageUrl;
            }

            $contentType = strtolower((string) $response->header('Content-Type', ''));
            if ($contentType && !str_contains($contentType, 'image') && !preg_match('/\.(webp|png|jpg|jpeg)(?:\?|$)/i', $imageUrl)) {
                $this->imageCopyNotes[] = "Downloaded {$color} image did not look like an image ({$contentType}); kept external URL";
                return $this->localizedImageCache[$cacheKey] = $imageUrl;
            }

            $extension = $this->imageExtensionFromContentType($contentType, $imageUrl);
            $filename = Str::slug($product->slug ?: $product->name ?: 'balenco-product')
                . '-' . Str::slug($color ?: 'color')
                . '-' . substr(md5($imageUrl), 0, 10)
                . '.' . $extension;

            $targetFile = $targetDir . '/' . $filename;
            if (!file_exists($targetFile)) {
                $written = @file_put_contents($targetFile, $body);
                if ($written === false || $written < 100) {
                    $this->imageCopyNotes[] = "Could not write {$color} image to {$targetFile}; kept external URL";
                    return $this->localizedImageCache[$cacheKey] = $imageUrl;
                }
                @chmod($targetFile, 0664);
            }

            $relativePath = $subdir . '/' . $filename;
            $publicUrl = $this->publicVariationStorageUrl($relativePath);
            $this->imageCopyNotes[] = "Copied {$color} variation image to {$publicUrl}";
            return $this->localizedImageCache[$cacheKey] = $publicUrl;
        } catch (Throwable $e) {
            $this->imageCopyNotes[] = "Image copy error for {$color}: " . $e->getMessage();
            return $this->localizedImageCache[$cacheKey] = $imageUrl;
        }
    }

    private function normalizeVariationImagePublicUrl(string $url): string
    {
        $relative = $this->relativePathFromShofyStorageUrl($url);
        if ($relative !== null) {
            return $this->publicVariationStorageUrl($relative);
        }

        return trim($url);
    }

    private function publicVariationStorageUrl(string $relativePath): string
    {
        $relativePath = trim($relativePath);
        $relativePath = ltrim($relativePath, '/');

        if (str_starts_with($relativePath, 'storage/')) {
            $relativePath = substr($relativePath, strlen('storage/'));
        }

        $base = trim((string) env('BDP_VARIATION_IMAGE_PUBLIC_BASE_URL', 'https://store.balencousa.com'));
        $base = rtrim($base ?: 'https://store.balencousa.com', '/');

        return $base . '/storage/' . ltrim($relativePath, '/');
    }

    private function relativePathFromShofyStorageUrl(string $url): ?string
    {
        $parts = parse_url($url);
        if (!is_array($parts) || empty($parts['path'])) {
            return null;
        }

        $path = ltrim((string) $parts['path'], '/');
        $needle = 'storage/';
        $pos = strpos($path, $needle);
        if ($pos === false) {
            return null;
        }

        return substr($path, $pos + strlen($needle));
    }

    private function shofyImageBridgeConfigured(): bool
    {
        return trim((string) env('SHOFY_IMAGE_UPLOAD_URL', 'https://store.balencousa.com/data-pilot-image-receiver.php')) !== ''
            && trim((string) env('SHOFY_IMAGE_UPLOAD_TOKEN', '')) !== '';
    }

    private function shofyPublicStoragePath(): string
    {
        $configured = trim((string) config('balenco-data-pilot.shofy_public_storage_path', ''));
        if ($configured !== '') {
            return rtrim($configured, '/');
        }

        $database = trim((string) config('balenco-data-pilot.shofy_db.database', ''));
        if ($database === '') {
            return '';
        }

        // Cloudways usually stores sibling apps under /home/{server}.cloudwaysapps.com/{app}/public_html.
        // Data Pilot is one app and Shofy/Balenco is another, so infer the sibling path from the Shofy DB/app name.
        $cloudwaysRoot = dirname(dirname(base_path()));
        $candidate = $cloudwaysRoot . '/' . $database . '/public_html/public/storage';

        return is_dir(dirname($candidate)) ? $candidate : '';
    }

    private function imageExtensionFromContentType(string $contentType, string $url): string
    {
        if (str_contains($contentType, 'webp')) {
            return 'webp';
        }
        if (str_contains($contentType, 'png')) {
            return 'png';
        }
        if (str_contains($contentType, 'gif')) {
            return 'gif';
        }
        if (preg_match('/\.(webp|png|jpg|jpeg)(?:\?|$)/i', $url, $m)) {
            return strtolower($m[1]) === 'jpeg' ? 'jpg' : strtolower($m[1]);
        }
        return 'jpg';
    }

    private function colorKey(string $color): string
    {
        return strtolower(trim($color));
    }

    private function syncSlug(int $productId, BdpProduct $product): void
    {
        if (!$this->hasTable('slugs')) {
            return;
        }

        $referenceType = $this->productReferenceType();
        $desiredBaseSlug = $product->slug ?: Str::slug($product->name);

        DB::connection($this->connection)->table('slugs')
            ->where('reference_id', $productId)
            ->where('reference_type', $referenceType)
            ->delete();

        // Remove stale slug rows left by previous failed tests for the same product URL.
        DB::connection($this->connection)->table('slugs')
            ->where('key', $desiredBaseSlug)
            ->where('reference_type', $referenceType)
            ->where('reference_id', '!=', $productId)
            ->delete();

        DB::connection($this->connection)->table('slugs')->insert($this->filterColumns('slugs', [
            'key' => $this->uniqueSlug($desiredBaseSlug, $productId),
            'reference_id' => $productId,
            'reference_type' => $referenceType,
            'prefix' => '',
            'created_at' => now(),
            'updated_at' => now(),
        ]));
    }


    private function syncCategories(int $productId, BdpProduct $product): void
    {
        if (!$this->hasTable('ec_product_category_product')) {
            return;
        }

        $sourceCategories = $this->splitCommaValues($product->categories);
        if (!$sourceCategories) {
            return;
        }

        $mappingRows = BdpCategoryMapping::query()
            ->whereIn('source_category', $sourceCategories)
            ->whereNotNull('balenco_category_id')
            ->get()
            ->keyBy(fn ($row) => mb_strtolower($row->source_category));

        $categoryIds = [];
        foreach ($sourceCategories as $sourceCategory) {
            $mapping = $mappingRows->get(mb_strtolower($sourceCategory));
            if ($mapping && $mapping->balenco_category_id) {
                $categoryIds[] = (int) $mapping->balenco_category_id;
            }
        }

        $categoryIds = array_values(array_unique(array_filter($categoryIds)));

        // If no category is mapped, leave existing Balenco categories untouched.
        if (!$categoryIds) {
            return;
        }

        DB::connection($this->connection)->table('ec_product_category_product')
            ->where('product_id', $productId)
            ->delete();

        foreach ($categoryIds as $categoryId) {
            DB::connection($this->connection)->table('ec_product_category_product')->insert([
                'product_id' => $productId,
                'category_id' => $categoryId,
            ]);
        }
    }

    private function syncTags(int $productId, BdpProduct $product): void
    {
        if (!$this->hasTable('ec_product_tags') || !$this->hasTable('ec_product_tag_product')) {
            return;
        }

        $tags = $this->splitCommaValues($product->tags);
        if (!$tags) {
            return;
        }

        DB::connection($this->connection)->table('ec_product_tag_product')
            ->where('product_id', $productId)
            ->delete();

        foreach ($tags as $tagName) {
            $tagId = $this->tagId($tagName);

            DB::connection($this->connection)->table('ec_product_tag_product')->insert(
                $this->filterColumns('ec_product_tag_product', [
                    'product_id' => $productId,
                    'tag_id' => $tagId,
                ])
            );
        }
    }

    private function tagId(string $name): int
    {
        $name = trim($name);
        if ($name === '') {
            $name = 'Product';
        }

        $existing = DB::connection($this->connection)->table('ec_product_tags')
            ->whereRaw('LOWER(name) = ?', [mb_strtolower($name)])
            ->orderBy('id')
            ->first();

        if ($existing) {
            return (int) $existing->id;
        }

        $data = [
            'name' => $name,
            'description' => '',
            'status' => 'published',
            'created_at' => now(),
            'updated_at' => now(),
        ];

        if (\Illuminate\Support\Facades\Schema::connection($this->connection)->hasColumn('ec_product_tags', 'slug')) {
            $data['slug'] = $this->uniqueTagSlug(Str::slug($name));
        }

        return DB::connection($this->connection)->table('ec_product_tags')->insertGetId(
            $this->filterColumns('ec_product_tags', $data)
        );
    }

    private function uniqueTagSlug(string $base): string
    {
        $base = $base ?: 'product-tag';

        if (!\Illuminate\Support\Facades\Schema::connection($this->connection)->hasColumn('ec_product_tags', 'slug')) {
            return $base;
        }

        $slug = $base;
        $i = 1;

        while (DB::connection($this->connection)->table('ec_product_tags')
            ->where('slug', $slug)
            ->exists()) {
            $slug = $base . '-' . $i++;
        }

        return $slug;
    }

    private function splitCommaValues(?string $value): array
    {
        $items = [];
        foreach (explode(',', (string) $value) as $item) {
            $item = trim($item);
            if ($item !== '') {
                $items[mb_strtolower($item)] = $item;
            }
        }

        return array_values($items);
    }

    private function cleanupSeoMetaForProductTree(int $parentId): void
    {
        if (!$this->hasTable('meta_boxes')) {
            return;
        }

        $variationIds = DB::connection($this->connection)->table('ec_product_variations')
            ->where('configurable_product_id', $parentId)
            ->pluck('product_id')
            ->all();

        $ids = array_values(array_filter(array_merge([$parentId], $variationIds)));
        if (!$ids) {
            return;
        }

        // Parent can keep other meta in future; variations should not receive SEO meta from this tool.
        DB::connection($this->connection)->table('meta_boxes')
            ->whereIn('reference_id', $ids)
            ->where('meta_key', 'seo_meta')
            ->delete();
    }

    private function syncSeoMeta(int $productId, BdpProduct $product): void
    {
        if (!$this->hasTable('meta_boxes')) {
            return;
        }

        $referenceType = $this->productReferenceType();
        $seoTitle = trim((string) ($product->seo_title ?: $product->name));
        $seoDescription = trim((string) ($product->seo_description ?: $product->short_description ?: strip_tags((string) ($product->description ?: $product->content))));
        $seoDescription = Str::limit($seoDescription, 170, '');
        // Do not use CJA/Woo parent image as SEO image. Parent/SEO images are managed manually in Shofy.
        $seoImage = '';

        // Do not create an empty SEO row. Botble can safely fall back to product title/content.
        if ($seoTitle === '' && $seoDescription === '' && $seoImage === '') {
            return;
        }

        $payload = [
            'seo_title' => $seoTitle,
            'seo_description' => $seoDescription,
            'seo_image' => $seoImage,
            'index' => 'index',
        ];

        // Replace SEO meta only on the parent product. Never attach SEO meta to variation product rows.
        DB::connection($this->connection)->table('meta_boxes')
            ->where('reference_id', $productId)
            ->where('reference_type', $referenceType)
            ->where('meta_key', 'seo_meta')
            ->delete();

        DB::connection($this->connection)->table('meta_boxes')->insert($this->filterColumns('meta_boxes', [
            'meta_key' => 'seo_meta',
            // Botble MetaBox::getMetaData(..., true) expects meta_value to decode as an array
            // and then reads index [0]. Store the SEO payload wrapped in an array.
            'meta_value' => json_encode([$payload], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'reference_id' => $productId,
            'reference_type' => $referenceType,
            'created_at' => now(),
            'updated_at' => now(),
        ]));
    }

    private function productReferenceType(): string
    {
        return trim((string) config('balenco-data-pilot.shofy_product_model', 'Botble\\Ecommerce\\Models\\Product'));
    }

    private function syncAttributeSets(int $productId): void
    {
        if (!$this->hasTable('ec_product_with_attribute_set')) {
            return;
        }

        $table = 'ec_product_with_attribute_set';
        DB::connection($this->connection)->table($table)->where('product_id', $productId)->delete();

        $colorSet = (int) config('balenco-data-pilot.shofy_color_attribute_set_id', 1);
        $sizeSet = (int) config('balenco-data-pilot.shofy_size_attribute_set_id', 2);

        foreach ([[$colorSet, 0], [$sizeSet, 1]] as [$setId, $order]) {
            DB::connection($this->connection)->table($table)->insert($this->filterColumns($table, [
                'product_id' => $productId,
                'attribute_set_id' => $setId,
                'order' => $order,
            ]));
        }
    }

    private function deleteExistingVariations(int $parentId): void
    {
        $links = DB::connection($this->connection)->table('ec_product_variations')
            ->where('configurable_product_id', $parentId)
            ->get(['id', 'product_id']);

        $variationLinkIds = $links->pluck('id')->all();
        $variationProductIds = $links->pluck('product_id')->all();

        if ($variationLinkIds) {
            DB::connection($this->connection)->table('ec_product_variation_items')->whereIn('variation_id', $variationLinkIds)->delete();
            DB::connection($this->connection)->table('ec_product_variations')->whereIn('id', $variationLinkIds)->delete();
        }

        if ($variationProductIds) {
            // Clean related rows for old variation products before deleting them.
            // This prevents broken/old SEO meta rows from staying attached to deleted variations.
            if ($this->hasTable('meta_boxes')) {
                DB::connection($this->connection)->table('meta_boxes')->whereIn('reference_id', $variationProductIds)->delete();
            }
            if ($this->hasTable('slugs')) {
                DB::connection($this->connection)->table('slugs')->whereIn('reference_id', $variationProductIds)->delete();
            }

            DB::connection($this->connection)->table('ec_products')->whereIn('id', $variationProductIds)->delete();
        }
    }

    private function findExistingParentId(BdpProduct $product): ?int
    {
        if (!empty($product->shofy_product_id)) {
            $exists = DB::connection($this->connection)->table('ec_products')
                ->where('id', $product->shofy_product_id)
                ->where('is_variation', 0)
                ->exists();
            if ($exists) {
                return (int) $product->shofy_product_id;
            }
        }

        if (config('balenco-data-pilot.shofy_update_existing_by_sku', true) && $product->sku) {
            $existing = DB::connection($this->connection)->table('ec_products')
                ->where('sku', $product->sku)
                ->where('is_variation', 0)
                ->orderByDesc('id')
                ->first();
            if ($existing) {
                return (int) $existing->id;
            }
        }

        return null;
    }

    private function attributeId(string $title, int $attributeSetId, string $type): int
    {
        $title = trim($title);
        if ($title === '') {
            $title = $type === 'color' ? 'Default' : 'One Size';
        }

        $existing = DB::connection($this->connection)->table('ec_product_attributes')
            ->where('attribute_set_id', $attributeSetId)
            ->whereRaw('LOWER(title) = ?', [strtolower($title)])
            ->orderBy('id')
            ->first();

        if ($existing) {
            return (int) $existing->id;
        }

        $slug = $this->uniqueAttributeSlug(Str::slug($title), $attributeSetId);
        return DB::connection($this->connection)->table('ec_product_attributes')->insertGetId($this->filterColumns('ec_product_attributes', [
            'attribute_set_id' => $attributeSetId,
            'title' => $title,
            'slug' => $slug,
            'color' => $type === 'color' ? $this->colorHex($title) : null,
            'image' => null,
            'is_default' => 0,
            'order' => 0,
            'created_at' => now(),
            'updated_at' => now(),
        ]));
    }

    private function gallery(?string $csv, ?string $featured = null): array
    {
        $images = [];
        if ($featured) {
            $images[] = trim($featured);
        }
        foreach (explode(',', (string) $csv) as $image) {
            $image = trim($image);
            if ($image !== '') {
                $images[] = $image;
            }
        }
        return array_values(array_unique($images));
    }

    private function uniqueSlug(string $base, ?int $currentProductId = null): string
    {
        $base = $base ?: 'product';
        $slug = $base;
        $i = 1;
        $referenceType = $this->productReferenceType();

        while (DB::connection($this->connection)->table('slugs')
            ->where('key', $slug)
            ->where('reference_type', $referenceType)
            ->when($currentProductId, fn ($q) => $q->where('reference_id', '!=', $currentProductId))
            ->exists()) {
            $slug = $base . '-' . $i++;
        }

        return $slug;
    }

    private function uniqueAttributeSlug(string $base, int $attributeSetId): string
    {
        $base = $base ?: 'attribute';
        $slug = $base;
        $i = 1;
        while (DB::connection($this->connection)->table('ec_product_attributes')
            ->where('attribute_set_id', $attributeSetId)
            ->where('slug', $slug)
            ->exists()) {
            $slug = $base . '-' . $i++;
        }
        return $slug;
    }

    private function colorHex(string $title): ?string
    {
        $map = [
            'black' => '#000000', 'white' => '#FFFFFF', 'beige' => '#D8C3A5', 'nude' => '#E3B7A0',
            'cream' => '#F5F0E6', 'brown' => '#6B3F24', 'blue' => '#1D4ED8', 'navy' => '#1E2A44',
            'red' => '#C1121F', 'pink' => '#FFC0CB', 'gold' => '#D4AF37', 'silver' => '#C0C0C0',
            'green' => '#15803D', 'gray' => '#808080', 'multi color' => '#8B5CF6', 'grey' => '#808080',
        ];
        return $map[strtolower(trim($title))] ?? null;
    }





    // BDP_CONNECTED_STORE_SYNC_BRIDGE_HELPERS_START
    private function bdpSetting(string $key, $default = null)
    {
        try {
            if (class_exists(BdpSetting::class)) {
                $model = BdpSetting::query()->where('key', $key)->first();
                if ($model && $model->value !== null && $model->value !== '') {
                    return $model->value;
                }
            }

            if (Schema::hasTable('bdp_settings')) {
                $value = DB::table('bdp_settings')->where('key', $key)->value('value');
                if ($value !== null && $value !== '') {
                    return $value;
                }
            }
        } catch (Throwable $e) {
            // Fallback to old config if settings cannot be read.
        }

        return $default;
    }

    private function bdpDecryptSettingValue(?string $value): ?string
    {
        if ($value === null || $value === '' || $value === '********') {
            return null;
        }

        try {
            return Crypt::decryptString($value);
        } catch (Throwable $e) {
            return $value;
        }
    }

    private function bdpConnectedStoreDatabaseSettings(): array
    {
        $pick = function (array $keys, $default = null) {
            foreach ($keys as $key) {
                $value = $this->bdpSetting($key);
                if ($value !== null && $value !== '') {
                    return $value;
                }
            }

            return $default;
        };

        return [
            'enabled' => (string) $pick(['connected_store_enabled', 'store_enabled'], '1') !== '0',
            'method' => (string) $pick(['store_push_method', 'push_method', 'connected_store_push_method'], 'database'),
            'host' => trim((string) $pick(['store_db_host', 'connected_store_db_host', 'database_host', 'db_host'], '')),
            'port' => trim((string) $pick(['store_db_port', 'connected_store_db_port', 'database_port', 'db_port'], '3306')),
            'database' => trim((string) $pick(['store_db_database', 'connected_store_db_database', 'connected_store_db_name', 'store_database_name', 'database_name', 'db_database', 'db_name'], '')),
            'username' => trim((string) $pick(['store_db_username', 'connected_store_db_username', 'database_username', 'db_username'], '')),
            'password' => $this->bdpDecryptSettingValue((string) $pick(['store_db_password', 'connected_store_db_password', 'database_password', 'db_password'], '')),
            'prefix' => (string) $pick(['store_db_prefix', 'connected_store_db_prefix', 'database_prefix', 'db_prefix'], ''),
        ];
    }
    // BDP_CONNECTED_STORE_SYNC_BRIDGE_HELPERS_END


    private function configureConnection(): void
    {
        $settings = $this->bdpConnectedStoreDatabaseSettings();

        if ($settings['enabled'] && $settings['method'] === 'database' && $settings['host'] && $settings['database'] && $settings['username'] && $settings['password']) {
            $connectionName = 'bdp_connected_store';

            Config::set("database.connections.{$connectionName}", [
                'driver' => 'mysql',
                'host' => $settings['host'],
                'port' => $settings['port'] ?: 3306,
                'database' => $settings['database'],
                'username' => $settings['username'],
                'password' => $settings['password'],
                'unix_socket' => '',
                'charset' => 'utf8mb4',
                'collation' => 'utf8mb4_unicode_ci',
                'prefix' => $settings['prefix'] ?: '',
                'prefix_indexes' => true,
                'strict' => false,
                'engine' => null,
                'options' => extension_loaded('pdo_mysql') ? array_filter([
                    \PDO::ATTR_TIMEOUT => 20,
                ]) : [],
            ]);

            DB::purge($connectionName);
            DB::reconnect($connectionName);

            $this->connection = $connectionName;

            return;
        }

        if ($settings['enabled'] && $settings['method'] === 'api') {
            throw new RuntimeException('API receiver push is selected in Connected Store settings, but this sync action currently supports direct database push only. Choose Direct database connection or build the API receiver sync service.');
        }

        $database = config('balenco-data-pilot.shofy_db.database') ?: env('SHOFY_DB_DATABASE');
        $username = config('balenco-data-pilot.shofy_db.username') ?: env('SHOFY_DB_USERNAME');
        $password = config('balenco-data-pilot.shofy_db.password') ?: env('SHOFY_DB_PASSWORD');
        $host = config('balenco-data-pilot.shofy_db.host') ?: env('SHOFY_DB_HOST', '127.0.0.1');
        $port = config('balenco-data-pilot.shofy_db.port') ?: env('SHOFY_DB_PORT', 3306);
        $prefix = config('balenco-data-pilot.shofy_db.prefix') ?: env('SHOFY_DB_PREFIX', '');

        if ($database && $username) {
            Config::set('database.connections.shofy', [
                'driver' => 'mysql',
                'host' => $host,
                'port' => $port,
                'database' => $database,
                'username' => $username,
                'password' => $password,
                'unix_socket' => '',
                'charset' => 'utf8mb4',
                'collation' => 'utf8mb4_unicode_ci',
                'prefix' => $prefix,
                'prefix_indexes' => true,
                'strict' => false,
                'engine' => null,
            ]);

            DB::purge('shofy');
            DB::reconnect('shofy');
            $this->connection = 'shofy';
        }
    }





    private function assertConnectionReady(): void
    {
        try {
            DB::connection($this->connection)->getPdo();
        } catch (Throwable $e) {
            throw new RuntimeException('Connected store database connection failed: ' . $e->getMessage());
        }

        if (!$this->hasTable('ec_products') || !$this->hasTable('ec_product_variations') || !$this->hasTable('ec_product_variation_items')) {
            throw new RuntimeException(sprintf(
                'Connected store database is reachable, but required Botble ecommerce tables were not found on connection [%s]. Required: ec_products, ec_product_variations, ec_product_variation_items. Check database name or table prefix.',
                $this->connection
            ));
        }
    }



    private function hasTable(string $table): bool
    {
        try {
            return Schema::connection($this->connection)->hasTable($table);
        } catch (Throwable) {
            return false;
        }
    }

    private function filterColumns(string $table, array $payload): array
    {
        $columns = $this->columns($table);
        return array_intersect_key($payload, array_flip($columns));
    }

    private function columns(string $table): array
    {
        if (!isset($this->columnsCache[$table])) {
            $this->columnsCache[$table] = Schema::connection($this->connection)->getColumnListing($table);
        }
        return $this->columnsCache[$table];
    }
}
