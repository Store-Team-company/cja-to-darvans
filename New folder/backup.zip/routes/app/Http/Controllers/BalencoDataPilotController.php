<?php

namespace App\Http\Controllers;

use App\Models\BdpProduct;
use App\Models\BdpProductVariation;
use App\Models\BdpCategoryMapping;
use App\Models\BdpApiLog;
use App\Services\BdpShofyExporter;
use App\Services\BdpShofyDirectPusher;
use App\Services\BdpWooCsvImporter;
use App\Services\BdpCjaImporter;
use App\Services\BdpShofyCategoryService;
use App\Services\BdpCjApiService;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class BalencoDataPilotController extends Controller
{

    public function loginForm()
    {
        if (session('bdp_logged_in')) {
            return redirect()->route('bdp.index');
        }

        return view('balenco-data-pilot.login');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'username' => ['required', 'string'],
            'password' => ['required', 'string'],
        ]);

        $expectedUsername = config('balenco-data-pilot.login_username', env('BDP_LOGIN_USERNAME', 'admin'));
        $expectedPassword = config('balenco-data-pilot.login_password', env('BDP_LOGIN_PASSWORD', 'change-this-password'));

        if ($credentials['username'] === $expectedUsername && hash_equals((string) $expectedPassword, (string) $credentials['password'])) {
            $request->session()->regenerate();
            session(['bdp_logged_in' => true]);

            return redirect()->route('bdp.index');
        }

        return back()->with('error', 'Invalid username or password.')->onlyInput('username');
    }

    public function logout(Request $request)
    {
        $request->session()->forget('bdp_logged_in');
        $request->session()->regenerateToken();

        return redirect()->route('bdp.login.form')->with('success', 'Logged out successfully.');
    }
    public function index(Request $request)
    {
        $stats = $this->dashboardStats();

        $recentProducts = BdpProduct::withCount('variations')
            ->withSum('variations as variations_total_quantity', 'quantity')
            ->latest()
            ->limit(5)
            ->get();

        $recentLogs = BdpApiLog::latest()->limit(5)->get();

        $mappedCategories = BdpCategoryMapping::whereNotNull('balenco_category_id')->count();
        $pendingCategories = BdpCategoryMapping::whereNull('balenco_category_id')->count();

        $pricingSummary = [
            'Destination Country' => 'United States (US)',
            'Margin Type' => 'Fixed amount',
            'Margin Value' => '$20.00',
            'Minimum Selling Price' => '$39.99',
            'Retail Rounding' => 'Round up to .99',
        ];

        return view('balenco-data-pilot.dashboard', compact(
            'stats',
            'recentProducts',
            'recentLogs',
            'mappedCategories',
            'pendingCategories',
            'pricingSummary'
        ));
    }

    public function products(Request $request)
    {
        $sync = $request->query('sync', 'all');

        $query = BdpProduct::withCount('variations')
            ->withMin('variations as min_variation_price', 'price')
            ->withMin('variations as min_variation_cost', 'cost_per_item')
            ->withSum('variations as variations_total_quantity', 'quantity')
            ->latest();

        if ($sync === 'synced') {
            $query->whereNotNull('shofy_product_id');
        } elseif ($sync === 'not_synced') {
            $query->whereNull('shofy_product_id');
        } elseif ($sync === 'failed') {
            $query->where('balenco_sync_status', 'sync_failed');
        } elseif ($sync === 'needs_review') {
            $query->where(function ($q) {
                $q->whereNull('sku')
                  ->orWhere('sku', '')
                  ->orWhereNull('price')
                  ->orWhereDoesntHave('variations');
            });
        }

        $products = $query->paginate(25)->withQueryString();
        $counts = $this->dashboardStats();

        return view('balenco-data-pilot.products', compact('products', 'sync', 'counts'));
    }

    protected function dashboardStats(): array
    {
        $needsReview = BdpProduct::where(function ($q) {
            $q->whereNull('sku')
              ->orWhere('sku', '')
              ->orWhereNull('price')
              ->orWhereDoesntHave('variations');
        })->count();

        return [
            'all' => BdpProduct::count(),
            'synced' => BdpProduct::whereNotNull('shofy_product_id')->count(),
            'not_synced' => BdpProduct::whereNull('shofy_product_id')->count(),
            'failed' => BdpProduct::where('balenco_sync_status', 'sync_failed')->count(),
            'needs_review' => $needsReview,
            'variations' => BdpProductVariation::count(),
            'low_stock' => BdpProductVariation::whereNotNull('quantity')->where('quantity', '<=', 5)->count(),
            'draft' => BdpProduct::where('status', 'draft')->count(),
            'published' => BdpProduct::where('status', 'published')->count(),
        ];
    }


    public function categoryMapping(BdpShofyCategoryService $categoryService)
    {
        try {
            $sourceCategories = $categoryService->sourceCategories();
            $balencoCategories = $categoryService->balencoCategories();
            $mappings = BdpCategoryMapping::query()->get()->keyBy(fn ($item) => mb_strtolower($item->source_category));

            return view('balenco-data-pilot.category-mapping', compact('sourceCategories', 'balencoCategories', 'mappings'));
        } catch (\Throwable $e) {
            return redirect()->route('bdp.index')->with('error', 'Category mapping error: ' . $e->getMessage());
        }
    }

    public function saveCategoryMapping(Request $request)
    {
        $data = $request->validate([
            'mappings' => ['nullable', 'array'],
            'category_names' => ['nullable', 'array'],
        ]);

        $saved = 0;
        foreach (($data['mappings'] ?? []) as $sourceCategory => $balencoCategoryId) {
            $sourceCategory = trim((string) $sourceCategory);
            if ($sourceCategory === '') {
                continue;
            }

            $balencoCategoryId = $balencoCategoryId !== '' ? (int) $balencoCategoryId : null;
            $balencoCategoryName = null;

            if ($balencoCategoryId) {
                $balencoCategoryName = $data['category_names'][$balencoCategoryId] ?? null;
            }

            BdpCategoryMapping::updateOrCreate(
                ['source_category' => $sourceCategory],
                [
                    'balenco_category_id' => $balencoCategoryId,
                    'balenco_category_name' => $balencoCategoryName,
                ]
            );
            $saved++;
        }

        return redirect()->route('bdp.categories.mapping')->with('success', "Saved {$saved} category mappings.");
    }

    public function bulkAssignCategory(Request $request)
    {
        $data = $request->validate([
            'products' => ['required', 'array'],
            'products.*' => ['integer'],
            'category' => ['required', 'string', 'max:255'],
            'mode' => ['nullable', Rule::in(['replace', 'append'])],
        ]);

        $products = BdpProduct::whereIn('id', $data['products'])->get();
        $updated = 0;
        foreach ($products as $product) {
            $product->categories = ($data['mode'] ?? 'replace') === 'append'
                ? $this->mergeCommaValues($product->categories, $data['category'])
                : $data['category'];
            $product->save();
            $updated++;
        }

        return back()->with('success', "Assigned category to {$updated} products.");
    }

    public function importForm()
    {
        return view('balenco-data-pilot.import');
    }

    public function import(Request $request, BdpWooCsvImporter $wooImporter, BdpCjaImporter $cjaImporter)
    {
        $data = $request->validate([
            'source' => ['required', Rule::in(['woocommerce', 'cja'])],
            'file' => ['required', 'file', 'mimes:csv,txt,xlsx,xlsm'],
        ]);

        $importer = $data['source'] === 'cja' ? $cjaImporter : $wooImporter;
        $result = $importer->import($request->file('file'));

        $sourceLabel = $data['source'] === 'cja' ? 'CJA' : 'WooCommerce';

        return redirect()->route('bdp.index')->with('success', "Imported {$result['products']} {$sourceLabel} products and {$result['variations']} variations.");
    }

    public function edit(BdpProduct $product)
    {
        $product->load('variations');
        return view('balenco-data-pilot.edit', compact('product'));
    }

    public function update(Request $request, BdpProduct $product)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'slug' => ['nullable', 'string', 'max:255'],
            'sku' => ['nullable', 'string', 'max:255'],
            'short_description' => ['nullable', 'string'],
            'content' => ['nullable', 'string'],
            'price' => ['nullable', 'numeric'],
            'sale_price' => ['nullable', 'numeric'],
            'categories' => ['nullable', 'string'],
            'tags' => ['nullable', 'string'],
            'seo_title' => ['nullable', 'string', 'max:255'],
            'seo_description' => ['nullable', 'string'],
            'focus_keyword' => ['nullable', 'string', 'max:255'],
            'featured_image' => ['nullable', 'string'],
            'gallery_images' => ['nullable', 'string'],
        ]);

        $data['slug'] = $data['slug'] ?: Str::slug($data['name']);
        $product->update($data);

        foreach ($request->input('variations', []) as $id => $variationData) {
            BdpProductVariation::where('bdp_product_id', $product->id)->where('id', $id)->update([
                'color' => $variationData['color'] ?? null,
                'size_raw' => $variationData['size_raw'] ?? null,
                'size_us' => $variationData['size_us'] ?? null,
                'price' => $variationData['price'] ?? null,
                'sale_price' => $variationData['sale_price'] ?? null,
                'quantity' => $variationData['quantity'] ?? null,
                'stock_status' => $variationData['stock_status'] ?? 'in_stock',
                'image' => $variationData['image'] ?? null,
                'is_default' => !empty($variationData['is_default']),
            ]);
        }

        return back()->with('success', 'Product updated.');
    }


    public function bulkEdit(Request $request)
    {
        $ids = array_filter((array) $request->input('products', []));
        if (empty($ids)) {
            return back()->with('error', 'Please select at least one product for bulk edit.');
        }

        $products = BdpProduct::whereIn('id', $ids)
            ->withCount('variations')
            ->orderBy('name')
            ->get();

        return view('balenco-data-pilot.bulk-edit', compact('products', 'ids'));
    }

    public function bulkUpdate(Request $request)
    {
        $data = $request->validate([
            'products' => ['required', 'array'],
            'products.*' => ['integer'],
            'category_action' => ['nullable', Rule::in(['ignore', 'replace', 'append'])],
            'categories' => ['nullable', 'string'],
            'tags_action' => ['nullable', Rule::in(['ignore', 'replace', 'append'])],
            'tags' => ['nullable', 'string'],
            'focus_keyword_action' => ['nullable', Rule::in(['ignore', 'replace'])],
            'focus_keyword' => ['nullable', 'string', 'max:255'],
            'seo_title_template' => ['nullable', 'string', 'max:255'],
            'seo_description_template' => ['nullable', 'string'],
            'short_description_template' => ['nullable', 'string'],
            'content_prefix_template' => ['nullable', 'string'],
            'content_suffix_template' => ['nullable', 'string'],
        ]);

        $ids = array_filter((array) ($data['products'] ?? []));
        $products = BdpProduct::whereIn('id', $ids)->get();
        $updated = 0;

        foreach ($products as $product) {
            $update = [];
            $tokens = $this->bulkTemplateTokens($product);

            if (!empty($data['seo_title_template'])) {
                $update['seo_title'] = Str::limit($this->applyBulkTemplate($data['seo_title_template'], $tokens), 255, '');
            }

            if (!empty($data['seo_description_template'])) {
                $update['seo_description'] = $this->applyBulkTemplate($data['seo_description_template'], $tokens);
            }

            if (!empty($data['short_description_template'])) {
                $update['short_description'] = $this->applyBulkTemplate($data['short_description_template'], $tokens);
            }

            if (!empty($data['content_prefix_template'])) {
                $prefix = $this->applyBulkTemplate($data['content_prefix_template'], $tokens);
                $update['content'] = $prefix . "\n" . (string) $product->content;
            }

            if (!empty($data['content_suffix_template'])) {
                $suffix = $this->applyBulkTemplate($data['content_suffix_template'], $tokens);
                $update['content'] = (array_key_exists('content', $update) ? $update['content'] : (string) $product->content) . "\n" . $suffix;
            }

            $categoryAction = $data['category_action'] ?? 'ignore';
            if ($categoryAction !== 'ignore' && !empty($data['categories'])) {
                $update['categories'] = $categoryAction === 'append'
                    ? $this->mergeCommaValues($product->categories, $data['categories'])
                    : $data['categories'];
            }

            $tagsAction = $data['tags_action'] ?? 'ignore';
            if ($tagsAction !== 'ignore' && !empty($data['tags'])) {
                $update['tags'] = $tagsAction === 'append'
                    ? $this->mergeCommaValues($product->tags, $data['tags'])
                    : $data['tags'];
            }

            $focusAction = $data['focus_keyword_action'] ?? 'ignore';
            if ($focusAction === 'replace' && !empty($data['focus_keyword'])) {
                $update['focus_keyword'] = $data['focus_keyword'];
            }

            if (!empty($update)) {
                $product->update($update);
                $updated++;
            }
        }

        return redirect()->route('bdp.index')->with('success', "Bulk updated {$updated} products.");
    }

    protected function bulkTemplateTokens(BdpProduct $product): array
    {
        return [
            'product_name' => (string) $product->name,
            'name' => (string) $product->name,
            'sku' => (string) $product->sku,
            'category' => (string) $product->categories,
            'categories' => (string) $product->categories,
            'price' => $product->price !== null ? number_format((float) $product->price, 2) : '',
            'brand' => 'Balenco',
            'store' => 'Balenco',
        ];
    }

    protected function applyBulkTemplate(string $template, array $tokens): string
    {
        foreach ($tokens as $key => $value) {
            $template = str_replace(['{' . $key . '}', '{{' . $key . '}}'], $value, $template);
        }

        return trim($template);
    }

    protected function mergeCommaValues(?string $existing, string $new): string
    {
        $items = [];
        foreach (explode(',', (string) $existing . ',' . $new) as $item) {
            $item = trim($item);
            if ($item !== '') {
                $items[mb_strtolower($item)] = $item;
            }
        }

        return implode(', ', array_values($items));
    }


    public function cjSettings(BdpCjApiService $cj)
    {
        $token = $cj->token();
        return view('balenco-data-pilot.cj-settings', compact('token'));
    }

    public function saveCjSettings(Request $request, BdpCjApiService $cj)
    {
        $data = $request->validate([
            'api_key' => ['required', 'string', 'max:255'],
        ]);

        $cj->saveApiKey($data['api_key']);

        return redirect()->route('bdp.cj.settings')->with('success', 'CJ API key saved. Now click Get Access Token.');
    }

    public function getCjToken(BdpCjApiService $cj)
    {
        try {
            $cj->getAccessToken();
            return redirect()->route('bdp.cj.settings')->with('success', 'CJ access token received successfully.');
        } catch (\Throwable $e) {
            return redirect()->route('bdp.cj.settings')->with('error', 'CJ token error: ' . $e->getMessage());
        }
    }

    public function refreshCjToken(BdpCjApiService $cj)
    {
        try {
            $cj->refreshAccessToken();
            return redirect()->route('bdp.cj.settings')->with('success', 'CJ access token refreshed successfully.');
        } catch (\Throwable $e) {
            return redirect()->route('bdp.cj.settings')->with('error', 'CJ refresh error: ' . $e->getMessage());
        }
    }

    public function testCjConnection(BdpCjApiService $cj)
    {
        try {
            $cj->testConnection();
            return redirect()->route('bdp.cj.settings')->with('success', 'CJ connection test successful.');
        } catch (\Throwable $e) {
            return redirect()->route('bdp.cj.settings')->with('error', 'CJ connection test failed: ' . $e->getMessage());
        }
    }

    public function cjImportForm(Request $request, BdpCjApiService $cj)
    {
        $results = null;
        $keyword = (string) $request->query('keyword', '');
        if ($request->filled('keyword')) {
            try {
                $results = $cj->searchProducts([
                    'keyword' => $keyword,
                    'page' => (int) $request->query('page', 1),
                    'size' => (int) $request->query('size', 20),
                    'country_code' => $request->query('country_code'),
                    'min_price' => $request->query('min_price'),
                    'max_price' => $request->query('max_price'),
                ]);
            } catch (\Throwable $e) {
                return redirect()->route('bdp.cj.import')->with('error', 'CJ search failed: ' . $e->getMessage());
            }
        }

        return view('balenco-data-pilot.cj-import', compact('results', 'keyword'));
    }

    public function importFromCj(Request $request, BdpCjApiService $cj)
    {
        $data = $request->validate([
            'pid' => ['nullable', 'string', 'max:255'],
            'product_sku' => ['nullable', 'string', 'max:255'],
            'variant_sku' => ['nullable', 'string', 'max:255'],
        ]);

        if (empty($data['pid']) && empty($data['product_sku']) && empty($data['variant_sku'])) {
            return back()->with('error', 'Please provide a CJ product ID, product SKU, or variant SKU.');
        }

        try {
            $product = $cj->importProduct($data['pid'] ?? null, $data['product_sku'] ?? null, $data['variant_sku'] ?? null);
            return redirect()->route('bdp.products.edit', $product)->with('success', 'Imported CJ product into Data Pilot. Review it before syncing to Balenco.');
        } catch (\Throwable $e) {
            return back()->with('error', 'CJ import failed: ' . $e->getMessage());
        }
    }



    public function refreshCjInventoryShipping(Request $request, BdpProduct $product, BdpCjApiService $cj)
    {
        $data = $request->validate([
            'country_code' => ['nullable', 'string', 'max:10'],
            'quantity' => ['nullable', 'integer', 'min:1', 'max:100'],
        ]);

        try {
            $product->load('variations');
            $country = strtoupper($data['country_code'] ?? env('BDP_CJ_DEFAULT_SHIPPING_COUNTRY', 'US'));
            $quantity = (int) ($data['quantity'] ?? 1);
            $result = $cj->refreshInventoryAndShipping($product, $country ?: 'US', $quantity ?: 1);

            $message = "CJ refresh complete: {$result['inventory']} inventory rows updated and {$result['shipping']} product-level shipping estimate saved.";
            if (!empty($result['errors'])) {
                $message .= ' Some rows had errors: ' . implode(' | ', array_slice($result['errors'], 0, 3));
            }

            return redirect()->route('bdp.products.edit', $product)->with('success', $message);
        } catch (\Throwable $e) {
            return redirect()->route('bdp.products.edit', $product)->with('error', 'CJ inventory/shipping refresh failed: ' . $e->getMessage());
        }
    }

    public function apiLogs(Request $request)
    {
        $logs = BdpApiLog::query()
            ->when($request->filled('status'), fn ($q) => $q->where('status_code', (int) $request->query('status')))
            ->when($request->filled('endpoint'), fn ($q) => $q->where('endpoint', 'like', '%' . $request->query('endpoint') . '%'))
            ->latest('id')
            ->paginate(50)
            ->withQueryString();

        return view('balenco-data-pilot.api-logs', compact('logs'));
    }

    public function clearApiLogs()
    {
        BdpApiLog::query()->delete();

        return redirect()->route('bdp.api.logs')->with('success', 'API logs cleared.');
    }


    public function bulkPricing(Request $request, BdpCjApiService $cj)
    {
        $data = $request->validate([
            'products' => ['required', 'array'],
            'products.*' => ['integer'],
            'country_code' => ['nullable', 'string', 'max:10'],
            'quantity' => ['nullable', 'integer', 'min:1', 'max:100'],
            'margin_type' => ['required', Rule::in(['fixed', 'percent'])],
            'margin_value' => ['required', 'numeric', 'min:0', 'max:10000'],
            'round_mode' => ['nullable', Rule::in(['none', '99', '95', '00'])],
            'minimum_price' => ['nullable', 'numeric', 'min:0', 'max:10000'],
            'refresh_shipping' => ['nullable', 'boolean'],
        ]);

        $products = BdpProduct::with('variations')->whereIn('id', $data['products'])->get();
        if ($products->isEmpty()) {
            return back()->with('error', 'No selected products were found.');
        }

        $country = strtoupper($data['country_code'] ?: env('BDP_CJ_DEFAULT_SHIPPING_COUNTRY', 'US'));
        $quantity = (int) ($data['quantity'] ?? 1);
        $marginType = $data['margin_type'];
        $marginValue = (float) $data['margin_value'];
        $roundMode = $data['round_mode'] ?? '99';
        $minimumPrice = $data['minimum_price'] !== null && $data['minimum_price'] !== '' ? (float) $data['minimum_price'] : null;
        $refreshShipping = (bool) ($data['refresh_shipping'] ?? false);

        $updated = 0;
        $refreshed = 0;
        $errors = [];

        foreach ($products as $index => $product) {
            try {
                if ($refreshShipping || $product->cj_shipping_fee === null) {
                    $result = $cj->refreshInventoryAndShipping($product, $country ?: 'US', $quantity ?: 1);
                    $refreshed++;
                    if (!empty($result['errors'])) {
                        $errors[] = $product->name . ': ' . implode(' | ', array_slice($result['errors'], 0, 2));
                    }

                    // CJ logistics has strict QPS limits, so keep bulk refresh gentle.
                    if ($products->count() > 1 && $index < $products->count() - 1) {
                        sleep(1);
                    }
                }

                $product->refresh();
                $product->load('variations');

                $shippingFee = $product->cj_shipping_fee;
                if ($shippingFee === null || $shippingFee === '') {
                    $errors[] = $product->name . ': shipping fee is missing. Click Refresh CJ Inventory + Product Shipping or enable refresh in bulk pricing.';
                    continue;
                }

                $finalPrices = [];
                foreach ($product->variations as $variation) {
                    $cjCost = $variation->cost_per_item;
                    if ($cjCost === null || $cjCost === '') {
                        $cjCost = $variation->price ?: $product->cost_per_item ?: $product->price;
                    }
                    if ($cjCost === null || $cjCost === '') {
                        continue;
                    }

                    // Preserve the original CJ cost before overwriting price with Balenco selling price.
                    $landed = round((float) $cjCost + (float) $shippingFee, 2);
                    $selling = $this->calculateSellingPrice($landed, $marginType, $marginValue, $roundMode, $minimumPrice);

                    $variation->forceFill([
                        'cost_per_item' => round((float) $cjCost, 2),
                        'cj_shipping_fee' => (float) $shippingFee,
                        'landed_cost' => $landed,
                        'price' => $selling,
                        'sale_price' => null,
                    ])->save();

                    $finalPrices[] = $selling;
                }

                if (empty($finalPrices)) {
                    $errors[] = $product->name . ': no variation costs were available for pricing.';
                    continue;
                }

                $baseCost = $product->variations()->whereNotNull('cost_per_item')->min('cost_per_item') ?: $product->cost_per_item ?: $product->price;
                $productLanded = $baseCost !== null ? round((float) $baseCost + (float) $shippingFee, 2) : null;

                $product->forceFill([
                    'cost_per_item' => $baseCost !== null ? round((float) $baseCost, 2) : null,
                    'landed_cost' => $productLanded,
                    'price' => min($finalPrices),
                    'sale_price' => null,
                    'balenco_sync_status' => $product->shofy_product_id ? $product->balenco_sync_status : 'not_synced',
                    'balenco_sync_message' => sprintf(
                        'Bulk priced: cost + shipping + %s margin %s, rounded %s.',
                        $marginType === 'fixed' ? '$' : '',
                        rtrim(rtrim(number_format($marginValue, 2), '0'), '.'),
                        $roundMode
                    ),
                ])->save();

                $updated++;
            } catch (\Throwable $e) {
                $errors[] = $product->name . ': ' . $e->getMessage();
            }
        }

        $message = "Bulk pricing updated {$updated} products" . ($refreshed ? " and refreshed CJ shipping for {$refreshed} products" : '') . '.';
        if (!empty($errors)) {
            $message .= ' Notes: ' . implode(' | ', array_slice($errors, 0, 5));
        }

        return back()->with(empty($errors) ? 'success' : 'error', $message);
    }

    protected function calculateSellingPrice(float $landedCost, string $marginType, float $marginValue, string $roundMode = '99', ?float $minimumPrice = null): float
    {
        $price = $marginType === 'percent'
            ? $landedCost * (1 + ($marginValue / 100))
            : $landedCost + $marginValue;

        if ($minimumPrice !== null) {
            $price = max($price, $minimumPrice);
        }

        return round($this->roundRetailPrice($price, $roundMode), 2);
    }

    protected function roundRetailPrice(float $price, string $roundMode): float
    {
        if ($roundMode === 'none') {
            return $price;
        }

        if ($roundMode === '00') {
            return ceil($price);
        }

        $cents = $roundMode === '95' ? 0.95 : 0.99;
        $rounded = floor($price) + $cents;
        if ($rounded < $price) {
            $rounded = floor($price) + 1 + $cents;
        }

        return $rounded;
    }


    public function pushToShofy(Request $request, BdpShofyDirectPusher $pusher)
    {
        $ids = array_filter((array) $request->input('products', []));
        if (empty($ids)) {
            return back()->with('error', 'Please select at least one product to sync.');
        }

        $options = [
            'sync_status' => $request->input('sync_status', config('balenco-data-pilot.sync_default_status', 'draft')),
            'copy_variation_images' => $request->boolean('copy_variation_images', true),
        ];

        $result = $pusher->push($ids, $options);
        $message = "Synced {$result['products']} products and {$result['variations']} variations to Balenco.";

        if (!empty($result['errors'])) {
            return back()->with('error', $message . ' Errors: ' . implode(' | ', $result['errors']));
        }

        return back()->with('success', $message);
    }

    public function export(Request $request, BdpShofyExporter $exporter)
    {
        $ids = array_filter((array) $request->input('products', []));
        if (empty($ids)) {
            return back()->with('error', 'Please select at least one product.');
        }

        return $exporter->stream($ids);
    }
}
