<?php

use App\Http\Controllers\BalencoDataPilotController;
use App\Http\Controllers\BalencoCjaWooApiController;
use App\Http\Middleware\BalencoDataPilotAuth;
use Illuminate\Support\Facades\Route;

Route::get('/login', [BalencoDataPilotController::class, 'loginForm'])->name('bdp.login.form');
Route::post('/login', [BalencoDataPilotController::class, 'login'])->name('bdp.login');
Route::post('/logout', [BalencoDataPilotController::class, 'logout'])->name('bdp.logout');



// WooCommerce app authentication endpoint used by CJA Default connection.
// This simulates WooCommerce's /wc-auth/v1/authorize flow and returns API keys to CJA.
Route::match(['GET', 'POST'], '/wc-auth/v1/authorize', [BalencoCjaWooApiController::class, 'wcAuthorize'])->name('bdp.cja.woo.auth.authorize');
Route::match(['GET', 'POST'], '/wc-auth/v1/authorize/', [BalencoCjaWooApiController::class, 'wcAuthorize'])->name('bdp.cja.woo.auth.authorize.slash');
Route::match(['GET', 'POST'], '/wc-auth/v1/authorize/approve', [BalencoCjaWooApiController::class, 'wcAuthorizeApprove'])->name('bdp.cja.woo.auth.approve');

// WooCommerce-compatible API listener for CJA one-click listing.
// CJA store URL: https://your-data-pilot-domain.com
// Supports common WooCommerce REST paths used by CJA and other importers.
Route::match(['GET', 'POST', 'PUT', 'PATCH', 'DELETE'], '/wp-json/wc/v3/{endpoint?}', [BalencoCjaWooApiController::class, 'handle'])
    ->where('endpoint', '.*')
    ->name('bdp.cja.woo.api.v3');
Route::match(['GET', 'POST', 'PUT', 'PATCH', 'DELETE'], '/wp-json/wc/v2/{endpoint?}', [BalencoCjaWooApiController::class, 'handle'])
    ->where('endpoint', '.*')
    ->name('bdp.cja.woo.api.v2');
Route::match(['GET', 'POST', 'PUT', 'PATCH', 'DELETE'], '/wp-json/wc/v1/{endpoint?}', [BalencoCjaWooApiController::class, 'handle'])
    ->where('endpoint', '.*')
    ->name('bdp.cja.woo.api.v1');
Route::match(['GET', 'POST', 'PUT', 'PATCH', 'DELETE'], '/wc-api/v3/{endpoint?}', [BalencoCjaWooApiController::class, 'handle'])
    ->where('endpoint', '.*')
    ->name('bdp.cja.woo.legacy.v3');


// CJA fallback routes: if CJA accidentally stores /login as the base path after an auth redirect,
// these aliases still allow the WooCommerce auth/API flow to work.
Route::match(['GET', 'POST'], '/login/wc-auth/v1/authorize', [BalencoCjaWooApiController::class, 'wcAuthorize'])->name('bdp.cja.woo.auth.authorize.login_alias');
Route::match(['GET', 'POST'], '/login/wc-auth/v1/authorize/', [BalencoCjaWooApiController::class, 'wcAuthorize'])->name('bdp.cja.woo.auth.authorize.login_alias_slash');
Route::match(['GET', 'POST'], '/login/wc-auth/v1/authorize/approve', [BalencoCjaWooApiController::class, 'wcAuthorizeApprove'])->name('bdp.cja.woo.auth.approve.login_alias');
Route::match(['GET', 'POST', 'PUT', 'PATCH', 'DELETE'], '/login/wp-json/wc/v3/{endpoint?}', [BalencoCjaWooApiController::class, 'handle'])
    ->where('endpoint', '.*')
    ->name('bdp.cja.woo.api.v3.login_alias');
Route::match(['GET', 'POST', 'PUT', 'PATCH', 'DELETE'], '/login/wp-json/wc/v2/{endpoint?}', [BalencoCjaWooApiController::class, 'handle'])
    ->where('endpoint', '.*')
    ->name('bdp.cja.woo.api.v2.login_alias');
Route::match(['GET', 'POST', 'PUT', 'PATCH', 'DELETE'], '/login/wp-json/wc/v1/{endpoint?}', [BalencoCjaWooApiController::class, 'handle'])
    ->where('endpoint', '.*')
    ->name('bdp.cja.woo.api.v1.login_alias');
Route::match(['GET', 'POST', 'PUT', 'PATCH', 'DELETE'], '/login/wc-api/v3/{endpoint?}', [BalencoCjaWooApiController::class, 'handle'])
    ->where('endpoint', '.*')
    ->name('bdp.cja.woo.legacy.v3.login_alias');

Route::middleware([BalencoDataPilotAuth::class])->name('bdp.')->group(function () {
    Route::get('/', [BalencoDataPilotController::class, 'index'])->name('index');
    Route::get('/products', [BalencoDataPilotController::class, 'products'])->name('products');
    Route::get('/import', [BalencoDataPilotController::class, 'importForm'])->name('import.form');
    Route::get('/cj-settings', [BalencoDataPilotController::class, 'cjSettings'])->name('cj.settings');
    Route::post('/cj-settings', [BalencoDataPilotController::class, 'saveCjSettings'])->name('cj.settings.save');
    Route::post('/cj-settings/token', [BalencoDataPilotController::class, 'getCjToken'])->name('cj.token');
    Route::post('/cj-settings/refresh', [BalencoDataPilotController::class, 'refreshCjToken'])->name('cj.token.refresh');
    Route::post('/cj-settings/test', [BalencoDataPilotController::class, 'testCjConnection'])->name('cj.test');
    Route::get('/cj-import', [BalencoDataPilotController::class, 'cjImportForm'])->name('cj.import');
    Route::post('/cj-import', [BalencoDataPilotController::class, 'importFromCj'])->name('cj.import.product');
    Route::get('/api-logs', [BalencoDataPilotController::class, 'apiLogs'])->name('api.logs');
    Route::post('/api-logs/clear', [BalencoDataPilotController::class, 'clearApiLogs'])->name('api.logs.clear');
    Route::get('/category-mapping', [BalencoDataPilotController::class, 'categoryMapping'])->name('categories.mapping');
    Route::post('/category-mapping', [BalencoDataPilotController::class, 'saveCategoryMapping'])->name('categories.mapping.save');
    Route::post('/bulk-assign-category', [BalencoDataPilotController::class, 'bulkAssignCategory'])->name('categories.bulk.assign');
    Route::post('/import', [BalencoDataPilotController::class, 'import'])->name('import');
    Route::get('/products/{product}/edit', [BalencoDataPilotController::class, 'edit'])->name('products.edit');
    Route::put('/products/{product}', [BalencoDataPilotController::class, 'update'])->name('products.update');
    Route::post('/products/{product}/refresh-cj-inventory-shipping', [BalencoDataPilotController::class, 'refreshCjInventoryShipping'])->name('products.refresh.cj');
    Route::post('/export', [BalencoDataPilotController::class, 'export'])->name('export');
    Route::post('/bulk-edit', [BalencoDataPilotController::class, 'bulkEdit'])->name('bulk.edit');
    Route::post('/bulk-update', [BalencoDataPilotController::class, 'bulkUpdate'])->name('bulk.update');
    Route::post('/bulk-pricing', [BalencoDataPilotController::class, 'bulkPricing'])->name('bulk.pricing');
    Route::post('/push-to-shofy', [BalencoDataPilotController::class, 'pushToShofy'])->name('push');
});

// Old URL support. If you open /balenco-data-pilot, it redirects to root.
Route::redirect('/balenco-data-pilot', '/');
