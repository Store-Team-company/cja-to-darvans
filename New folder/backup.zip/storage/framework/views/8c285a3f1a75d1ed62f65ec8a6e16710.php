<?php $__env->startSection('title', 'Products | Balenco Data Pilot'); ?>

<?php $__env->startSection('content'); ?>
<?php
    // BDP labels filter data fallback
    $bdpProductLabels = collect();

    try {
        if (class_exists(\App\Models\BdpLabel::class) && \Illuminate\Support\Facades\Schema::hasTable('bdp_labels')) {
            $bdpProductLabels = \App\Models\BdpLabel::query()
                ->orderBy('name')
                ->get();
        }
    } catch (\Throwable $e) {
        $bdpProductLabels = collect();
    }
?>


<?php
    $tabs = [
        'all' => 'All',
        'not_synced' => 'Not Synced',
        'synced' => 'Synced',
        'needs_review' => 'Needs Review',
        'failed' => 'Failed',
    ];

    $bdpSettingsRows = [];

    try {
        if (\Illuminate\Support\Facades\Schema::hasTable('bdp_settings')) {
            $bdpSettingsRows = \Illuminate\Support\Facades\DB::table('bdp_settings')->pluck('value', 'key')->toArray();
        }
    } catch (\Throwable $e) {
        $bdpSettingsRows = [];
    }

    $bdpSetting = function (array $keys, $default = null) use ($bdpSettingsRows) {
        foreach ($keys as $key) {
            if (array_key_exists($key, $bdpSettingsRows) && $bdpSettingsRows[$key] !== null && $bdpSettingsRows[$key] !== '') {
                return $bdpSettingsRows[$key];
            }
        }

        return $default;
    };

    $bdpBool = function ($value, $default = false) {
        if ($value === null || $value === '') {
            return (bool) $default;
        }

        return filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) ?? (bool) $default;
    };

    $bdpSyncDefault = $bdpSetting(['default_sync_status', 'sync_status'], 'draft');

    $bdpCopyVariation = $bdpBool(
        $bdpSetting(['copy_variation_images_to_shofy', 'copy_variation_images'], null),
        true
    );

    $bdpParentFeatured = $bdpBool(
        $bdpSetting(['push_parent_featured_image', 'sync_parent_featured_image', 'parent_image_sync'], null),
        false
    );

    $bdpParentGallery = $bdpBool(
        $bdpSetting(['push_parent_gallery_images', 'sync_parent_gallery_images', 'gallery_image_sync'], null),
        false
    );

    $bdpParentSync = $bdpParentFeatured || $bdpParentGallery;
?>

<style>
    .bdp-products-shell{display:flex;flex-direction:column;gap:18px}
    .bdp-products-head{display:flex;justify-content:space-between;gap:18px;align-items:flex-start}
    .bdp-products-head-actions{display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end}
    .bdp-products-search-card{padding:18px}
    .bdp-products-filter-grid{display:grid;grid-template-columns:minmax(260px,1.7fr) minmax(140px,.8fr) minmax(140px,.8fr) minmax(110px,.55fr) auto auto;gap:12px;align-items:end}
    .bdp-products-tools{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
    .bdp-tool-toggle{border:1px solid var(--bdp-border);background:#fff;border-radius:12px;padding:10px 13px;font-weight:800;color:var(--bdp-navy);cursor:pointer;display:inline-flex;gap:8px;align-items:center}
    .bdp-tool-toggle:hover{background:#f8fafc}
    .bdp-tool-toggle.active{background:#eff6ff;border-color:#bfdbfe;color:#1d4ed8}
    .bdp-tool-panel{display:none}
    .bdp-tool-panel.is-open{display:block}
    .bdp-selected-bar{display:flex;align-items:center;justify-content:space-between;gap:14px;background:#0f1f3d;color:#fff;border-radius:16px;padding:13px 16px;margin-top:14px}
    .bdp-selected-bar strong{font-size:14px}
    .bdp-selected-actions{display:flex;gap:10px;flex-wrap:wrap}
    .bdp-btn.dark{background:#0f1f3d;color:#fff}
    .bdp-btn.danger-light{background:#fff1f2;color:#be123c;border-color:#fecdd3}
    .bdp-products-table .bdp-product-title{max-width:300px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
    .bdp-products-table .bdp-product-meta{max-width:320px;display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;overflow:hidden}
    .bdp-product-thumb-wrap{position:relative}
    .bdp-row-actions{display:flex;align-items:center;gap:8px}
    .bdp-icon-btn{width:34px;height:34px;border-radius:10px;border:1px solid var(--bdp-border);background:#fff;color:var(--bdp-muted);display:inline-flex;align-items:center;justify-content:center;text-decoration:none}
    .bdp-icon-btn:hover{background:#f8fafc;color:var(--bdp-navy)}
    .bdp-compact-note{display:flex;align-items:center;gap:8px;color:var(--bdp-muted);font-size:12px}
    .bdp-table-footer{display:flex;justify-content:space-between;gap:15px;align-items:center;margin-top:16px;flex-wrap:wrap}
    .bdp-page-links{font-size:13px;color:#475569}
    .bdp-page-links nav{display:flex!important;justify-content:flex-end!important;align-items:center!important;gap:10px!important;flex-wrap:wrap!important}
    .bdp-page-links nav > div{display:flex!important;align-items:center!important;gap:8px!important;flex-wrap:wrap!important}
    .bdp-page-links .pagination{display:flex;gap:6px;list-style:none;margin:0;padding:0;align-items:center}
    .bdp-page-links .page-link,.bdp-page-links .page-item span,.bdp-page-links nav a,.bdp-page-links nav span[aria-current] span,.bdp-page-links nav span[aria-disabled] span{display:inline-flex!important;min-width:34px!important;height:34px!important;max-width:90px!important;align-items:center!important;justify-content:center!important;border:1px solid var(--bdp-border)!important;border-radius:10px!important;background:#fff!important;color:var(--bdp-navy)!important;text-decoration:none!important;padding:0 10px!important;font-size:13px!important;line-height:1!important;box-shadow:none!important}
    .bdp-page-links svg{width:16px!important;height:16px!important;max-width:16px!important;max-height:16px!important;display:block!important;stroke-width:2!important}
    .bdp-page-links .active .page-link,.bdp-page-links .active span,.bdp-page-links nav span[aria-current] span{background:#0f1f3d!important;color:#fff!important;border-color:#0f1f3d!important}
    .bdp-page-links .disabled span,.bdp-page-links nav span[aria-disabled] span{opacity:.45!important;background:#f8fafc!important}
    .bdp-page-links p{margin:0!important;color:#64748b!important;font-size:12px!important}
    .bdp-empty-products{text-align:center;padding:48px 20px;border:1px dashed #cbd5e1;border-radius:18px;background:#f8fafc}
    .bdp-product-list-tabs{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:14px 0 16px}
    .bdp-list-header-actions{display:flex;gap:10px;flex-wrap:wrap;align-items:center;justify-content:flex-end}
    .bdp-sync-settings-summary{display:flex;align-items:center;justify-content:space-between;gap:12px;background:#f8fafc;border:1px solid #edf1f7;border-radius:14px;padding:12px 14px;margin-top:12px;flex-wrap:wrap}
    .bdp-sync-settings-summary .summary-text{color:#475569;font-size:13px;line-height:1.45}
    .bdp-sync-settings-summary strong{color:#0f172a}
    @media(max-width:1100px){
        .bdp-products-filter-grid{grid-template-columns:1fr 1fr}
        .bdp-products-head{flex-direction:column}
        .bdp-products-head-actions{justify-content:flex-start}
        .bdp-selected-bar{align-items:flex-start;flex-direction:column}
    }
    @media(max-width:720px){
        .bdp-products-filter-grid{grid-template-columns:1fr}
        .bdp-products-tools{display:grid;grid-template-columns:1fr}
        .bdp-tool-toggle{justify-content:space-between}
        .bdp-table-footer{align-items:flex-start;flex-direction:column}
    }
.bdp-sync-settings-summary{display:none!important}
.bdp-label-chip{display:inline-flex;align-items:center;gap:6px;border:1px solid #dbeafe;background:#eff6ff;color:#1d4ed8;border-radius:999px;padding:4px 9px;font-size:12px;font-weight:800}

    /* BDP title link + collapsible filter patch */
    .bdp-product-title-link{color:#0f172a;text-decoration:none;font-weight:900}
    .bdp-product-title-link:hover{color:#ff5a1f;text-decoration:underline}
    .bdp-products-search-card.is-collapsed .bdp-products-filter-grid,
    .bdp-products-search-card.is-collapsed .bdp-toolbar{display:none!important}
    .bdp-filter-toggle-btn{border:1px solid var(--bdp-border);background:#fff;border-radius:12px;padding:10px 13px;font-weight:900;color:var(--bdp-navy);cursor:pointer;display:inline-flex;align-items:center;gap:8px;white-space:nowrap}
    .bdp-filter-toggle-btn:hover{background:#f8fafc;color:#ff5a1f}
    .bdp-products-search-card.is-collapsed{padding-bottom:18px}


    .bdp-row-actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
</style>

<?php
    // BDP_PRODUCT_CATEGORY_DROPDOWN_DATA
    try {
        $bdpBalencoCategories = \Illuminate\Support\Facades\Schema::hasTable('bdp_balenco_categories')
            ? \App\Models\BdpBalencoCategory::orderBy('path')->orderBy('name')->get()
            : collect();
    } catch (\Throwable $e) {
        $bdpBalencoCategories = collect();
    }
?>

<div class="bdp-products-shell">
    <div class="bdp-products-head">
        <div class="bdp-page-title">
            <h1>Products</h1>
            <p>Manage imported CJ products, pricing, categories, variation images, and Balenco sync status.</p>
        </div>
        <div class="bdp-products-head-actions">
            <a class="bdp-btn light" href="<?php echo e(route('bdp.cj.import')); ?>">Import from CJ</a>
            <button class="bdp-btn orange" type="submit" form="bdp-products-form" formaction="<?php echo e(route('bdp.push')); ?>" formmethod="post">Sync Selected</button>
                    <button class="bdp-btn light" type="submit" form="bdp-products-form" formaction="<?php echo e(route('bdp.sync.queue.enqueue')); ?>" formmethod="post">Add to Sync Queue</button>
                    <a class="bdp-btn light" href="<?php echo e(route('bdp.sync.queue.index')); ?>">View Sync Queue</a>
                <button class="bdp-btn light" type="submit" form="bdp-products-form" formaction="<?php echo e(route('bdp.products.archive')); ?>" formmethod="post">Disable Selected</button>
                <button class="bdp-btn light" type="submit" form="bdp-products-form" formaction="<?php echo e(route('bdp.products.restore')); ?>" formmethod="post">Restore Selected</button>
        </div>
    </div>

    <div class="bdp-grid bdp-stats" style="grid-template-columns:repeat(5,minmax(150px,1fr))">
        <div class="bdp-stat-card">
            <div class="bdp-stat-icon is-blue">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 8 12 3 3 8l9 5 9-5Z"/><path d="M3 8v8l9 5 9-5V8"/></svg>
            </div>
            <div><div class="bdp-stat-label">All Products</div><div class="bdp-stat-number"><?php echo e($counts['all'] ?? 0); ?></div><div class="bdp-stat-note">Imported into Data Pilot</div></div>
        </div>
        <div class="bdp-stat-card">
            <div class="bdp-stat-icon is-green">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m20 6-11 11-5-5"/></svg>
            </div>
            <div><div class="bdp-stat-label">Synced</div><div class="bdp-stat-number"><?php echo e($counts['synced'] ?? 0); ?></div><div class="bdp-stat-note">Live in Balenco</div></div>
        </div>
        <div class="bdp-stat-card">
            <div class="bdp-stat-icon is-orange">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 0 0-15.5-6.2L3 8"/><path d="M3 3v5h5"/></svg>
            </div>
            <div><div class="bdp-stat-label">Not Synced</div><div class="bdp-stat-number"><?php echo e($counts['not_synced'] ?? 0); ?></div><div class="bdp-stat-note">Waiting for push</div></div>
        </div>
        <div class="bdp-stat-card">
            <div class="bdp-stat-icon is-purple">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 9v4"/><path d="M12 17h.01"/><circle cx="12" cy="12" r="10"/></svg>
            </div>
            <div><div class="bdp-stat-label">Needs Review</div><div class="bdp-stat-number"><?php echo e($counts['needs_review'] ?? 0); ?></div><div class="bdp-stat-note">Missing data</div></div>
        </div>
        <div class="bdp-stat-card">
            <div class="bdp-stat-icon is-red">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg>
            </div>
            <div><div class="bdp-stat-label">Failed</div><div class="bdp-stat-number"><?php echo e($counts['failed'] ?? 0); ?></div><div class="bdp-stat-note">Need fixing</div></div>
        </div>
    </div>

    <div class="bdp-card bdp-products-search-card" id="product-controls">
        <div class="bdp-card-header">
            <div>
                <h3 class="bdp-card-title">Find & Filter Products</h3>
                <p class="bdp-card-subtitle">Search products, filter by sync state, then select items for bulk actions.</p>

                <div class="bdp-sync-settings-summary">
                    <div class="summary-text">
                        <strong>Sync settings locked:</strong>
                        Mode: <strong><?php echo e(ucfirst($bdpSyncDefault)); ?></strong> ·
                        Variation images: <strong><?php echo e($bdpCopyVariation ? 'Copy enabled' : 'Disabled'); ?></strong> ·
                        Parent/gallery: <strong><?php echo e($bdpParentSync ? 'Push enabled' : 'Manual upload'); ?></strong>
                    </div>
                    <a href="<?php echo e(route('bdp.settings')); ?>" class="bdp-btn light">Manage in Settings</a>
                </div>
            </div>
        </div>

        <form method="GET" action="<?php echo e(route('bdp.products')); ?>" class="bdp-products-filter-grid">
            <input type="hidden" name="sync" value="<?php echo e($sync ?? 'all'); ?>">
            <div>
                <label>Search</label>
                <input type="search" name="q" value="<?php echo e($search ?? request('q')); ?>" placeholder="Product title, SKU, CJ SKU, source ID...">
            </div>
                                <?php if(!empty($product->seo_optimized_at)): ?>
                                    <span class="bdp-seo-optimized-badge" title="Optimized <?php echo e(optional($product->seo_optimized_at)->format('Y-m-d H:i')); ?>">Optimized</span>
                                <?php endif; ?>
            <div>
                <label>Status</label>
                <select name="status">
                    <option value="all" <?php if(($status ?? 'all') === 'all'): echo 'selected'; endif; ?>>All statuses</option>
                    <option value="draft" <?php if(($status ?? '') === 'draft'): echo 'selected'; endif; ?>>Draft</option>
                    <option value="published" <?php if(($status ?? '') === 'published'): echo 'selected'; endif; ?>>Published</option>
                    <option value="pending" <?php if(($status ?? '') === 'pending'): echo 'selected'; endif; ?>>Pending</option>
                </select>
            </div>
            <div>
                <label>Category contains</label>
                <input type="text" name="category" value="<?php echo e($category ?? request('category')); ?>" placeholder="Sneakers, Pumps...">
            </div>
            <div>
                <label>Label</label>
                <select name="label_id">
                    <option value="">All labels</option>
                    <?php $__currentLoopData = $bdpProductLabels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($label->id); ?>" <?php if((string) request('label_id') === (string) $label->id): echo 'selected'; endif; ?>><?php echo e($label->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
                <div>
                    <label>SEO Status</label>
                    <select name="seo_status">
                        <option value="all" <?php if(($seoStatus ?? request('seo_status', 'all')) === 'all'): echo 'selected'; endif; ?>>All SEO</option>
                        <option value="optimized" <?php if(($seoStatus ?? request('seo_status')) === 'optimized'): echo 'selected'; endif; ?>>Optimized</option>
                        <option value="not_optimized" <?php if(($seoStatus ?? request('seo_status')) === 'not_optimized'): echo 'selected'; endif; ?>>Not optimized</option>
                    </select>
                </div>
            <div>
                <label>Per page</label>
                <select name="per_page">
                    <?php $__currentLoopData = [10,25,50,100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($size); ?>" <?php if((int)($perPage ?? 25) === $size): echo 'selected'; endif; ?>><?php echo e($size); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button class="bdp-btn orange" type="submit">Apply</button>
            <a class="bdp-btn light" href="<?php echo e(route('bdp.products')); ?>">Reset</a>
        </form>

        <div class="bdp-toolbar" style="margin-top:16px;justify-content:space-between">
            <div class="bdp-products-tools">
                <button class="bdp-tool-toggle" type="button" data-product-tool="pricing-tools">Bulk Price Update</button>
            </div>
            <div class="bdp-compact-note">
                <span class="bdp-pill muted">Tip</span>
                Sync behavior is controlled in Settings. Select products below, then use Bulk Price Update to update prices safely.
            </div>
        </div>

        <div class="bdp-selected-bar" id="bdp-selected-bar" style="display:none">
            <strong><span id="bdp-selected-count">0</span> products selected</strong>
            <div class="bdp-selected-actions">
                <button class="bdp-btn orange" type="submit" form="bdp-products-form" formaction="<?php echo e(route('bdp.push')); ?>" formmethod="post">Sync Selected</button>
                <button class="bdp-btn light" type="submit" form="bdp-products-form" formaction="<?php echo e(route('bdp.products.archive')); ?>" formmethod="post">Disable Selected</button>
                <button class="bdp-btn light" type="submit" form="bdp-products-form" formaction="<?php echo e(route('bdp.products.restore')); ?>" formmethod="post">Restore Selected</button>
                <button class="bdp-btn light" type="button" id="bdpExportSelectedSeoCsvBtn" data-export-url="<?php echo e(route('bdp.bulk.optimization.export')); ?>">Export Selected SEO CSV</button>
<button class="bdp-btn light" type="submit" form="bdp-products-form" formaction="<?php echo e(route('bdp.bulk.edit')); ?>" formmethod="post">Bulk SEO Edit</button>

                <button class="bdp-btn danger-light" type="button" id="bdp-clear-selection">Clear</button>
            </div>
        </div>
    </div>

    <div class="bdp-tool-panel" id="pricing-tools">
        <div class="bdp-card" id="bulk-pricing">
            <div class="bdp-card-header">
                <div>
                    <h3 class="bdp-card-title">Bulk Price Update</h3>
                    <p class="bdp-card-subtitle">Select products from the list, then update Data Pilot prices using existing landed cost + margin. Products are not changed on Balenco until you sync them.</p>
                </div>
                <button class="bdp-btn light" type="button" data-close-tool="pricing-tools">Close</button>
            </div>
            <div class="bdp-alert" style="background:#eff6ff;border-color:#bfdbfe;color:#1e3a8a;margin-top:12px">
                <strong>Bulk price update:</strong> Uses existing landed cost by default. Select “Refresh CJA shipping” only when you want to recheck shipping before pricing. After review, sync selected products to Balenco as draft.
            </div>
            <div class="bdp-form-grid" style="margin-top:14px">
                <div>
                    <label>Destination country</label>
                    <select form="bdp-products-form" name="country_code">
                        <option value="US" selected>United States (US)</option>
                        <option value="GB">United Kingdom (GB)</option>
                        <option value="CA">Canada (CA)</option>
                        <option value="AU">Australia (AU)</option>
                        <option value="DE">Germany (DE)</option>
                        <option value="FR">France (FR)</option>
                    </select>
                </div>
                <div>
                    <label>Quantity for shipping</label>
                    <input form="bdp-products-form" type="number" name="quantity" value="1" min="1" max="100">
                </div>
                <div>
                    <label>Margin type</label>
                    <select form="bdp-products-form" name="margin_type">
                        <option value="fixed" selected>Fixed amount</option>
                        <option value="percent">Percentage markup</option>
                    </select>
                </div>
                <div>
                    <label>Margin value</label>
                    <input form="bdp-products-form" type="number" name="margin_value" value="20" step="0.01" min="0">
                </div>
                <div>
                    <label>Minimum selling price</label>
                    <input form="bdp-products-form" type="number" name="minimum_price" value="39.99" step="0.01" min="0">
                </div>
                <div>
                    <label>Retail rounding</label>
                    <select form="bdp-products-form" name="round_mode">
                        <option value="99" selected>Round up to .99</option>
                        <option value="95">Round up to .95</option>
                        <option value="00">Round up to whole dollar</option>
                        <option value="none">No rounding</option>
                    </select>
                </div>
            </div>
            <label style="display:flex;align-items:center;gap:8px;margin-top:14px;font-weight:650">
                <input form="bdp-products-form" class="bdp-checkbox" type="checkbox" name="refresh_shipping" value="1" style="width:auto">
                Refresh CJA shipping before updating prices <span style="color:#64748b;font-size:12px;font-weight:500">(optional — cron already updates shipping and landed cost)</span>
            </label>
            <div style="margin-top:14px">
                <button class="bdp-btn orange" type="submit" form="bdp-products-form" formaction="<?php echo e(route('bdp.bulk.pricing')); ?>" formmethod="post">Bulk Price Update</button>
            </div>
        </div>
    </div>

    
    <div class="bdp-tool-panel" id="label-tools">
        <div class="bdp-card">
            <div class="bdp-card-header">
                <div>
                    <h3 class="bdp-card-title">Labels</h3>
                    <p class="bdp-card-subtitle">Create labels, assign them to selected products, then filter by label later.</p>
                </div>
                <button class="bdp-btn light" type="button" data-close-tool="label-tools">Close</button>
            </div>
            <div class="bdp-form-grid" style="margin-top:14px">
                <div>
                    <label>Create new label</label>
                    <input form="bdp-products-form" type="text" name="new_label_name" placeholder="e.g. Ready for SEO, Good Ads, Needs Images">
                </div>
                <div>
                    <label>Or choose existing label</label>
                    <select form="bdp-products-form" name="label_id">
                        <option value="">Select existing label</option>
                        <?php $__currentLoopData = $bdpProductLabels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($label->id); ?>"><?php echo e($label->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:14px">
                <button class="bdp-btn light" type="submit" form="bdp-products-form" formaction="<?php echo e(route('bdp.products.labels.assign')); ?>" formmethod="post">Assign Label to Selected</button>
                <button class="bdp-btn light" type="submit" form="bdp-products-form" formaction="<?php echo e(route('bdp.products.labels.remove')); ?>" formmethod="post">Remove Selected Label</button>
            </div>
            <div class="bdp-input-help" style="margin-top:10px">Tip: labels are for internal workflow only. They do not sync to Balenco.</div>
        </div>
    </div>

<form id="bdp-products-form" method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="sync_status" value="<?php echo e($bdpSyncDefault ?: 'draft'); ?>">
        <?php if($bdpCopyVariation): ?>
            <input type="hidden" name="copy_variation_images" value="1">
        <?php endif; ?>

        <div class="bdp-card">
            <div class="bdp-card-header">
                <div>
        
        <div class="bdp-list-header-actions">
                    
                        
<script>
                        (function(){
                            if (window.__bdpProductsPerPageSelectorLoaded) return;
                            window.__bdpProductsPerPageSelectorLoaded = true;
                            document.addEventListener('DOMContentLoaded', function(){
                                var select = document.getElementById('bdp-products-per-page');
                                var custom = document.getElementById('bdp-products-per-page-custom');
                                var apply = document.getElementById('bdp-products-per-page-apply');
                                if (!select || !custom || !apply) return;

                                function toggleCustom(){
                                    custom.style.display = select.value === 'custom' ? 'inline-block' : 'none';
                                    if (select.value === 'custom') custom.focus();
                                }

                                function applyPerPage(){
                                    var value = select.value === 'custom' ? parseInt(custom.value, 10) : parseInt(select.value, 10);
                                    if (!value || value < 1) value = 25;
                                    if (value > 500) value = 500;
                                    var url = new URL(window.location.href);
                                    url.searchParams.set('per_page', value);
                                    url.searchParams.delete('page');
                                    window.location.href = url.toString();
                                }

                                select.addEventListener('change', function(){
                                    toggleCustom();
                                    if (select.value !== 'custom') applyPerPage();
                                });
                                apply.addEventListener('click', applyPerPage);
                                custom.addEventListener('keydown', function(e){
                                    if (e.key === 'Enter') {
                                        e.preventDefault();
                                        applyPerPage();
                                    }
                                });
                            });
                        })();
                        </script>
                        
<button type="button" class="bdp-btn light" id="bdp-select-visible">Select visible</button>
                    <button type="button" class="bdp-btn light" id="bdp-unselect-visible">Clear</button>
                </div>
            </div>

            <div class="bdp-product-list-tabs">
                <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('bdp.products', array_merge(request()->except('page'), ['sync' => $key]))); ?>" class="bdp-btn <?php echo e(($sync ?? 'all') === $key ? 'orange' : 'light'); ?>"><?php echo e($label); ?> (<?php echo e($counts[$key] ?? 0); ?>)</a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="bdp-table-wrap">
                <table class="bdp-table bdp-products-table">
                    <thead>
                        <tr>
                            <th><input class="bdp-checkbox" type="checkbox" id="bdp-check-all"></th>
                            <th>Product</th>
                            <th>SKU</th>
                            <th>Vars</th>
                            <th>CJ Cost</th>
                            <th>Shipping</th>
                            <th>Landed</th>
                            <th>Selling</th>
                            <th>Stock</th>
                            <th>Status</th>
                            <th>Balenco Sync</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            // BDP safe row defaults: must be defined before any product-row buttons/columns use them.
                            $displayCost = $product->min_variation_cost
                                ?: $product->cost_per_item
                                ?: $product->min_variation_price
                                ?: $product->price
                                ?: null;
                        ?>
                        <tr>
                            <td><input class="bdp-checkbox bdp-product-select" type="checkbox" name="products[]" value="<?php echo e($product->id); ?>"></td>
                            <td>
                                <div class="bdp-product-cell">
                                    <div class="bdp-product-thumb-wrap">
                                        <?php if($product->featured_image): ?>
                                            <img class="bdp-thumb" src="<?php echo e($product->featured_image); ?>" alt="">
                                        <?php else: ?>
                                            <div class="bdp-thumb"></div>
                                        <?php endif; ?>
                                    </div>
                                    <div>
                                        <a class="bdp-product-title bdp-product-title-link" href="<?php echo e(route('bdp.products.edit', $product)); ?>"><?php echo e($product->name); ?></a>
                                        <div class="bdp-product-meta"><?php echo e($product->categories ?: 'No category'); ?></div>
                                    </div>
                                </div>
                            </td>
                            <td><?php echo e($product->sku ?: '—'); ?></td>
                            <td><?php echo e($product->variations_count); ?></td>
                            <td><?php echo e($displayCost !== null && $displayCost !== '' ? '$' . number_format((float) $displayCost, 2) : '—'); ?></td>
                            <td>
                                <?php if($product->cj_shipping_fee !== null): ?>
                                    <strong>$<?php echo e(number_format((float)$product->cj_shipping_fee, 2)); ?></strong>
                                    <?php if($product->cj_shipping_country): ?><br><small><?php echo e($product->cj_shipping_country); ?></small><?php endif; ?>
                                    <?php if($product->cj_shipping_method): ?><br><small><?php echo e(\Illuminate\Support\Str::limit($product->cj_shipping_method, 24)); ?></small><?php endif; ?>
                                <?php else: ?>
                                    <span class="bdp-pill muted">Refresh CJ</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($product->landed_cost !== null ? '$' . number_format((float) $product->landed_cost, 2) : '—'); ?></td>
                            <td><?php echo e($product->price !== null && $product->price !== '' ? '$' . number_format((float) $product->price, 2) : '—'); ?></td>
                            <td><?php echo e($product->variations_total_quantity !== null ? number_format((int)$product->variations_total_quantity) : '—'); ?></td>
                            <td><span class="bdp-pill <?php echo e($product->status === 'published' ? 'success' : 'muted'); ?>"><?php echo e($product->status); ?></span></td>
                            <td>
                                <?php if($product->balenco_sync_status === 'sync_failed'): ?>
                                    <span class="bdp-pill danger">Sync Failed</span><br>
                                    <small><?php echo e(\Illuminate\Support\Str::limit($product->balenco_sync_message ?: $product->shofy_push_note, 80)); ?></small>
                                <?php elseif(!empty($product->shofy_product_id)): ?>
                                    <span class="bdp-pill success"><?php echo e($product->balenco_sync_status === 'updated_in_balenco' ? 'Updated' : 'Synced'); ?></span><br>
                                    <small>Balenco ID: <?php echo e($product->shofy_product_id); ?></small><br>
                                    <small><?php echo e(optional($product->balenco_synced_at ?: $product->shofy_pushed_at)->format('Y-m-d H:i')); ?></small><br>
                                    <?php if(!is_null($product->shofy_variations_count)): ?>
                                        <small><?php echo e($product->shofy_variations_count); ?> variations synced</small>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="bdp-pill muted">Not Synced</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="bdp-row-actions">
                                    <a class="bdp-btn light" href="<?php echo e(route('bdp.products.images.zip', $product)); ?>" title="Download product images as ZIP">Images ZIP</a>
                                    
                                    <a class="bdp-btn light" href="<?php echo e(route('bdp.products.edit', $product)); ?>">Edit</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="12">
                                <div class="bdp-empty-products">
                                    <h3>No products found</h3>
                                    <p>Try changing filters or import products from CJ.</p>
                                    <a class="bdp-btn orange" href="<?php echo e(route('bdp.cj.import')); ?>">Import from CJ</a>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="bdp-table-footer">
                <div class="bdp-compact-note">Recommended Balenco rule: landed cost + $20 margin, rounded to .99, minimum $39.99.</div>
                <div class="bdp-page-links"><?php echo e($products->links()); ?></div>
            </div>
        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const panels = document.querySelectorAll('.bdp-tool-panel');
    const toggles = document.querySelectorAll('[data-product-tool]');
    const storageKey = 'bdp-products-open-tool';

    function openPanel(id) {
        panels.forEach(panel => panel.classList.toggle('is-open', panel.id === id));
        toggles.forEach(btn => btn.classList.toggle('active', btn.dataset.productTool === id));
        if (id) {
            localStorage.setItem(storageKey, id);
        } else {
            localStorage.removeItem(storageKey);
        }
    }

    toggles.forEach(btn => btn.addEventListener('click', () => {
        const panel = document.getElementById(btn.dataset.productTool);
        openPanel(panel && panel.classList.contains('is-open') ? null : btn.dataset.productTool);
    }));

    document.querySelectorAll('[data-close-tool]').forEach(btn => btn.addEventListener('click', () => openPanel(null)));

    const saved = localStorage.getItem(storageKey);
    if (saved && document.getElementById(saved)) {
        openPanel(saved);
    }

    const selects = Array.from(document.querySelectorAll('.bdp-product-select'));
    const checkAll = document.getElementById('bdp-check-all');
    const selectedBar = document.getElementById('bdp-selected-bar');
    const selectedCount = document.getElementById('bdp-selected-count');

    function updateSelected() {
        const count = selects.filter(cb => cb.checked).length;
        selectedCount.textContent = count;
        selectedBar.style.display = count > 0 ? 'flex' : 'none';
        if (checkAll) {
            checkAll.checked = count > 0 && count === selects.length;
        }
    }

    selects.forEach(cb => cb.addEventListener('change', updateSelected));

    if (checkAll) {
        checkAll.addEventListener('change', () => {
            selects.forEach(cb => cb.checked = checkAll.checked);
            updateSelected();
        });
    }

    const selectVisible = document.getElementById('bdp-select-visible');
    const unselectVisible = document.getElementById('bdp-unselect-visible');
    const clearSelection = document.getElementById('bdp-clear-selection');

    if (selectVisible) {
        selectVisible.addEventListener('click', () => {
            selects.forEach(cb => cb.checked = true);
            updateSelected();
        });
    }

    if (unselectVisible) {
        unselectVisible.addEventListener('click', () => {
            selects.forEach(cb => cb.checked = false);
            updateSelected();
        });
    }

    if (clearSelection) {
        clearSelection.addEventListener('click', () => {
            selects.forEach(cb => cb.checked = false);
            updateSelected();
        });
    }

    updateSelected();
});
</script>

<script>
document.addEventListener('DOMContentLoaded', function () {
    // BDP collapsible Find & Filter Products patch
    const filterCard = document.getElementById('product-controls') || document.querySelector('.bdp-products-search-card');
    if (!filterCard || filterCard.dataset.bdpFilterToggleReady === '1') return;
    filterCard.dataset.bdpFilterToggleReady = '1';

    const header = filterCard.querySelector('.bdp-card-header') || filterCard.firstElementChild;
    const storageKey = 'bdp-products-filter-open';
    const toggleBtn = document.createElement('button');
    toggleBtn.type = 'button';
    toggleBtn.className = 'bdp-filter-toggle-btn';

    if (header) {
        header.style.display = 'flex';
        header.style.alignItems = 'flex-start';
        header.style.justifyContent = 'space-between';
        header.style.gap = '14px';
        header.appendChild(toggleBtn);
    } else {
        filterCard.prepend(toggleBtn);
    }

    function hasActiveFilters() {
        const params = new URLSearchParams(window.location.search);
        const q = (params.get('q') || '').trim();
        const category = (params.get('category') || '').trim();
        const label = (params.get('label') || 'all').trim();
        const status = (params.get('status') || 'all').trim();
        const perPage = (params.get('per_page') || '').trim();
        return !!q || !!category || (label && label !== 'all') || (status && status !== 'all') || (perPage && perPage !== '25');
    }

    function setOpen(open) {
        filterCard.classList.toggle('is-collapsed', !open);
        toggleBtn.textContent = open ? 'Hide Find & Filter Products' : 'Find & Filter Products';
        toggleBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
        localStorage.setItem(storageKey, open ? '1' : '0');
    }

    const saved = localStorage.getItem(storageKey);
    const defaultOpen = saved === '1' || (saved === null && hasActiveFilters());
    setOpen(defaultOpen);

    toggleBtn.addEventListener('click', function () {
        setOpen(filterCard.classList.contains('is-collapsed'));
    });
});
</script>

<script id="bdpSafeSeoCsvImportPostScript">
(function () {
    function bdpReady(fn) {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', fn);
        } else {
            fn();
        }
    }

    bdpReady(function () {
        var importBtn = document.getElementById('bdpSubmitSeoCsvImportBtn');
        var fileInput = document.getElementById('bdpSeoCsvFileInputAlways');

        if (importBtn && fileInput && !importBtn.dataset.bdpSafeImportBound) {
            importBtn.dataset.bdpSafeImportBound = '1';
            importBtn.addEventListener('click', function () {
                if (!fileInput.files || !fileInput.files.length) {
                    alert('Please choose the optimized SEO CSV file first.');
                    return;
                }

                var form = document.createElement('form');
                form.method = 'POST';
                form.action = "<?php echo e(route('bdp.bulk.optimization.import')); ?>";
                form.enctype = 'multipart/form-data';
                form.style.display = 'none';

                var csrf = document.createElement('input');
                csrf.type = 'hidden';
                csrf.name = '_token';
                csrf.value = "<?php echo e(csrf_token()); ?>";
                form.appendChild(csrf);

                document.body.appendChild(form);
                form.appendChild(fileInput);
                form.submit();
            });
        }
    });
})();
</script>
<?php $__env->stopSection(); ?>

<!-- BDP_SEO_IMPORT_BUTTON_JS_FIX_START -->
<script>
(function () {
    if (window.__bdpSeoImportButtonFixLoaded) return;
    window.__bdpSeoImportButtonFixLoaded = true;

    var importUrl = <?php echo json_encode(route('bdp.bulk.optimization.import'), 15, 512) ?>;
    var csrf = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || <?php echo json_encode(csrf_token(), 15, 512) ?>;

    function looksLikeSeoImportButton(el) {
        if (!el) return false;
        var text = ((el.textContent || el.value || '') + '').trim().toLowerCase();
        return text === 'import now' || text.indexOf('import optimized seo csv') !== -1;
    }

    function findFileInput(button) {
        var scope = button.closest('.bdp-card, .bdp-bulk-card, .bdp-actions-bar, .bdp-toolbar, .bdp-section, form, div') || document;
        var input = scope.querySelector('input[type="file"]');
        if (input) return input;

        input = document.querySelector('input[type="file"][name="csv_file"], input[type="file"][name="file"], input[type="file"][name="seo_csv"], input[type="file"]');
        return input;
    }

    document.addEventListener('click', function (event) {
        var button = event.target.closest('button, input[type="submit"], input[type="button"], a');
        if (!looksLikeSeoImportButton(button)) return;

        var fileInput = findFileInput(button);
        if (!fileInput || !fileInput.files || !fileInput.files.length) {
            alert('Please choose the optimized SEO CSV file first.');
            event.preventDefault();
            event.stopPropagation();
            return false;
        }

        event.preventDefault();
        event.stopPropagation();

        var originalText = button.textContent || button.value || 'Import Now';
        if ('disabled' in button) button.disabled = true;
        if (button.tagName.toLowerCase() === 'input') {
            button.value = 'Importing...';
        } else {
            button.textContent = 'Importing...';
        }

        var formData = new FormData();
        formData.append('_token', csrf);
        formData.append('csv_file', fileInput.files[0]);
        formData.append('file', fileInput.files[0]);
        formData.append('seo_csv', fileInput.files[0]);

        fetch(importUrl, {
            method: 'POST',
            body: formData,
            credentials: 'same-origin',
            headers: {
                'X-CSRF-TOKEN': csrf,
                'X-Requested-With': 'XMLHttpRequest'
            }
        }).then(function (response) {
            if (response.redirected) {
                window.location.href = response.url;
                return null;
            }
            return response.text().then(function (body) {
                if (!response.ok) {
                    throw new Error(body || ('Import failed with HTTP ' + response.status));
                }
                window.location.reload();
            });
        }).catch(function (error) {
            console.error(error);
            alert('Import failed. Please check the Laravel log for details.');
            if ('disabled' in button) button.disabled = false;
            if (button.tagName.toLowerCase() === 'input') {
                button.value = originalText;
            } else {
                button.textContent = originalText;
            }
        });

        return false;
    }, true);
})();
</script>
<!-- BDP_SEO_IMPORT_BUTTON_JS_FIX_END -->


<script>
/* BDP_SELECTED_ACTION_FALLBACK_START */
document.addEventListener('click', function (event) {
    const btn = event.target.closest('button[form="bdp-products-form"][formaction]');
    if (!btn) return;

    const form = document.getElementById('bdp-products-form');
    if (!form) return;

    // Only help submit buttons from the selected action bar. Avoid duplicate handling elsewhere.
    if (!btn.closest('#bdp-selected-bar')) return;

    event.preventDefault();

    form.action = btn.getAttribute('formaction');
    form.method = (btn.getAttribute('formmethod') || 'post').toLowerCase();

    if (form.requestSubmit) {
        form.requestSubmit();
    } else {
        form.submit();
    }
});
/* BDP_SELECTED_ACTION_FALLBACK_END */
</script>


<style id="bdp-products-layout-hard-repair">
/* HARD REPAIR: restore Products page table/card layout after previous partial patches */

/* Main content should be wide and stable */
body .bdp-app,
body .bdp-main,
body .bdp-content,
body .bdp-page,
body .bdp-page-body,
body main {
    max-width: none !important;
}

/* Product form/card must not shrink into the center */
#bdp-products-form {
    display: block !important;
    width: 100% !important;
    max-width: none !important;
    min-width: 0 !important;
    margin: 0 !important;
    padding: 0 !important;
}

/* Any direct wrapper inside form becomes full width */
#bdp-products-form > * {
    width: 100% !important;
    max-width: none !important;
    min-width: 0 !important;
    box-sizing: border-box !important;
}

/* Product list card */
#bdp-products-form .bdp-card,
#bdp-products-form .bdp-table-card,
#bdp-products-form .bdp-product-list-card,
#bdp-products-form .bdp-list-card {
    display: block !important;
    width: 100% !important;
    max-width: none !important;
    min-width: 0 !important;
    margin-left: 0 !important;
    margin-right: 0 !important;
    overflow: hidden !important;
}

/* Force any flex/grid layout in product list to one clean column */
#bdp-products-form .bdp-card,
#bdp-products-form .bdp-card > div,
#bdp-products-form [class*="product"],
#bdp-products-form [class*="Product"] {
    max-width: 100% !important;
}

/* Product list header/tabs should be horizontal above the table, not floating on the side */
#bdp-products-form .bdp-card-header,
#bdp-products-form .bdp-toolbar,
#bdp-products-form .bdp-tabs,
#bdp-products-form .bdp-products-tabs,
#bdp-products-form .bdp-product-tabs,
#bdp-products-form .bdp-status-tabs,
#bdp-products-form [class*="tabs"] {
    width: 100% !important;
    max-width: none !important;
    display: flex !important;
    flex-direction: row !important;
    align-items: center !important;
    justify-content: flex-start !important;
    flex-wrap: wrap !important;
    gap: 8px !important;
    position: static !important;
    float: none !important;
}

/* Fix table scroll wrapper */
#bdp-products-form .bdp-table-wrap,
#bdp-products-form .bdp-table-wrapper,
#bdp-products-form .bdp-table-responsive,
#bdp-products-form .table-responsive,
#bdp-products-form [class*="table-wrap"],
#bdp-products-form [class*="table-wrapper"] {
    display: block !important;
    width: 100% !important;
    max-width: 100% !important;
    overflow-x: auto !important;
    overflow-y: visible !important;
    position: static !important;
    float: none !important;
}

/* If no wrapper class exists, table still expands */
#bdp-products-form table {
    width: 100% !important;
    min-width: 1180px !important;
    max-width: none !important;
    table-layout: auto !important;
    border-collapse: separate !important;
    border-spacing: 0 !important;
    margin: 0 !important;
}

/* Clean table cells */
#bdp-products-form th,
#bdp-products-form td {
    white-space: nowrap !important;
    vertical-align: middle !important;
}

#bdp-products-form th:nth-child(2),
#bdp-products-form td:nth-child(2) {
    white-space: normal !important;
    min-width: 300px !important;
}

#bdp-products-form th {
    background: #f8fafc !important;
    color: #475569 !important;
    font-size: 11px !important;
    text-transform: uppercase !important;
    letter-spacing: .04em !important;
}

/* Pagination/footer should appear below table, full width */
#bdp-products-form nav,
#bdp-products-form .pagination,
#bdp-products-form [class*="pagination"] {
    width: 100% !important;
    display: flex !important;
    justify-content: flex-end !important;
    align-items: center !important;
    flex-wrap: wrap !important;
    gap: 6px !important;
    position: static !important;
    float: none !important;
}

/* Fix older patch damage: remove side-floating controls */
#bdp-products-form button,
#bdp-products-form a {
    position: static !important;
}

#bdp-products-form .bdp-btn {
    white-space: nowrap !important;
}

/* Selection toolbar */
.bdp-selected-bar {
    width: 100% !important;
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    flex-wrap: wrap !important;
    gap: 12px !important;
    border-radius: 14px !important;
    padding: 14px 16px !important;
}

.bdp-selected-actions {
    display: flex !important;
    flex-wrap: wrap !important;
    align-items: center !important;
    justify-content: flex-end !important;
    gap: 10px !important;
    margin-left: auto !important;
}

/* Hide any duplicate always-visible SEO workflow card on Products page */
#bdp-products-form + .bdp-card:has(#bdpExportSelectedSeoCsvBtn),
.bdp-card:has(> div > h3):has(#bdpExportSelectedSeoCsvBtn) {
    display: none !important;
}

/* General visual polish */
.bdp-products-search-card {
    margin-bottom: 22px !important;
}

.bdp-card {
    border-radius: 18px !important;
}

@media (max-width: 1200px) {
    #bdp-products-form table {
        min-width: 1050px !important;
    }

    .bdp-selected-actions {
        justify-content: flex-start !important;
        margin-left: 0 !important;
        width: 100% !important;
    }
}
</style>

<script id="bdp-products-layout-hard-repair-js">
(function () {
    function selectedProductIds() {
        return Array.prototype.slice.call(document.querySelectorAll('#bdp-products-form input[name="products[]"]:checked'))
            .map(function (el) { return el.value; })
            .filter(Boolean);
    }

    document.addEventListener('click', function (event) {
        var btn = event.target.closest('#bdpExportSelectedSeoCsvBtn');
        if (!btn) return;

        event.preventDefault();
        event.stopPropagation();

        var url = btn.getAttribute('data-export-url');
        if (!url) return;

        var ids = selectedProductIds();
        var params = new URLSearchParams();

        ids.forEach(function (id) {
            params.append('products[]', id);
        });

        window.location.href = ids.length
            ? url + (url.indexOf('?') === -1 ? '?' : '&') + params.toString()
            : url;
    });
})();
</script>



<style id="bdp-hide-empty-selected-toolbar-css">
/* Hide selected action bar until at least one product checkbox is selected */
#bdp-selected-bar[data-selected-count="0"],
#bdp-selected-bar.bdp-no-selection {
    display: none !important;
}
</style>

<script id="bdp-hide-empty-selected-toolbar-js">
(function () {
    function getProductCheckboxes() {
        return Array.prototype.slice.call(
            document.querySelectorAll('#bdp-products-form input[name="products[]"], input[name="products[]"]')
        );
    }

    function updateSelectedToolbar() {
        var bar = document.getElementById('bdp-selected-bar');
        if (!bar) return;

        var checkboxes = getProductCheckboxes();
        var selected = checkboxes.filter(function (el) { return el.checked; }).length;

        bar.setAttribute('data-selected-count', String(selected));

        if (selected > 0) {
            bar.classList.remove('bdp-no-selection');
            bar.style.display = '';
        } else {
            bar.classList.add('bdp-no-selection');
            bar.style.display = 'none';
        }

        var countEl = document.getElementById('bdp-selected-count');
        if (countEl) {
            countEl.textContent = String(selected);
        }
    }

    document.addEventListener('change', function (event) {
        if (
            event.target.matches('input[name="products[]"]') ||
            event.target.matches('input[type="checkbox"]')
        ) {
            setTimeout(updateSelectedToolbar, 0);
        }
    });

    document.addEventListener('click', function (event) {
        if (
            event.target.closest('#bdp-clear-selection') ||
            event.target.closest('[data-clear-selection]') ||
            event.target.closest('button') && /clear/i.test(event.target.closest('button').textContent || '')
        ) {
            setTimeout(updateSelectedToolbar, 30);
        }
    });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', updateSelectedToolbar);
    } else {
        updateSelectedToolbar();
    }

    window.addEventListener('pageshow', updateSelectedToolbar);
})();
</script>



<style id="bdp-seo-optimized-badge-css">
.bdp-seo-optimized-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    width: fit-content;
    margin-top: 5px;
    padding: 3px 8px;
    border-radius: 999px;
    background: #dcfce7;
    border: 1px solid #bbf7d0;
    color: #166534;
    font-size: 11px;
    font-weight: 800;
    line-height: 1.2;
}
.bdp-seo-optimized-badge::before {
    content: "✓";
    font-weight: 900;
}
</style>

<?php echo $__env->make('balenco-data-pilot.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/1556810.cloudwaysapps.com/rgxpgjudaw/public_html/resources/views/balenco-data-pilot/products.blade.php ENDPATH**/ ?>