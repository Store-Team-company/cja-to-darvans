<?php $__env->startSection('title', 'Edit Product | Balenco Data Pilot'); ?>




<?php
    $bdpAiPromptDefaults = [
        'ai_short_words' => '40-60',
        'ai_long_words' => '180-230',
        'ai_meta_chars' => '150-160',
        'ai_tags_count' => '6',
        'ai_default_buyer_intent' => 'Everyday wear',
    ];

    try {
        if (class_exists(\App\Models\BdpSetting::class)) {
            foreach ($bdpAiPromptDefaults as $bdpAiKey => $bdpAiDefault) {
                if (method_exists(\App\Models\BdpSetting::class, 'getValue')) {
                    $bdpAiPromptDefaults[$bdpAiKey] = \App\Models\BdpSetting::getValue($bdpAiKey, $bdpAiDefault);
                } elseif (method_exists(\App\Models\BdpSetting::class, 'get')) {
                    $bdpAiPromptDefaults[$bdpAiKey] = \App\Models\BdpSetting::get($bdpAiKey, $bdpAiDefault);
                } else {
                    $bdpAiPromptDefaults[$bdpAiKey] = optional(\App\Models\BdpSetting::query()->where('key', $bdpAiKey)->first())->value ?? $bdpAiDefault;
                }
            }
        }
    } catch (\Throwable $e) {}
?>


<?php $__env->startSection('content'); ?>
<?php
    $variations = $product->variations ?? collect();
    $totalInventory = $variations->sum('quantity');
    $inStockCount = $variations->where('stock_status', 'in_stock')->count();
    $variationColors = $variations->pluck('color')->filter()->unique()->values();
    $productShippingDetails = $product->cj_shipping_details ? json_decode($product->cj_shipping_details, true) : [];
    $mainImage = old('featured_image', $product->featured_image) ?: ($variations->pluck('image')->filter()->first());
    $galleryImages = collect(explode(',', (string) old('gallery_images', $product->gallery_images)))->map(fn($i) => trim($i))->filter()->values();
    $isSynced = !empty($product->balenco_product_id) || !empty($product->shofy_product_id) || in_array($product->balenco_sync_status, ['synced', 'updated'], true);
    $syncStatus = $product->balenco_sync_status ?: ($isSynced ? 'synced' : 'not_synced');
    $seoChecks = [
        'Title' => filled($product->name),
        'Slug' => filled($product->slug),
        'Short description' => filled($product->short_description),
        'Long description' => filled($product->content),
        'SEO title' => filled($product->seo_title),
        'SEO description' => filled($product->seo_description),
        'Category' => filled($product->categories),
        'Final price' => $product->price !== null,
        'Variation images' => $variations->count() === 0 ? false : $variations->whereNotNull('image')->count() > 0,
        'Stock' => $totalInventory > 0,
    ];
    $readyCount = collect($seoChecks)->filter()->count();
    $readyPercent = count($seoChecks) ? round(($readyCount / count($seoChecks)) * 100) : 0;
    $parentGalleryImageSyncEnabled = (bool) config('balenco-data-pilot.parent_gallery_image_sync', false);
    $pushParentFeaturedImage = (bool) config('balenco-data-pilot.push_parent_featured_image', false);
    $pushParentGalleryImages = (bool) config('balenco-data-pilot.push_parent_gallery_images', false);
?>

<style>
    .bdp-edit-shell{display:flex;flex-direction:column;gap:18px}.bdp-edit-head{display:flex;justify-content:space-between;align-items:flex-start;gap:18px}.bdp-edit-head-actions{display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end}.bdp-edit-layout{display:grid;grid-template-columns:minmax(0,1fr) 360px;gap:18px;align-items:start}.bdp-edit-main{display:flex;flex-direction:column;gap:18px}.bdp-edit-side{position:sticky;top:96px;display:flex;flex-direction:column;gap:18px}.bdp-section-tabs{display:flex;gap:8px;flex-wrap:wrap}.bdp-section-tabs a{border:1px solid var(--bdp-border);background:#fff;border-radius:999px;padding:8px 12px;text-decoration:none;font-weight:800;color:#334155;font-size:12px}.bdp-section-tabs a:hover{background:#f8fafc}.bdp-editor-card{padding:22px}.bdp-field-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.bdp-field-grid.three{grid-template-columns:repeat(3,minmax(0,1fr))}.bdp-field-span{grid-column:1/-1}.bdp-form-note{background:#fff7ed;border:1px solid #fed7aa;color:#9a3412;padding:12px 14px;border-radius:14px;font-size:13px;line-height:1.45}.bdp-product-preview{display:flex;gap:14px;align-items:flex-start}.bdp-preview-img{width:96px;height:96px;border-radius:18px;object-fit:cover;background:#f8fafc;border:1px solid var(--bdp-border);flex:0 0 auto}.bdp-preview-title{font-size:16px;font-weight:900;line-height:1.25;margin:0 0 8px}.bdp-mini-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}.bdp-mini-stat{background:#f8fafc;border:1px solid #edf1f7;border-radius:14px;padding:11px}.bdp-mini-stat span{display:block;font-size:11px;color:#64748b;font-weight:800;text-transform:uppercase;letter-spacing:.02em}.bdp-mini-stat strong{display:block;margin-top:4px;font-size:15px;color:#0f172a}.bdp-progress-wrap{height:9px;background:#e5e7eb;border-radius:999px;overflow:hidden}.bdp-progress-bar{height:100%;background:linear-gradient(90deg,#16a34a,#22c55e);border-radius:999px}.bdp-checklist{display:flex;flex-direction:column;gap:8px;margin-top:14px}.bdp-check-item{display:flex;align-items:center;justify-content:space-between;gap:10px;border:1px solid #edf1f7;background:#fff;border-radius:12px;padding:9px 10px;font-size:13px}.bdp-check-item .left{display:flex;align-items:center;gap:8px}.bdp-check-dot{width:18px;height:18px;border-radius:999px;display:grid;place-items:center;font-size:11px;font-weight:900}.bdp-check-dot.ok{background:#dcfce7;color:#166534}.bdp-check-dot.no{background:#f1f5f9;color:#94a3b8}.bdp-gallery-grid{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:10px}.bdp-gallery-grid img{width:100%;aspect-ratio:1/1;object-fit:cover;border-radius:14px;border:1px solid var(--bdp-border);background:#f8fafc}.bdp-variation-table th,.bdp-variation-table td{white-space:nowrap}.bdp-variation-table .var-image-cell{min-width:240px}.bdp-var-img-wrap{display:flex;gap:10px;align-items:flex-start}.bdp-var-img{width:54px;height:54px;border-radius:12px;object-fit:cover;border:1px solid var(--bdp-border);background:#f8fafc;flex:0 0 auto}.bdp-var-image-input{min-width:160px}.bdp-color-chip{display:inline-flex;align-items:center;gap:6px;background:#f8fafc;border:1px solid #edf1f7;border-radius:999px;padding:5px 9px;font-size:12px;font-weight:800;color:#334155}.bdp-action-sticky{position:sticky;bottom:16px;z-index:8;background:rgba(255,255,255,.9);backdrop-filter:blur(12px);border:1px solid var(--bdp-border);box-shadow:var(--bdp-shadow);border-radius:18px;padding:12px 14px;display:flex;align-items:center;justify-content:space-between;gap:14px}.bdp-action-sticky .bdp-selected-actions{display:flex;gap:10px;flex-wrap:wrap}.bdp-source-list{display:flex;flex-direction:column;gap:10px}.bdp-source-row{display:flex;justify-content:space-between;gap:12px;padding-bottom:10px;border-bottom:1px solid #edf1f7}.bdp-source-row:last-child{border-bottom:0;padding-bottom:0}.bdp-source-row span{color:#64748b}.bdp-source-row strong{text-align:right;color:#0f172a}.bdp-image-status{display:flex;flex-direction:column;gap:8px}.bdp-image-status .bdp-pill{justify-content:center}.bdp-side-actions{display:grid;gap:10px}.bdp-side-actions .bdp-btn{width:100%}.bdp-copy-input{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-size:12px;color:#475569}.bdp-side-collapsible{border:1px solid #edf1f7;border-radius:14px;overflow:hidden}.bdp-side-collapsible summary{list-style:none;cursor:pointer;padding:12px 14px;font-weight:900;display:flex;align-items:center;justify-content:space-between}.bdp-side-collapsible summary::-webkit-details-marker{display:none}.bdp-side-collapsible .body{padding:0 14px 14px}.bdp-side-collapsible summary:after{content:'+';font-weight:900;color:#64748b}.bdp-side-collapsible[open] summary:after{content:'−'}.bdp-image-mode-box{border:1px solid #dbeafe;background:linear-gradient(180deg,#eff6ff,#fff);border-radius:16px;padding:14px;margin-bottom:14px}.bdp-image-mode-box .mode-head{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;margin-bottom:10px}.bdp-image-mode-box h3{margin:0;font-size:14px;font-weight:900;color:#0f172a}.bdp-image-mode-box p{margin:4px 0 0;color:#64748b;font-size:12px;line-height:1.45}.bdp-image-mode-box select{max-width:360px}@media(max-width:1200px){.bdp-edit-layout{grid-template-columns:1fr}.bdp-edit-side{position:static}.bdp-gallery-grid{grid-template-columns:repeat(4,minmax(0,1fr))}.bdp-edit-head{flex-direction:column}.bdp-edit-head-actions{justify-content:flex-start}}.bdp-variation-bulk-price{border:1px solid #dbeafe;background:linear-gradient(180deg,#eff6ff,#fff);border-radius:16px;padding:14px;margin-bottom:14px}.bdp-variation-bulk-price .bulk-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:12px}.bdp-variation-bulk-price h3{margin:0;font-size:14px;font-weight:900;color:#0f172a}.bdp-variation-bulk-price p{margin:4px 0 0;color:#64748b;font-size:12px;line-height:1.45}.bdp-variation-bulk-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;align-items:end}.bdp-variation-bulk-grid label{font-size:11px}.bdp-variation-bulk-actions{display:flex;gap:8px;flex-wrap:wrap}.bdp-image-manual-notice{border:1px dashed #bfdbfe;background:#f8fbff;border-radius:16px;padding:16px;display:flex;align-items:flex-start;justify-content:space-between;gap:14px;margin-bottom:18px}.bdp-image-manual-notice h3{margin:0 0 4px;font-size:15px;font-weight:900}.bdp-image-manual-notice p{margin:0;color:#64748b;font-size:13px;line-height:1.45}.bdp-mini-settings-list{display:grid;gap:10px}.bdp-mini-setting-row{display:flex;align-items:center;justify-content:space-between;gap:12px;border:1px solid #edf1f7;background:#fff;border-radius:12px;padding:10px 12px}.bdp-mini-setting-row span{font-size:12px;color:#64748b}.bdp-mini-setting-row strong{font-size:13px;color:#0f172a}@media(max-width:900px){.bdp-variation-bulk-grid{grid-template-columns:1fr 1fr}.bdp-image-manual-notice{flex-direction:column}}@media(max-width:760px){.bdp-field-grid,.bdp-field-grid.three{grid-template-columns:1fr}.bdp-gallery-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.bdp-action-sticky{align-items:flex-start;flex-direction:column}.bdp-product-preview{flex-direction:column}.bdp-mini-grid{grid-template-columns:1fr}.bdp-variation-bulk-grid{grid-template-columns:1fr}}


/* BDP AI SEO Tools Patch */
.bdp-ai-tools-card{border:1px solid #dbeafe;background:linear-gradient(180deg,#eff6ff,#fff);}
.bdp-ai-tools-card .bdp-card-title{display:flex;align-items:center;gap:8px}
.bdp-ai-tool-actions{display:grid;grid-template-columns:1fr;gap:8px;margin-top:12px}
.bdp-ai-output{width:100%;min-height:150px;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-size:12px;line-height:1.5;resize:vertical}
.bdp-ai-prompt-box{display:none;margin-top:10px}
.bdp-ai-prompt-box.is-open{display:block}
.bdp-ai-help{font-size:12px;color:#64748b;line-height:1.45;margin-top:8px}
.bdp-ai-mini-status{display:none;border-radius:12px;padding:8px 10px;font-size:12px;font-weight:800;margin-top:10px}
.bdp-ai-mini-status.ok{display:block;background:#dcfce7;color:#166534;border:1px solid #bbf7d0}
.bdp-ai-mini-status.warn{display:block;background:#fff7ed;color:#9a3412;border:1px solid #fed7aa}
.bdp-ai-mini-status.err{display:block;background:#fee2e2;color:#991b1b;border:1px solid #fecaca}



/* BDP Price Sale UI Patch */
.bdp-price-help{font-size:12px;color:#64748b;line-height:1.45;margin-top:6px}
.bdp-price-callout{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;border:1px solid #dbeafe;background:#eff6ff;border-radius:14px;padding:12px 14px;margin-bottom:14px;color:#1e3a8a;font-size:13px;line-height:1.45}
.bdp-price-callout strong{color:#172554}.bdp-sale-input{border-color:#fed7aa!important;background:#fff7ed!important}.bdp-price-input{font-weight:800}.bdp-variation-table .price-col{min-width:105px}.bdp-variation-table .sale-col{min-width:120px}



/* BDP AI Prompt Settings Patch */
.bdp-ai-settings{margin:12px 0;padding:12px;border:1px solid #dbeafe;background:rgba(255,255,255,.72);border-radius:14px;display:grid;gap:10px}
.bdp-ai-settings-title{display:flex;align-items:center;justify-content:space-between;gap:10px;font-weight:900;font-size:12px;color:#0f172a}
.bdp-ai-settings-grid{display:grid;grid-template-columns:1fr 1fr;gap:9px}
.bdp-ai-settings-grid label{display:block;font-size:10px;font-weight:900;color:#64748b;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px}
.bdp-ai-settings-grid input,.bdp-ai-settings-grid select{width:100%;border:1px solid var(--bdp-border,#dbe3ef);border-radius:10px;padding:8px 9px;font-size:12px;background:#fff;color:#0f172a}
.bdp-ai-rule-note{font-size:11px;line-height:1.45;color:#475569;background:#f8fafc;border:1px dashed #cbd5e1;border-radius:12px;padding:9px 10px}
.bdp-ai-rule-note strong{color:#0f172a}
@media(max-width:760px){.bdp-ai-settings-grid{grid-template-columns:1fr}}


.bdp-review-toolbar{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:12px 0}.bdp-review-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.bdp-review-card{border:1px solid #edf1f7;background:#fff;border-radius:16px;padding:13px;display:flex;flex-direction:column;gap:10px}.bdp-review-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px}.bdp-stars{color:#f59e0b;font-weight:900;letter-spacing:.02em}.bdp-review-meta{font-size:12px;color:#64748b}.bdp-review-text{font-size:13px;line-height:1.55;color:#334155;margin:0}.bdp-review-images{display:flex;gap:8px;flex-wrap:wrap}.bdp-review-images img{width:58px;height:58px;object-fit:cover;border-radius:10px;border:1px solid #edf1f7;background:#f8fafc}.bdp-review-empty{border:1px dashed #cbd5e1;background:#f8fafc;border-radius:16px;padding:18px;color:#64748b;font-size:13px}.bdp-review-fetch-box{background:#f8fafc;border:1px solid #edf1f7;border-radius:16px;padding:12px 14px;display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap}@media(max-width:900px){.bdp-review-grid{grid-template-columns:1fr}}



/* BDP sticky edit section tabs */
.bdp-section-tabs{
    position: sticky;
    top: 74px;
    z-index: 25;
    background: rgba(247,248,251,.92);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    padding: 10px 0;
    margin: -4px 0 2px;
    border-bottom: 1px solid rgba(226,232,240,.8);
}
.bdp-section-tabs a{
    transition: all .16s ease;
}
.bdp-section-tabs a:hover{
    transform: translateY(-1px);
}
.bdp-section-tabs a.is-active{
    background:#0f1f3d;
    border-color:#0f1f3d;
    color:#fff;
    box-shadow: 0 8px 18px rgba(15,31,61,.12);
}
@media(max-width:760px){
    .bdp-section-tabs{
        top: 58px;
        overflow-x:auto;
        flex-wrap:nowrap;
        scrollbar-width:none;
    }
    .bdp-section-tabs::-webkit-scrollbar{display:none;}
    .bdp-section-tabs a{white-space:nowrap;}
}


    .bdp-price-variation-sync-box{margin-top:14px;border:1px solid #dbeafe;background:#eff6ff;border-radius:16px;padding:14px;display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap}.bdp-price-variation-sync-box .sync-copy{display:flex;flex-direction:column;gap:4px}.bdp-price-variation-sync-box strong{color:#0f172a}.bdp-price-variation-sync-box small{color:#64748b;line-height:1.45}.bdp-price-variation-sync-actions{display:flex;align-items:center;gap:10px;flex-wrap:wrap}.bdp-price-variation-sync-actions label{display:flex;align-items:center;gap:8px;font-weight:800;color:#334155;margin:0}.bdp-price-sync-result{font-size:12px;font-weight:800;color:#166534;display:none}



/* BDP cleanup: images are managed in Settings/Balenco, hide image section on edit page */
#images { display: none !important; }

/* BDP cleanup: collapse variations section by default */
#variations .bdp-variations-body { display: none; }
#variations.bdp-variations-open .bdp-variations-body { display: block; }
.bdp-variation-toggle-btn {
    border: 1px solid var(--bdp-border);
    background: #fff;
    color: var(--bdp-navy);
    border-radius: 12px;
    padding: 8px 12px;
    font-weight: 800;
    cursor: pointer;
}
.bdp-variation-toggle-btn:hover { background: #f8fafc; }


    .bdp-edit-image-download-actions{display:inline-flex;gap:8px;align-items:center;flex-wrap:wrap}
    .bdp-edit-image-download-actions .bdp-btn{white-space:nowrap}
    .bdp-btn.image-zip{background:#fff;border:1px solid #dbe4f0;color:#0f1f3d}
    .bdp-btn.image-zip:hover{background:#f8fafc;border-color:#ff5a1f;color:#ff5a1f}

</style>

<div class="bdp-edit-shell">
    <div class="bdp-edit-head">
        <div class="bdp-page-title">
            <h1>Edit Product</h1>
            <p>Clean product content, SEO, pricing, images, and variations before syncing to Balenco.</p>
        </div>
        <div class="bdp-edit-head-actions">
            <a href="<?php echo e(route('bdp.products')); ?>" class="bdp-btn light">Back to Products</a>
            <?php if($product->source === 'cj_api'): ?>
                <button class="bdp-btn light" type="submit" form="bdp-refresh-cj-form">Refresh CJ Data</button>
            <?php endif; ?>
            
<?php
    $bdpGalleryZipUrl = null;
    $bdpAllZipUrl = null;

    $bdpGalleryRouteNames = [
        'bdp.products.images.gallery_zip',
        'bdp.products.images.featured_gallery_zip',
        'bdp.products.images.featured-gallery',
        'bdp.products.images.gallery',
        'bdp.products.gallery.zip',
    ];

    $bdpAllRouteNames = [
        'bdp.products.images.all_zip',
        'bdp.products.images.all-zip',
        'bdp.products.images.zip',
        'bdp.products.images.download',
        'bdp.products.download.images',
        'bdp.products.download-images',
        'bdp.product.images.zip',
    ];

    foreach ($bdpGalleryRouteNames as $bdpRouteName) {
        if (\Illuminate\Support\Facades\Route::has($bdpRouteName)) {
            $bdpGalleryZipUrl = route($bdpRouteName, $product);
            break;
        }
    }

    foreach ($bdpAllRouteNames as $bdpRouteName) {
        if (\Illuminate\Support\Facades\Route::has($bdpRouteName)) {
            $bdpAllZipUrl = route($bdpRouteName, $product);
            break;
        }
    }
?>
<?php if($bdpGalleryZipUrl || $bdpAllZipUrl): ?>
    <span class="bdp-edit-image-download-actions">
        <?php if($bdpGalleryZipUrl): ?>
            <a class="bdp-btn image-zip" href="<?php echo e($bdpGalleryZipUrl); ?>">Gallery ZIP</a>
        <?php endif; ?>
        <?php if($bdpAllZipUrl): ?>
            <a class="bdp-btn image-zip" href="<?php echo e($bdpAllZipUrl); ?>">All Images ZIP</a>
        <?php endif; ?>
    </span>
<?php endif; ?>

<button class="bdp-btn orange" type="submit" form="bdp-edit-form">Save Product</button>
        </div>
    </div>

    <div class="bdp-section-tabs">
        <a href="#content">Content</a>
        <a href="#seo">SEO</a>
        <a href="#pricing">Pricing</a>
        <a href="#reviews">Reviews</a>
        <a href="#variations">Variations</a>
    </div>

    <?php if($product->source === 'cj_api'): ?>
        <form id="bdp-refresh-cj-form" method="post" action="<?php echo e(route('bdp.products.refresh.cj', $product)); ?>" style="display:none">
            <?php echo csrf_field(); ?>
        <input type="hidden" name="redirect_after_sync" id="bdp-redirect-after-sync" value="0">
            <input type="hidden" name="country_code" value="US">
            <input type="hidden" name="quantity" value="1">
        </form>
    <?php endif; ?>

    <form id="bdp-sync-product-form" method="post" action="<?php echo e(route('bdp.push')); ?>" style="display:none">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="products[]" value="<?php echo e($product->id); ?>">
        <input type="hidden" name="sync_status" value="draft">
        <input type="hidden" name="copy_variation_images" value="1">
        
    </form>

    <form id="bdp-fetch-cj-reviews-form" method="post" action="<?php echo e(route('bdp.products.reviews.fetch.cj', $product)); ?>" style="display:none">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="max_reviews" value="12">
    </form>

    <form id="bdp-edit-form" method="post" action="<?php echo e(route('bdp.products.update', $product)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="bdp-edit-layout">
            <div class="bdp-edit-main">
                <div class="bdp-card bdp-editor-card" id="content">
                    <div class="bdp-card-header">
                        <div>
                            <h2 class="bdp-card-title">Product Content</h2>
                            <p class="bdp-card-subtitle">Buyer-facing title, slug, descriptions, categories, and tags.</p>
                        </div>
                        <span class="bdp-pill <?php echo e(filled($product->name) && filled($product->short_description) ? 'success' : 'warning'); ?>"><?php echo e(filled($product->short_description) ? 'Content started' : 'Needs content'); ?></span>
                    </div>

                    <div class="bdp-field-grid">
                        <div class="bdp-field-span">
                            <label>Product title</label>
                            <input name="name" value="<?php echo e(old('name', $product->name)); ?>" placeholder="SEO-friendly product title">
                        </div>
                        <div>
                            <label>URL slug</label>
                            <input name="slug" value="<?php echo e(old('slug', $product->slug)); ?>" placeholder="clean-product-url-slug">
                        </div>
                        <div>
                            <label>SKU</label>
                            <input name="sku" value="<?php echo e(old('sku', $product->sku)); ?>" placeholder="CJNS...">
                        </div>
                        <div>
                            <label>Categories</label>
                            <input name="categories" value="<?php echo e(old('categories', $product->categories)); ?>" placeholder="Shoes > Sneakers">
                            <div class="bdp-input-help">Use Category Mapping before final sync where possible.</div>
                        </div>
                        <div>
                            <label>Tags</label>
                            <input name="tags" value="<?php echo e(old('tags', $product->tags)); ?>" placeholder="women shoes, sneakers, platform sneakers">
                        </div>
                        <div class="bdp-field-span">
                            <label>Short description</label>
                            <textarea name="short_description" placeholder="Short benefit-focused product summary" class="bdp-rich-editor" data-editor="rich"><?php echo e(old('short_description', $product->short_description)); ?></textarea>
                        </div>
                        <div class="bdp-field-span">
                            <label>Long description / product content</label>
                            <textarea name="content" style="min-height:260px" placeholder="Full product details, features, fit notes, materials, styling, and buyer guidance" class="bdp-rich-editor" data-editor="rich"><?php echo e(old('content', $product->content)); ?></textarea>
                        </div>
                    </div>
                </div>

                <div class="bdp-card bdp-editor-card" id="seo">
                    <div class="bdp-card-header">
                        <div>
                            <h2 class="bdp-card-title">SEO Details</h2>
                            <p class="bdp-card-subtitle">Prepare Google-friendly product metadata before publishing.</p>
                        </div>
                    </div>
                    <div class="bdp-field-grid">
                        <div>
                            <label>Focus keyword</label>
                            <input name="focus_keyword" value="<?php echo e(old('focus_keyword', $product->focus_keyword)); ?>" placeholder="women platform casual sneakers">
                        </div>
                        <div>
                            <label>SEO title</label>
                            <input name="seo_title" value="<?php echo e(old('seo_title', $product->seo_title)); ?>" placeholder="Product keyword | Balenco">
                            <div class="bdp-input-help">Recommended: clear, buyer-friendly, under 60 characters where possible.</div>
                        </div>
                        <div class="bdp-field-span">
                            <label>SEO description</label>
                            <textarea name="seo_description" placeholder="Short meta description for search results"><?php echo e(old('seo_description', $product->seo_description)); ?></textarea>
                            <div class="bdp-input-help">Recommended: around 150–160 characters, natural and benefit-focused.</div>
                        </div>
                    </div>
                </div>

                <div class="bdp-card bdp-editor-card" id="pricing">
                    <div class="bdp-card-header">
                        <div>
                            <h2 class="bdp-card-title">Pricing & CJ Cost Summary</h2>
                            <p class="bdp-card-subtitle">Review landed cost, selling price, shipping, and stock before syncing.</p>
                        </div>
                        <?php if($product->source === 'cj_api'): ?>
                            <button class="bdp-btn light" type="submit" form="bdp-refresh-cj-form">Refresh CJ Inventory + Shipping</button>
                        <?php endif; ?>
                    </div>
                    <div class="bdp-price-callout"><div><strong>Product regular price and discounted price</strong><br>Use Selling price as the normal Balenco price. Use Discounted / sale price only when you want a visible sale price. Leave sale price empty when there is no discount.</div></div>
                    <div class="bdp-field-grid three">
                        <div>
                            <label>Product selling price</label>
                            <input class="bdp-price-input" name="price" value="<?php echo e(old('price', $product->price)); ?>" placeholder="39.99">
                            <div class="bdp-price-help">Regular product price shown when no sale price is used.</div>
                        </div>
                        <div>
                            <label>Discounted / sale price</label>
                            <input class="bdp-sale-input" name="sale_price" value="<?php echo e(old('sale_price', $product->sale_price)); ?>" placeholder="Optional sale price">
                            <div class="bdp-price-help">Optional. If filled, Balenco/Shofy should show this as the discounted price.</div>
                        </div>
                        <div>
                            <label>Total stock</label>
                            <input value="<?php echo e(number_format((int) $totalInventory)); ?>" readonly>
                        </div>
                        <div>
                            <label>Product shipping fee</label>
                            <input value="<?php echo e($product->cj_shipping_fee !== null ? '$'.number_format((float)$product->cj_shipping_fee, 2).' '.($product->cj_shipping_country ?: '') : 'Refresh CJ shipping first'); ?>" readonly>
                        </div>
                        <div>
                            <label>Landed cost</label>
                            <input value="<?php echo e($product->landed_cost !== null ? '$'.number_format((float)$product->landed_cost, 2) : '—'); ?>" readonly>
                        </div>
                        <div>
                            <label>Shipping method</label>
                            <input value="<?php echo e($product->cj_shipping_method ?: '—'); ?>" readonly>
                        </div>
                        <div class="bdp-field-span">
                            <label>Shipping debug</label>
                            <input value="<?php echo e(!empty($productShippingDetails['error']) ? \Illuminate\Support\Str::limit($productShippingDetails['error'], 160) : 'No shipping error saved'); ?>" readonly>
                        </div>
                    </div>
                </div>

                <?php if($parentGalleryImageSyncEnabled): ?>
                    <div class="bdp-price-variation-sync-box">
                        <div class="sync-copy">
                            <strong>Update variations from product price</strong>
                            <small>Enter product selling price and discounted/sale price above, then copy them to all variation rows. This only updates fields on this page; click Save Product to store changes.</small>
                            <span class="bdp-price-sync-result" id="bdp-price-sync-result"></span>
                        </div>
                        <div class="bdp-price-variation-sync-actions">
                            <label>
                                <input class="bdp-checkbox" type="checkbox" id="bdp-sync-product-price-to-variations" style="width:auto">
                                Update variation prices
                            </label>
                            <button class="bdp-btn light" type="button" id="bdp-apply-product-price-to-variations" disabled>Update variation prices</button>
                        </div>
                    </div>

                <div class="bdp-card bdp-editor-card" id="images">
                    <div class="bdp-card-header">
                        <div>
                            <h2 class="bdp-card-title">Images</h2>
                            <p class="bdp-card-subtitle">Parent/gallery images are reference fields. Variation images can be copied to Balenco storage during sync.</p>
                        </div>
                    </div>
                    <div class="bdp-image-mode-box">
                        <div class="mode-head">
                            <div>
                                <h3>Parent / Gallery Image Sync Mode</h3>
                                <p>Choose whether Data Pilot should push the parent featured image and gallery, or leave them for manual upload in Balenco/Shofy.</p>
                            </div>
                            <select name="include_parent_images" form="bdp-sync-product-form">
                                <option value="0" <?php if(! $parentGalleryImageSyncEnabled): echo 'selected'; endif; ?>>Manual upload in Balenco/Shofy — recommended</option>
                                <option value="1" <?php if($parentGalleryImageSyncEnabled): echo 'selected'; endif; ?>>Push Data Pilot parent image + gallery during sync</option>
                            </select>
                        </div>
                        <div class="bdp-form-note"><strong>Recommended:</strong> Keep manual mode for final product page gallery so you can upload 5–6 optimized lifestyle/product images in Balenco. Use push mode only when Data Pilot already has clean parent/gallery image URLs and you want them sent automatically.</div>
                    </div>
                    <div class="bdp-form-note"><strong>Variation image note:</strong> Variation/color images are still handled separately. They can be copied to Balenco storage during sync and reused by color across sizes.</div>
                    <div style="height:14px"></div>
                    <div class="bdp-field-grid">
                        <div>
                            <label>Featured image URL</label>
                            <input class="bdp-copy-input" name="featured_image" value="<?php echo e(old('featured_image', $product->featured_image)); ?>" placeholder="https://...">
                        </div>
                        <div>
                            <label>Variation image colors</label>
                            <input value="<?php echo e($variationColors->count() ? $variationColors->implode(', ') : '—'); ?>" readonly>
                        </div>
                        <div class="bdp-field-span">
                            <label>Gallery image URLs, comma separated</label>
                            <textarea class="bdp-copy-input" name="gallery_images" placeholder="https://image-1.jpg, https://image-2.jpg"><?php echo e(old('gallery_images', $product->gallery_images)); ?></textarea>
                        </div>
                    </div>

                    <?php if($galleryImages->isNotEmpty() || $mainImage): ?>
                        <div style="height:16px"></div>
                        <div class="bdp-gallery-grid">
                            <?php if($mainImage): ?><img src="<?php echo e($mainImage); ?>" alt="Main image" onerror="this.style.display='none'"><?php endif; ?>
                            <?php $__currentLoopData = $galleryImages->take(11); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img src="<?php echo e($img); ?>" alt="Gallery image" onerror="this.style.display='none'">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>

                                <?php else: ?>
                <div class="bdp-card bdp-editor-card" id="images">
                    <div class="bdp-card-header">
                        <div>
                            <h2 class="bdp-card-title">Images</h2>
                            <p class="bdp-card-subtitle">Parent featured image and gallery are currently managed manually in Balenco/Shofy.</p>
                        </div>
                        <span class="bdp-pill muted">Manual mode</span>
                    </div>
                    <div class="bdp-image-manual-notice">
                        <div>
                            <h3>Parent / gallery image fields are hidden</h3>
                            <p>Global Settings are set to manual upload. This keeps final product page gallery images clean and prevents raw CJ gallery images from replacing optimized Balenco media.</p>
                        </div>
                        <a class="bdp-btn light" href="<?php echo e(route('bdp.settings')); ?>#image-sync">Open Image Settings</a>
                    </div>
                    <?php if($mainImage): ?>
                        <div class="bdp-gallery-grid" style="max-width:110px">
                            <img src="<?php echo e($mainImage); ?>" alt="Reference image" onerror="this.style.display='none'">
                        </div>
                        <div class="bdp-input-help" style="margin-top:8px">Reference image only. It will not be pushed unless enabled in Settings.</div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>


                <div class="bdp-card bdp-editor-card" id="reviews">
                    <?php
                        $bdpReviews = \App\Models\BdpProductReview::where('bdp_product_id', $product->id)
                            ->orderByDesc('score')
                            ->orderByDesc('review_date')
                            ->limit(12)
                            ->get();
                        $approvedReviews = $bdpReviews->where('is_approved', true)->count();
                    ?>
                    <div class="bdp-card-header">
                        <div>
                            <h2 class="bdp-card-title">CJ Product Reviews</h2>
                            <p class="bdp-card-subtitle">Fetch up to 12 high-quality CJ reviews. Only 5-star and 4-star reviews are imported for manual approval.</p>
                        </div>
                        <span class="bdp-pill info"><?php echo e($bdpReviews->count()); ?> imported</span>
                    </div>

                    <div class="bdp-review-fetch-box">
                        <div>
                            <strong>Fetch rule: 5★ first, then 4★ if needed</strong>
                            <div class="bdp-input-help">Reviews are saved inside Data Pilot as pending approval. They are not pushed to Balenco automatically.</div>
                        </div>
                        <button class="bdp-btn orange" type="submit" form="bdp-fetch-cj-reviews-form">Fetch 5★ & 4★ Reviews</button>
                    </div>

                    <div style="height:14px"></div>

                    <?php if($bdpReviews->isEmpty()): ?>
                        <div class="bdp-review-empty">
                            No CJ reviews imported yet. Click <strong>Fetch 5★ & 4★ Reviews</strong> to import up to 12 reviews for this product.
                        </div>
                    <?php else: ?>
                        <div class="bdp-review-toolbar">
                            <span class="bdp-pill success"><?php echo e($approvedReviews); ?> approved</span>
                            <span class="bdp-pill muted"><?php echo e($bdpReviews->count() - $approvedReviews); ?> pending</span>
                            <span class="bdp-pill warning">Push to Balenco later after review table mapping</span>
                        </div>
                        <div class="bdp-review-grid">
                            <?php $__currentLoopData = $bdpReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="bdp-review-card">
                                    <div class="bdp-review-head">
                                        <div>
                                            <div class="bdp-stars"><?php echo e(str_repeat('★', (int) $review->score)); ?><?php echo e(str_repeat('☆', max(0, 5 - (int) $review->score))); ?></div>
                                            <div class="bdp-review-meta">
                                                <?php echo e($review->reviewer_name ?: 'CJ buyer'); ?>

                                                <?php if($review->country_code): ?> · <?php echo e($review->country_code); ?> <?php endif; ?>
                                                <?php if($review->review_date): ?> · <?php echo e($review->review_date->format('Y-m-d')); ?> <?php endif; ?>
                                            </div>
                                        </div>
                                        <span class="bdp-pill <?php echo e($review->is_approved ? 'success' : 'muted'); ?>"><?php echo e($review->is_approved ? 'Approved' : 'Pending'); ?></span>
                                    </div>
                                    <p class="bdp-review-text"><?php echo e(\Illuminate\Support\Str::limit($review->review_text, 260)); ?></p>
                                    <?php if(!empty($review->review_images)): ?>
                                        <div class="bdp-review-images">
                                            <?php $__currentLoopData = array_slice($review->review_images, 0, 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <img src="<?php echo e($img); ?>" alt="Review image" onerror="this.style.display='none'">
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>

<div class="bdp-card bdp-editor-card" id="variations">
                    <div class="bdp-card-header">
                        <div>
                            <h2 class="bdp-card-title">Variations</h2>
                            <p class="bdp-card-subtitle">One image per color is reused across sizes. Review size, price, stock, and default variation.</p>
                        </div>
                        <span class="bdp-pill info"><?php echo e($variations->count()); ?> variations</span>
                    </div>
                    <div class="bdp-variation-bulk-price" id="variation-bulk-pricing">
                        <div class="bulk-head">
                            <div>
                                <h3>Bulk Variation Pricing</h3>
                                <p>Update variation prices quickly. This only changes the fields below — click Save Product to store changes.</p>
                            </div>
                            <span class="bdp-pill info">Client-side helper</span>
                        </div>
                        <div class="bdp-variation-bulk-grid">
                            <div>
                                <label>Selling price</label>
                                <input id="bdp-bulk-variation-selling-price" type="number" step="0.01" min="0" placeholder="e.g. 75.00">
                            </div>
                            <div>
                                <label>Discounted / sale price</label>
                                <input id="bdp-bulk-variation-sale-price" type="number" step="0.01" min="0" placeholder="e.g. 69.99">
                            </div>
                            <div>
                                <label>Apply to</label>
                                <select id="bdp-bulk-variation-target">
                                    <option value="selected">Selected/default variations only</option>
                                    <option value="all">All variations</option>
                                </select>
                            </div>
                            <div class="bdp-variation-bulk-actions">
                                <button class="bdp-btn light" type="button" id="bdp-apply-variation-prices">Apply prices</button>
                                <button class="bdp-btn light" type="button" id="bdp-clear-variation-sale-prices">Clear sale price</button>
                            </div>
                        </div>
                        <div class="bdp-input-help" style="margin-top:8px">Tip: choose selected variations if you only want to price specific colors/sizes. Use All variations when the whole product should have the same price.</div>
                    </div>
                    <div class="bdp-form-note"><strong>Variation image mode:</strong> Data Pilot should save a full local Balenco image URL for variation images after the image bridge copies the image.</div>
                    <div style="height:8px"></div>
                    <div class="bdp-price-callout"><div><strong>Variation discount note:</strong><br>Each variation can now have its own regular selling price and optional discounted/sale price. Leave discounted price empty when there is no sale.</div></div>
                    <div style="height:14px"></div>
                    <div class="bdp-table-wrap">
                        <table class="bdp-table bdp-variation-table">
                            <thead>
                                <tr>
                                    <th>Default</th>
                                    <th>Image</th>
                                    <th>Color</th>
                                    <th>Raw size</th>
                                    <th>US size</th>
                                    <th>CJ cost</th>
                                    <th class="price-col">Selling</th>
                                    <th class="sale-col">Discounted</th>
                                    <th>Qty</th>
                                    <th>CJ inv.</th>
                                    <th>Stock</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $variations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><input type="checkbox" name="variations[<?php echo e($variation->id); ?>][is_default]" value="1" <?php if($variation->is_default): echo 'checked'; endif; ?>></td>
                                    <td class="var-image-cell">
                                        <div class="bdp-var-img-wrap">
                                            <?php if($variation->image): ?><img class="bdp-var-img" src="<?php echo e($variation->image); ?>" onerror="this.style.display='none'" alt="Variation image"><?php endif; ?>
                                            <input class="bdp-copy-input bdp-var-image-input" name="variations[<?php echo e($variation->id); ?>][image]" value="<?php echo e($variation->image); ?>" placeholder="Image URL">
                                        </div>
                                    </td>
                                    <td><input name="variations[<?php echo e($variation->id); ?>][color]" value="<?php echo e($variation->color); ?>" placeholder="Color"></td>
                                    <td><input name="variations[<?php echo e($variation->id); ?>][size_raw]" value="<?php echo e($variation->size_raw); ?>" placeholder="Raw size"></td>
                                    <td><input name="variations[<?php echo e($variation->id); ?>][size_us]" value="<?php echo e($variation->size_us); ?>" placeholder="US size"></td>
                                    <td><?php echo e($variation->cost_per_item !== null ? '$'.number_format((float)$variation->cost_per_item, 2) : '—'); ?></td>
                                    <td><input class="bdp-price-input" name="variations[<?php echo e($variation->id); ?>][price]" value="<?php echo e($variation->price); ?>" placeholder="39.99"></td>
                                    <td><input class="bdp-sale-input" name="variations[<?php echo e($variation->id); ?>][sale_price]" value="<?php echo e($variation->sale_price); ?>" placeholder="Optional"></td>
                                    <td><input name="variations[<?php echo e($variation->id); ?>][quantity]" value="<?php echo e($variation->quantity); ?>" placeholder="100"></td>
                                    <td><?php echo e($variation->cj_inventory_total ?? '—'); ?> <?php if($variation->cj_inventory_details): ?><br><small title="<?php echo e($variation->cj_inventory_details); ?>">details saved</small><?php endif; ?></td>
                                    <td>
                                        <select name="variations[<?php echo e($variation->id); ?>][stock_status]">
                                            <option value="in_stock" <?php if($variation->stock_status === 'in_stock'): echo 'selected'; endif; ?>>In Stock</option>
                                            <option value="out_of_stock" <?php if($variation->stock_status === 'out_of_stock'): echo 'selected'; endif; ?>>Out of Stock</option>
                                        </select>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="10"><div class="bdp-empty-products">No variations found for this product.</div></td></tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="bdp-action-sticky">
                    <div>
                        <strong>Ready score: <?php echo e($readyPercent); ?>%</strong>
                        <div class="bdp-input-help">Save changes before syncing to Balenco.</div>
                    </div>
                    <div class="bdp-selected-actions">
                        
<?php
    $bdpGalleryZipUrl = null;
    $bdpAllZipUrl = null;

    $bdpGalleryRouteNames = [
        'bdp.products.images.gallery_zip',
        'bdp.products.images.featured_gallery_zip',
        'bdp.products.images.featured-gallery',
        'bdp.products.images.gallery',
        'bdp.products.gallery.zip',
    ];

    $bdpAllRouteNames = [
        'bdp.products.images.all_zip',
        'bdp.products.images.all-zip',
        'bdp.products.images.zip',
        'bdp.products.images.download',
        'bdp.products.download.images',
        'bdp.products.download-images',
        'bdp.product.images.zip',
    ];

    foreach ($bdpGalleryRouteNames as $bdpRouteName) {
        if (\Illuminate\Support\Facades\Route::has($bdpRouteName)) {
            $bdpGalleryZipUrl = route($bdpRouteName, $product);
            break;
        }
    }

    foreach ($bdpAllRouteNames as $bdpRouteName) {
        if (\Illuminate\Support\Facades\Route::has($bdpRouteName)) {
            $bdpAllZipUrl = route($bdpRouteName, $product);
            break;
        }
    }
?>
<?php if($bdpGalleryZipUrl || $bdpAllZipUrl): ?>
    <span class="bdp-edit-image-download-actions">
        <?php if($bdpGalleryZipUrl): ?>
            <a class="bdp-btn image-zip" href="<?php echo e($bdpGalleryZipUrl); ?>">Gallery ZIP</a>
        <?php endif; ?>
        <?php if($bdpAllZipUrl): ?>
            <a class="bdp-btn image-zip" href="<?php echo e($bdpAllZipUrl); ?>">All Images ZIP</a>
        <?php endif; ?>
    </span>
<?php endif; ?>

<a href="<?php echo e(route('bdp.products')); ?>" class="bdp-btn light">Cancel</a>
                        <button class="bdp-btn light" type="submit">Save Product</button>
                        <button class="bdp-btn orange" type="submit" form="bdp-sync-product-form">Sync & Close</button>
                    </div>
                </div>
            </div>

            <aside class="bdp-edit-side">

                
                <div class="bdp-card bdp-ai-tools-card" id="ai-seo-tools">
                    <div class="bdp-card-header">
                        <div>
                            <h2 class="bdp-card-title">AI SEO Tools</h2>
                            <p class="bdp-card-subtitle">Generate a safe cleanup prompt, paste the AI JSON result, then apply it for review.</p>
                        </div>
                        <span class="bdp-pill info">Draft only</span>
                    </div>

                    

                    
                    <div class="bdp-ai-settings" id="bdp-ai-settings">
                        <div class="bdp-ai-settings-title">
                            <span>Prompt Settings</span>
                            <span class="bdp-pill muted">Balenco SEO rules</span>
                        </div>
                        <div class="bdp-ai-settings-grid">
                            <div>
                                <label>Short description words</label>
                                <input type="text" id="bdp-ai-short-words" value="40–60" placeholder="40–60">
                            </div>
                            <div>
                                <label>Long description words</label>
                                <input type="text" id="bdp-ai-long-words" value="180–230" placeholder="180–230">
                            </div>
                            <div>
                                <label>Meta description chars</label>
                                <input type="text" id="bdp-ai-meta-chars" value="150–160" placeholder="150–160">
                            </div>
                            <div>
                                <label>Tags count</label>
                                <input type="number" id="bdp-ai-tags-count" value="6" min="1" max="13">
                            </div>
                            <div class="bdp-field-span" style="grid-column:1/-1">
                                <label>Buyer intent</label>
                                <select id="bdp-ai-buyer-intent">
                                    <option value="Everyday wear">Everyday wear</option>
                                    <option value="Party / event wear">Party / event wear</option>
                                    <option value="Office wear">Office wear</option>
                                    <option value="Casual fashion">Casual fashion</option>
                                    <option value="Walking / travel">Walking / travel</option>
                                    <option value="Summer wear">Summer wear</option>
                                    <option value="Dressy occasion">Dressy occasion</option>
                                </select>
                            </div>
                        </div>
                        <div class="bdp-ai-rule-note">
                            <strong>Slug rule:</strong> never use CJ/supplier prefixes in public URLs. If SKU is like <strong>CJNS1274506</strong>, AI must use <strong>b1274506</strong> at the end of the slug, for example <strong>womens-light-green-stiletto-pumps-b1274506</strong>.
                        </div>
                    </div>
<div class="bdp-ai-tool-actions">
                        <button type="button" class="bdp-btn light" id="bdp-ai-build-prompt">Build AI Prompt</button>
                        <button type="button" class="bdp-btn light" id="bdp-ai-copy-prompt">Copy Prompt</button>
                    </div>

                    <div class="bdp-ai-prompt-box" id="bdp-ai-prompt-box">
                        <label style="display:block;margin:10px 0 6px;font-weight:900;font-size:12px;color:#334155">Generated prompt</label>
                        <textarea class="bdp-ai-output" id="bdp-ai-prompt-output" readonly placeholder="Click Build AI Prompt first."></textarea>
                    </div>

                    <label style="display:block;margin:14px 0 6px;font-weight:900;font-size:12px;color:#334155">Paste AI JSON output</label>
                    <textarea class="bdp-ai-output" id="bdp-ai-json-output" placeholder='Paste JSON here, then click Apply. Example: {"title":"...","slug":"...","short_description":"..."}'></textarea>

                    <div class="bdp-ai-tool-actions">
                        <button type="button" class="bdp-btn orange" id="bdp-ai-apply-json">Apply AI Output</button>
                        <button type="button" class="bdp-btn light" id="bdp-ai-clear-json">Clear AI Box</button>
                    </div>

                    <div class="bdp-ai-mini-status" id="bdp-ai-status"></div>
                    <div class="bdp-ai-help">
                        Safety rule: AI output is never auto-published. Review the title, SEO, price, images, and variations before syncing to Balenco.
                    </div>
                </div>
                <div class="bdp-card">
                    <div class="bdp-product-preview">
                        <?php if($mainImage): ?>
                            <img class="bdp-preview-img" src="<?php echo e($mainImage); ?>" onerror="this.style.display='none'" alt="<?php echo e($product->name); ?>">
                        <?php else: ?>
                            <div class="bdp-preview-img"></div>
                        <?php endif; ?>
                        <div>
                            <h3 class="bdp-preview-title"><?php echo e($product->name ?: 'Untitled product'); ?></h3>
                            <div class="bdp-toolbar" style="gap:7px">
                                <span class="bdp-pill <?php echo e($isSynced ? 'success' : 'muted'); ?>"><?php echo e($isSynced ? 'Synced' : 'Not synced'); ?></span>
                                <span class="bdp-pill muted"><?php echo e($product->status ?: 'draft'); ?></span>
                            </div>
                        </div>
                    </div>
                    <div style="height:16px"></div>
                    <div class="bdp-mini-grid">
                        <div class="bdp-mini-stat"><span>Price</span><strong><?php echo e($product->price !== null ? '$'.number_format((float)$product->price, 2) : '—'); ?></strong></div>
                        <div class="bdp-mini-stat"><span>Variations</span><strong><?php echo e($variations->count()); ?></strong></div>
                        <div class="bdp-mini-stat"><span>Stock</span><strong><?php echo e(number_format((int) $totalInventory)); ?></strong></div>
                        <div class="bdp-mini-stat"><span>In stock vars</span><strong><?php echo e($inStockCount); ?></strong></div>
                    </div>
                </div>

                <div class="bdp-card">
                    <div class="bdp-card-header">
                        <div>
                            <h2 class="bdp-card-title">SEO / Publish Checklist</h2>
                            <p class="bdp-card-subtitle"><?php echo e($readyCount); ?> of <?php echo e(count($seoChecks)); ?> checks ready</p>
                        </div>
                        <span class="bdp-pill <?php echo e($readyPercent >= 80 ? 'success' : 'warning'); ?>"><?php echo e($readyPercent); ?>%</span>
                    </div>
                    <div class="bdp-progress-wrap"><div class="bdp-progress-bar" style="width:<?php echo e($readyPercent); ?>%"></div></div>
                    <div class="bdp-checklist">
                        <?php $__currentLoopData = $seoChecks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $ok): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="bdp-check-item">
                                <div class="left"><span class="bdp-check-dot <?php echo e($ok ? 'ok' : 'no'); ?>"><?php echo e($ok ? '✓' : '•'); ?></span><span><?php echo e($label); ?></span></div>
                                <span class="bdp-pill <?php echo e($ok ? 'success' : 'muted'); ?>"><?php echo e($ok ? 'Ready' : 'Missing'); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="bdp-card">
                    <div class="bdp-card-header">
                        <div>
                            <h2 class="bdp-card-title">Sync Actions</h2>
                            <p class="bdp-card-subtitle">Push this product safely as draft first.</p>
                        </div>
                    </div>
                    <div class="bdp-side-actions">
                        <button class="bdp-btn orange" type="submit" form="bdp-sync-product-form">Sync & Close</button>
                        <button class="bdp-btn light" type="submit" form="bdp-edit-form">Save Product</button>
                        <?php if($product->source === 'cj_api'): ?><button class="bdp-btn light" type="submit" form="bdp-refresh-cj-form">Refresh CJ Inventory</button><?php endif; ?>
                    </div>
                </div>

                <details class="bdp-card bdp-side-collapsible" open>
                    <summary>Source & Balenco Info</summary>
                    <div class="body">
                        <div class="bdp-source-list">
                            <div class="bdp-source-row"><span>Source</span><strong><?php echo e($product->source ?: '—'); ?></strong></div>
                            <div class="bdp-source-row"><span>Source product ID</span><strong><?php echo e($product->source_product_id ?: '—'); ?></strong></div>
                            <div class="bdp-source-row"><span>CJ SKU</span><strong><?php echo e($product->cj_sku ?: $product->sku ?: '—'); ?></strong></div>
                            <div class="bdp-source-row"><span>Balenco ID</span><strong><?php echo e($product->balenco_product_id ?: $product->shofy_product_id ?: '—'); ?></strong></div>
                            <div class="bdp-source-row"><span>Sync status</span><strong><?php echo e($syncStatus); ?></strong></div>
                            <div class="bdp-source-row"><span>Last sync</span><strong><?php echo e($product->balenco_synced_at ?: '—'); ?></strong></div>
                        </div>
                    </div>
                </details>

                <details class="bdp-card bdp-side-collapsible">
                    <summary>Image Debug</summary>
                    <div class="body">
                        <div class="bdp-image-status">
                            <span class="bdp-pill <?php echo e($mainImage ? 'success' : 'warning'); ?>">Main image: <?php echo e($mainImage ? 'Found' : 'Missing'); ?></span>
                            <span class="bdp-pill <?php echo e($galleryImages->isNotEmpty() ? 'success' : 'muted'); ?>">Gallery images: <?php echo e($galleryImages->count()); ?></span>
                            <span class="bdp-pill <?php echo e($variations->whereNotNull('image')->count() ? 'success' : 'warning'); ?>">Variation images: <?php echo e($variations->whereNotNull('image')->count()); ?></span>
                            <span class="bdp-pill muted">Parent gallery mode: Manual by default</span>
                            <span class="bdp-pill info">Variation copy mode: <?php echo e(config('balenco-data-pilot.copy_variation_images_to_shofy') ? 'Enabled' : 'Disabled'); ?></span>
                        </div>
                    </div>
                </details>
            </aside>
        </div>
    </form>
</div>




<link href="https://cdn.jsdelivr.net/npm/quill@2.0.3/dist/quill.snow.css" rel="stylesheet">
<style>
    .bdp-quill-wrapper{border:1px solid var(--bdp-border);border-radius:14px;overflow:hidden;background:#fff}
    .bdp-quill-wrapper .ql-toolbar{border:0;border-bottom:1px solid var(--bdp-border);background:#f8fafc}
    .bdp-quill-wrapper .ql-container{border:0;font-family:Inter,Arial,sans-serif;font-size:14px;line-height:1.65;min-height:220px}
    .bdp-quill-wrapper.bdp-quill-large .ql-container{min-height:360px}
    .bdp-quill-wrapper .ql-editor{min-height:220px;color:#0f172a}
    .bdp-quill-wrapper.bdp-quill-large .ql-editor{min-height:360px}
    .bdp-quill-wrapper .ql-editor h2,.bdp-quill-wrapper .ql-editor h3{line-height:1.3;margin:1em 0 .5em}
    .bdp-quill-wrapper .ql-editor p{margin:0 0 .85em}
</style>
<script src="https://cdn.jsdelivr.net/npm/quill@2.0.3/dist/quill.js"></script>
<script>
(function () {
    function initBdpQuillEditors() {
        var fields = document.querySelectorAll('textarea.bdp-rich-editor');
        if (!fields.length) return;

        if (!window.Quill) {
            console.error('BDP editor: Quill failed to load. Textareas are still available.');
            fields.forEach(function (textarea) { textarea.style.display = ''; });
            return;
        }

        fields.forEach(function (textarea, index) {
            if (textarea.dataset.quillReady === '1') return;
            textarea.dataset.quillReady = '1';

            if (!textarea.id) textarea.id = 'bdp-rich-editor-' + index;

            var wrapper = document.createElement('div');
            wrapper.className = 'bdp-quill-wrapper' + (textarea.name === 'content' ? ' bdp-quill-large' : '');

            var editorEl = document.createElement('div');
            editorEl.id = textarea.id + '-quill';
            wrapper.appendChild(editorEl);

            textarea.style.display = 'none';
            textarea.parentNode.insertBefore(wrapper, textarea.nextSibling);

            var quill = new Quill(editorEl, {
                theme: 'snow',
                modules: {
                    toolbar: [
                        [{ header: [2, 3, 4, false] }],
                        ['bold', 'italic', 'underline'],
                        [{ list: 'ordered' }, { list: 'bullet' }],
                        ['link'],
                        ['blockquote', 'code-block'],
                        ['clean']
                    ]
                }
            });

            var initialHtml = textarea.value || '';
            if (initialHtml.trim()) {
                quill.clipboard.dangerouslyPasteHTML(initialHtml);
            }

            function syncTextarea() {
                textarea.value = quill.root.innerHTML;
                textarea.dispatchEvent(new Event('input', { bubbles: true }));
            }

            quill.on('text-change', syncTextarea);
            syncTextarea();
        });

        document.querySelectorAll('form').forEach(function (form) {
            if (form.dataset.quillSubmitBound === '1') return;
            form.dataset.quillSubmitBound = '1';
            form.addEventListener('submit', function () {
                document.querySelectorAll('textarea.bdp-rich-editor').forEach(function (textarea) {
                    var editor = document.querySelector('#' + textarea.id + '-quill .ql-editor');
                    if (editor) textarea.value = editor.innerHTML;
                });
            });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initBdpQuillEditors);
    } else {
        initBdpQuillEditors();
    }
})();
</script>




<script>
(function () {
    function qs(selector) { return document.querySelector(selector); }
    function qsa(selector) { return Array.from(document.querySelectorAll(selector)); }
    function getValue(selector) {
        const el = qs(selector);
        return el ? (el.value || '').trim() : '';
    }
    function setValue(selector, value) {
        const el = qs(selector);
        if (!el || value === undefined || value === null) return;
        el.value = value;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
    }
    function richTextareas() {
        return qsa('textarea.bdp-rich-editor');
    }
    function getRichValueByName(name) {
        const textarea = qs('textarea[name="' + name + '"]');
        if (!textarea) return '';
        const list = richTextareas();
        const index = list.indexOf(textarea);
        const editors = qsa('.ql-editor');
        if (index >= 0 && editors[index]) return editors[index].innerHTML.trim();
        return textarea.value.trim();
    }
    function setRichValueByName(name, value) {
        if (value === undefined || value === null) return;
        const textarea = qs('textarea[name="' + name + '"]');
        if (!textarea) return;
        textarea.value = value;
        textarea.dispatchEvent(new Event('input', { bubbles: true }));
        textarea.dispatchEvent(new Event('change', { bubbles: true }));
        const list = richTextareas();
        const index = list.indexOf(textarea);
        const editors = qsa('.ql-editor');
        if (index >= 0 && editors[index]) editors[index].innerHTML = value;
    }
    function status(message, type) {
        const box = qs('#bdp-ai-status');
        if (!box) return;
        box.className = 'bdp-ai-mini-status ' + (type || 'ok');
        box.textContent = message;
    }
    function slugify(text) {
        return (text || '').toString().toLowerCase()
            .replace(/&/g, ' and ')
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-+|-+$/g, '')
            .substring(0, 90);
    }
    function collectVariations() {
        return qsa('.bdp-variation-table tbody tr').slice(0, 30).map(function(row) {
            const inputs = row.querySelectorAll('input, select');
            return {
                image: inputs[1] ? inputs[1].value : '',
                color: inputs[2] ? inputs[2].value : '',
                raw_size: inputs[3] ? inputs[3].value : '',
                us_size: inputs[4] ? inputs[4].value : '',
                selling_price: inputs[5] ? inputs[5].value : '',
                quantity: inputs[6] ? inputs[6].value : '',
                stock_status: inputs[7] ? inputs[7].value : ''
            };
        }).filter(function(v) { return v.color || v.us_size || v.raw_size; });
    }
    function getAiSetting(selector, fallback) {
        const el = qs(selector);
        return el && el.value ? el.value.trim() : fallback;
    }
    function skuToBalencoSlugCode(sku) {
        const raw = (sku || '').toString().trim();
        const digits = raw.replace(/^CJ[A-Z]*/i, '').replace(/[^0-9]/g, '');
        return digits ? ('b' + digits) : '';
    }
    function buildPrompt() {
        const sku = getValue('input[name="sku"]');
        const product = {
            current_title: getValue('input[name="name"]'),
            current_slug: getValue('input[name="slug"]'),
            sku: sku,
            balenco_slug_code: skuToBalencoSlugCode(sku),
            categories: getValue('input[name="categories"]'),
            tags: getValue('input[name="tags"]'),
            price: getValue('input[name="price"]'),
            sale_price: getValue('input[name="sale_price"]'),
            focus_keyword: getValue('input[name="focus_keyword"]'),
            seo_title: getValue('input[name="seo_title"]'),
            seo_description: getValue('textarea[name="seo_description"]'),
            short_description: getRichValueByName('short_description'),
            long_description: getRichValueByName('content'),
            featured_image: getValue('input[name="featured_image"]'),
            variations_sample: collectVariations()
        };

        const promptSettings = {
            short_description_words: getAiSetting('#bdp-ai-short-words', '40–60'),
            long_description_words: getAiSetting('#bdp-ai-long-words', '180–230'),
            meta_description_chars: getAiSetting('#bdp-ai-meta-chars', '150–160'),
            tags_count: getAiSetting('#bdp-ai-tags-count', '6'),
            buyer_intent: getAiSetting('#bdp-ai-buyer-intent', 'Everyday wear'),
            target_market: 'USA',
            store_brand: 'Balenco'
        };

        return `Act as a senior ecommerce SEO strategist, product content writer, and CRO expert for Balenco, a women's footwear store targeting USA buyers.

Your task is to rewrite and optimize this product listing for Google SEO, buyer intent, and conversion.

IMPORTANT CONTENT RULES:
- Use only the product facts provided in the product data.
- Do not invent materials, comfort claims, orthopedic/medical claims, waterproof claims, genuine leather claims, premium/luxury claims, shipping promises, guarantees, or brand claims.
- Do not mention CJ, CJDropshipping, supplier IDs, supplier names, supplier SKU prefixes, factory language, or raw marketplace wording in customer-facing content.
- Do not use keyword stuffing.
- Use American English.
- Target real buyers first, search engines second.
- Make the content natural, clean, readable, and suitable for a women’s footwear ecommerce store.
- If any product fact is unclear, keep the wording general and safe.

SLUG RULE:
- Create a short, clean, SEO-friendly URL slug.
- Do not use CJ, CJNS, CJBH, CJD, supplier prefixes, or the full supplier SKU in the slug.
- If SKU/source SKU contains a CJ-style code such as CJNS1274506, remove the CJ/CJNS prefix and append b + number at the end.
- Example: CJNS1274506 becomes b1274506.
- Example final slug: womens-light-green-stiletto-pumps-b1274506.
- For this product, use this slug ending if available: ${product.balenco_slug_code || 'b + numeric part of SKU'}.

BUYER INTENT:
${promptSettings.buyer_intent}

REQUIRED OUTPUT:
Return ONLY valid JSON with these exact keys:
{
  "title": "",
  "slug": "",
  "short_description": "",
  "description": "",
  "seo_title": "",
  "seo_description": "",
  "focus_keyword": "",
  "tags": ""
}

LENGTH AND FORMAT RULES:
- Title: clear, buyer-friendly, under 70 characters if possible.
- Short description: ${promptSettings.short_description_words} words, benefit-focused, clean HTML allowed.
- Long description: ${promptSettings.long_description_words} words, clean HTML only using <p>, <ul>, <li>, <strong>. Remove messy imported HTML wrappers.
- SEO title: under 60 characters if possible.
- SEO description: ${promptSettings.meta_description_chars} characters, natural and click-focused.
- Tags: exactly ${promptSettings.tags_count} comma-separated tags. Do not repeat the same phrase in every tag.
- Focus keyword: one natural buyer-intent phrase.

PRODUCT DATA:
${JSON.stringify(product, null, 2)}`;
    }
    

    function applyAiJson() {
        const raw = getValue('#bdp-ai-json-output');
        if (!raw) {
            status('Paste AI JSON output first.', 'warn');
            return;
        }
        let data;
        try {
            data = JSON.parse(raw);
        } catch (e) {
            status('Invalid JSON. Ask AI to return only valid JSON.', 'err');
            return;
        }

        if (data.title) setValue('input[name="name"]', data.title);
        if (data.slug) setValue('input[name="slug"]', slugify(data.slug));
        if (data.short_description) setRichValueByName('short_description', data.short_description);
        if (data.description) setRichValueByName('content', data.description);
        if (data.seo_title) setValue('input[name="seo_title"]', data.seo_title);
        if (data.seo_description) setValue('textarea[name="seo_description"]', data.seo_description);
        if (data.focus_keyword) setValue('input[name="focus_keyword"]', data.focus_keyword);
        if (data.tags) setValue('input[name="tags"]', Array.isArray(data.tags) ? data.tags.join(', ') : data.tags);

        status('AI output applied. Review carefully, then click Save Product.', 'ok');
    }

    function initAiSeoTools() {
        const buildBtn = qs('#bdp-ai-build-prompt');
        const copyBtn = qs('#bdp-ai-copy-prompt');
        const applyBtn = qs('#bdp-ai-apply-json');
        const clearBtn = qs('#bdp-ai-clear-json');
        const promptBox = qs('#bdp-ai-prompt-box');
        const promptOut = qs('#bdp-ai-prompt-output');
        const jsonOut = qs('#bdp-ai-json-output');

        if (buildBtn) buildBtn.addEventListener('click', function () {
            if (!promptOut) return;
            promptOut.value = buildPrompt();
            if (promptBox) promptBox.classList.add('is-open');
            status('Prompt built. Copy it into ChatGPT, then paste the JSON response below.', 'ok');
        });
        if (copyBtn) copyBtn.addEventListener('click', async function () {
            const prompt = promptOut && promptOut.value ? promptOut.value : buildPrompt();
            if (promptOut) promptOut.value = prompt;
            if (promptBox) promptBox.classList.add('is-open');
            try {
                await navigator.clipboard.writeText(prompt);
                status('Prompt copied to clipboard.', 'ok');
            } catch (e) {
                status('Prompt ready. Select and copy it manually.', 'warn');
            }
        });
        if (applyBtn) applyBtn.addEventListener('click', applyAiJson);
        if (clearBtn) clearBtn.addEventListener('click', function () {
            if (jsonOut) jsonOut.value = '';
            status('AI output box cleared.', 'ok');
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAiSeoTools);
    } else {
        initAiSeoTools();
    }
})();
</script>



<script>
(function () {
    function bdpGetVariationRows(target) {
        var rows = Array.prototype.slice.call(document.querySelectorAll('.bdp-variation-table tbody tr'));
        if (target === 'all') return rows;
        return rows.filter(function (row) {
            var checkbox = row.querySelector('input[type="checkbox"][name*="[is_default]"]');
            return checkbox && checkbox.checked;
        });
    }

    function bdpSetInputValue(input, value) {
        if (!input) return;
        input.value = value;
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
    }

    document.addEventListener('DOMContentLoaded', function () {
        var applyBtn = document.getElementById('bdp-apply-variation-prices');
        var clearSaleBtn = document.getElementById('bdp-clear-variation-sale-prices');
        var sellingInput = document.getElementById('bdp-bulk-variation-selling-price');
        var saleInput = document.getElementById('bdp-bulk-variation-sale-price');
        var targetSelect = document.getElementById('bdp-bulk-variation-target');

        if (applyBtn) {
            applyBtn.addEventListener('click', function () {
                var target = targetSelect ? targetSelect.value : 'selected';
                var rows = bdpGetVariationRows(target);
                if (!rows.length) {
                    alert('Please select at least one variation, or choose Apply to: All variations.');
                    return;
                }

                rows.forEach(function (row) {
                    if (sellingInput && sellingInput.value !== '') {
                        bdpSetInputValue(row.querySelector('input[name*="[price]"]'), sellingInput.value);
                    }
                    if (saleInput && saleInput.value !== '') {
                        bdpSetInputValue(row.querySelector('input[name*="[sale_price]"]'), saleInput.value);
                    }
                });
            });
        }

        if (clearSaleBtn) {
            clearSaleBtn.addEventListener('click', function () {
                var target = targetSelect ? targetSelect.value : 'selected';
                var rows = bdpGetVariationRows(target);
                if (!rows.length) {
                    alert('Please select at least one variation, or choose Apply to: All variations.');
                    return;
                }
                rows.forEach(function (row) {
                    bdpSetInputValue(row.querySelector('input[name*="[sale_price]"]'), '');
                });
            });
        }
    });
})();
</script>




<script>
document.addEventListener('DOMContentLoaded', function () {
    const tabs = Array.from(document.querySelectorAll('.bdp-section-tabs a[href^="#"]'));
    const sections = tabs.map(function (tab) {
        const id = tab.getAttribute('href');
        return id ? document.querySelector(id) : null;
    }).filter(Boolean);

    if (!tabs.length || !sections.length) return;

    function setActive() {
        let activeId = sections[0].id;
        const offset = 130;
        sections.forEach(function (section) {
            const rect = section.getBoundingClientRect();
            if (rect.top <= offset) activeId = section.id;
        });
        tabs.forEach(function (tab) {
            tab.classList.toggle('is-active', tab.getAttribute('href') === '#' + activeId);
        });
    }

    tabs.forEach(function (tab) {
        tab.addEventListener('click', function (event) {
            const target = document.querySelector(tab.getAttribute('href'));
            if (!target) return;
            event.preventDefault();
            const top = target.getBoundingClientRect().top + window.pageYOffset - 118;
            window.scrollTo({ top: top, behavior: 'smooth' });
            history.replaceState(null, '', tab.getAttribute('href'));
            setTimeout(setActive, 250);
        });
    });

    window.addEventListener('scroll', setActive, { passive: true });
    setActive();
});
</script>


<script>
document.addEventListener('DOMContentLoaded', function () {
    const checkbox = document.getElementById('bdp-sync-product-price-to-variations');
    const button = document.getElementById('bdp-apply-product-price-to-variations');
    const result = document.getElementById('bdp-price-sync-result');
    const form = document.getElementById('bdp-edit-form');

    if (!checkbox || !button || !form) return;

    checkbox.addEventListener('change', function () {
        button.disabled = !checkbox.checked;
    });

    button.addEventListener('click', function () {
        if (!checkbox.checked) return;

        const productPrice = form.querySelector('input[name="price"]');
        const productSalePrice = form.querySelector('input[name="sale_price"]');
        const priceValue = productPrice ? productPrice.value.trim() : '';
        const saleValue = productSalePrice ? productSalePrice.value.trim() : '';

        if (!priceValue) {
            alert('Please enter product selling price first.');
            if (productPrice) productPrice.focus();
            return;
        }

        const variationPriceInputs = Array.from(form.querySelectorAll('input[name^="variations["][name$="[price]"]'));
        const variationSaleInputs = Array.from(form.querySelectorAll('input[name^="variations["][name$="[sale_price]"], input[name^="variations["][name$="[discounted_price]"]'));

        variationPriceInputs.forEach(function (input) {
            input.value = priceValue;
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
        });

        variationSaleInputs.forEach(function (input) {
            input.value = saleValue;
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
        });

        if (result) {
            const saleText = variationSaleInputs.length ? ' and sale prices' : '';
            result.textContent = 'Updated ' + variationPriceInputs.length + ' variation selling prices' + saleText + '. Save Product to keep changes.';
            result.style.display = 'inline';
        }
    });
});
</script>




<style>
    .bdp-price-sync-panel{margin-top:14px;border:1px solid #dbeafe;background:linear-gradient(180deg,#eff6ff,#fff);border-radius:16px;padding:13px 14px;display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap}
    .bdp-price-sync-panel .bdp-price-sync-copy{color:#475569;font-size:12px;line-height:1.45}.bdp-price-sync-panel strong{color:#0f172a}.bdp-price-sync-actions{display:flex;align-items:center;gap:10px;flex-wrap:wrap}.bdp-price-sync-actions label{display:flex;align-items:center;gap:8px;font-weight:800;color:#0f172a;font-size:12px;margin:0}.bdp-price-sync-actions input[type="checkbox"]{width:auto}.bdp-variation-toggle{margin-left:auto}.bdp-variation-toggle .chev{display:inline-block;transition:transform .2s ease}.bdp-is-collapsed .bdp-variation-toggle .chev{transform:rotate(-90deg)}#variations.bdp-is-collapsed > *:not(.bdp-card-header){display:none!important}
</style>
<script>
document.addEventListener('DOMContentLoaded', function () {
    // Add product price -> variation price control inside Pricing card.
    const pricingCard = document.getElementById('pricing');
    if (pricingCard && !document.getElementById('bdp-price-sync-panel')) {
        const panel = document.createElement('div');
        panel.id = 'bdp-price-sync-panel';
        panel.className = 'bdp-price-sync-panel';
        panel.innerHTML = `
            <div class="bdp-price-sync-copy">
                <strong>Update variation prices from product price</strong><br>
                Enter product selling price and discounted/sale price above, then apply them to all variation rows before saving.
            </div>
            <div class="bdp-price-sync-actions">
                <label><input type="checkbox" id="bdp-sync-product-price-to-vars"> Update variation prices</label>
                <button class="bdp-btn light" type="button" id="bdp-apply-product-price-to-vars">Update variation prices</button>
            </div>`;
        const pricingGrid = pricingCard.querySelector('.bdp-field-grid, .bdp-form-grid');
        if (pricingGrid) {
            pricingGrid.insertAdjacentElement('afterend', panel);
        } else {
            pricingCard.appendChild(panel);
        }
    }

    const applyBtn = document.getElementById('bdp-apply-product-price-to-vars');
    if (applyBtn) {
        applyBtn.addEventListener('click', function () {
            const allow = document.getElementById('bdp-sync-product-price-to-vars');
            if (allow && !allow.checked) {
                alert('Please check “Update variation prices” first.');
                return;
            }
            const productPrice = document.querySelector('input[name="price"]');
            const productSale = document.querySelector('input[name="sale_price"]');
            const price = productPrice ? productPrice.value.trim() : '';
            const sale = productSale ? productSale.value.trim() : '';
            if (!price) {
                alert('Enter Product selling price first.');
                return;
            }
            const variationPriceInputs = Array.from(document.querySelectorAll('input[name^="variations["][name$="[price]"]'));
            const variationSaleInputs = Array.from(document.querySelectorAll('input[name^="variations["][name$="[sale_price]"], input[name^="variations["][name$="[discounted_price]"]'));
            variationPriceInputs.forEach(function (input) {
                input.value = price;
                input.dispatchEvent(new Event('input', { bubbles: true }));
                input.dispatchEvent(new Event('change', { bubbles: true }));
            });
            variationSaleInputs.forEach(function (input) {
                input.value = sale;
                input.dispatchEvent(new Event('input', { bubbles: true }));
                input.dispatchEvent(new Event('change', { bubbles: true }));
            });
            alert('Updated ' + variationPriceInputs.length + ' variation selling price field(s)' + (variationSaleInputs.length ? ' and ' + variationSaleInputs.length + ' discounted price field(s).' : '. Click Save Product to store changes.'));
        });
    }

    // Collapse Variations section by default. It opens automatically if page URL uses #variations.
    const variationsCard = document.getElementById('variations');
    if (variationsCard) {
        const header = variationsCard.querySelector('.bdp-card-header') || variationsCard.firstElementChild;
        if (header && !document.getElementById('bdp-toggle-variations')) {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.id = 'bdp-toggle-variations';
            btn.className = 'bdp-btn light bdp-variation-toggle';
            btn.innerHTML = '<span class="toggle-text">Show variations</span> <span class="chev">▾</span>';
            header.appendChild(btn);
            const setState = function (open) {
                variationsCard.classList.toggle('bdp-is-collapsed', !open);
                btn.querySelector('.toggle-text').textContent = open ? 'Hide variations' : 'Show variations';
            };
            setState(window.location.hash === '#variations');
            btn.addEventListener('click', function () {
                setState(variationsCard.classList.contains('bdp-is-collapsed'));
            });
            document.querySelectorAll('a[href="#variations"]').forEach(function (link) {
                link.addEventListener('click', function () { setState(true); });
            });
        }
    }
});
</script>


<script>
document.addEventListener('DOMContentLoaded', function () {
    var section = document.getElementById('variations');
    var btn = document.getElementById('bdp-toggle-variations');
    if (!section || !btn) return;

    var storageKey = 'bdp-edit-variations-open';
    function setOpen(open) {
        section.classList.toggle('bdp-variations-open', !!open);
        btn.textContent = open ? 'Hide variations' : 'Show variations';
        localStorage.setItem(storageKey, open ? '1' : '0');
    }

    setOpen(localStorage.getItem(storageKey) === '1');
    btn.addEventListener('click', function () {
        setOpen(!section.classList.contains('bdp-variations-open'));
    });
});
</script>


<!-- BDP_FORCE_VARIATIONS_COLLAPSED_START -->
<style>
    /* Product edit: keep Variations collapsed by default for a cleaner workflow. */
    #variations.bdp-vars-collapsed > :not(.bdp-card-header) {
        display: none !important;
    }
    #variations .bdp-vars-toggle-btn {
        white-space: nowrap;
    }
</style>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var section = document.getElementById('variations');
    if (!section) return;

    var header = section.querySelector('.bdp-card-header') || section.firstElementChild;
    if (!header) return;

    var headerRight = header.querySelector('.bdp-card-header > div:last-child, .bdp-toolbar') || header;
    var btn = section.querySelector('.bdp-vars-toggle-btn');

    if (!btn) {
        btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'bdp-btn light bdp-vars-toggle-btn';
        btn.style.marginLeft = 'auto';
        header.appendChild(btn);
    } else {
        btn.type = 'button';
        btn.classList.add('bdp-vars-toggle-btn');
    }

    function setCollapsed(collapsed) {
        section.classList.toggle('bdp-vars-collapsed', collapsed);
        btn.textContent = collapsed ? 'Show variations' : 'Hide variations';
        btn.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
    }

    // Always start collapsed on product edit page, even if an older patch saved open state.
    setCollapsed(true);

    btn.addEventListener('click', function () {
        setCollapsed(!section.classList.contains('bdp-vars-collapsed'));
    });

    // If user clicks the top Variations tab, open the section so anchor navigation is useful.
    document.querySelectorAll('a[href="#variations"]').forEach(function (link) {
        link.addEventListener('click', function () {
            setCollapsed(false);
        });
    });
});
</script>
<!-- BDP_FORCE_VARIATIONS_COLLAPSED_END -->



<style>
    /* Cleaner sticky section navigation on Product Edit */
    .bdp-section-tabs{
        position: sticky;
        top: 72px;
        z-index: 25;
        background: rgba(247,248,251,.94);
        backdrop-filter: blur(10px);
        border: 1px solid #e5e7eb;
        border-radius: 18px;
        padding: 8px;
        box-shadow: 0 10px 30px rgba(15,23,42,.06);
        margin-bottom: 6px;
    }
    .bdp-section-tabs a{
        transition: all .15s ease;
    }
    .bdp-section-tabs a.is-active,
    .bdp-section-tabs a.active{
        background: #0f1f3d !important;
        color: #fff !important;
        border-color: #0f1f3d !important;
    }

    /* Compact/collapsible right-side cards */
    .bdp-compact-card-toggle{
        width: 100%;
        border: 0;
        background: transparent;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        padding: 0;
        text-align: left;
        cursor: pointer;
        color: inherit;
    }
    .bdp-compact-card-toggle .chev{
        width: 22px;
        height: 22px;
        border-radius: 999px;
        background: #f1f5f9;
        color: #64748b;
        display: inline-grid;
        place-items: center;
        font-weight: 900;
        line-height: 1;
        flex: 0 0 auto;
    }
    .bdp-compact-card.is-collapsed .bdp-compact-card-body{
        display: none !important;
    }
    .bdp-compact-card.is-collapsed .bdp-compact-card-toggle .chev{
        transform: rotate(180deg);
    }
    .bdp-compact-card.is-collapsed{
        padding-bottom: 16px;
    }

    /* Variations collapsed state */
    #variations.bdp-vars-collapsed .bdp-vars-collapsible-body{
        display: none !important;
    }
    #variations .bdp-vars-toggle-wrap{
        display: flex;
        justify-content: flex-end;
        gap: 8px;
        align-items: center;
        flex-wrap: wrap;
    }
    #variations.bdp-vars-collapsed .bdp-vars-hide-btn{display:none !important;}
    #variations:not(.bdp-vars-collapsed) .bdp-vars-show-btn{display:none !important;}
</style>

<script>
document.addEventListener('DOMContentLoaded', function () {
    // Active sticky tabs while scrolling
    const tabs = Array.from(document.querySelectorAll('.bdp-section-tabs a[href^="#"]'));
    const sections = tabs.map(a => document.querySelector(a.getAttribute('href'))).filter(Boolean);
    function setActiveTab() {
        let active = sections[0] ? sections[0].id : null;
        const offset = 160;
        sections.forEach(section => {
            const rect = section.getBoundingClientRect();
            if (rect.top <= offset) active = section.id;
        });
        tabs.forEach(a => a.classList.toggle('is-active', a.getAttribute('href') === '#' + active));
    }
    if (tabs.length) {
        window.addEventListener('scroll', setActiveTab, { passive: true });
        setActiveTab();
        tabs.forEach(a => {
            a.addEventListener('click', function () {
                const target = document.querySelector(a.getAttribute('href'));
                if (target && target.id === 'variations') {
                    setTimeout(() => window.bdpSetVariationsOpen && window.bdpSetVariationsOpen(true), 80);
                }
            });
        });
    }

    // Collapse AI SEO Tools by default, but keep product preview/checklist/sync actions visible.
    const cards = Array.from(document.querySelectorAll('.bdp-edit-side .bdp-card'));
    cards.forEach(function(card) {
        const titleEl = card.querySelector('.bdp-card-title, h2, h3');
        if (!titleEl) return;
        const title = (titleEl.textContent || '').trim();
        if (!/AI SEO Tools/i.test(title)) return;
        if (card.dataset.bdpCompactReady === '1') return;
        card.dataset.bdpCompactReady = '1';
        card.classList.add('bdp-compact-card', 'is-collapsed');

        const header = titleEl.closest('.bdp-card-header') || titleEl.parentElement;
        if (!header) return;

        const body = document.createElement('div');
        body.className = 'bdp-compact-card-body';
        let node = header.nextSibling;
        const moving = [];
        while (node) {
            const next = node.nextSibling;
            moving.push(node);
            node = next;
        }
        moving.forEach(n => body.appendChild(n));
        card.appendChild(body);

        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'bdp-compact-card-toggle';
        button.innerHTML = '<span>' + header.innerHTML + '</span><span class="chev">⌄</span>';
        header.innerHTML = '';
        header.appendChild(button);
        button.addEventListener('click', function () {
            card.classList.toggle('is-collapsed');
        });
    });

    // Ensure details cards like Source & Image Debug start collapsed unless the user opens them.
    document.querySelectorAll('.bdp-edit-side details.bdp-side-collapsible').forEach(function(details){
        if (!details.dataset.userOpened) details.removeAttribute('open');
    });

    // Force variations collapsed by default and show only one toggle button at a time.
    const varCard = document.getElementById('variations');
    if (varCard) {
        const storageKey = 'bdp-edit-variations-open-v3';
        let header = varCard.querySelector('.bdp-card-header') || varCard.firstElementChild;
        let body = varCard.querySelector('.bdp-vars-collapsible-body');
        if (!body) {
            body = document.createElement('div');
            body.className = 'bdp-vars-collapsible-body';
            let startAfter = header || null;
            let node = startAfter ? startAfter.nextSibling : varCard.firstChild;
            const moving = [];
            while (node) {
                const next = node.nextSibling;
                moving.push(node);
                node = next;
            }
            moving.forEach(n => body.appendChild(n));
            varCard.appendChild(body);
        }

        let toggleWrap = varCard.querySelector('.bdp-vars-toggle-wrap');
        if (!toggleWrap) {
            toggleWrap = document.createElement('div');
            toggleWrap.className = 'bdp-vars-toggle-wrap';
            if (header) header.appendChild(toggleWrap);
        }

        // Remove duplicate old buttons by text to avoid two visible controls.
        Array.from(toggleWrap.querySelectorAll('button')).forEach(btn => btn.remove());
        Array.from(varCard.querySelectorAll('button')).forEach(btn => {
            const txt = (btn.textContent || '').trim().toLowerCase();
            if ((txt === 'show variations' || txt === 'hide variations') && !btn.closest('.bdp-vars-toggle-wrap')) btn.remove();
        });

        const showBtn = document.createElement('button');
        showBtn.type = 'button';
        showBtn.className = 'bdp-btn light bdp-vars-show-btn';
        showBtn.textContent = 'Show variations';
        const hideBtn = document.createElement('button');
        hideBtn.type = 'button';
        hideBtn.className = 'bdp-btn light bdp-vars-hide-btn';
        hideBtn.textContent = 'Hide variations';
        toggleWrap.appendChild(hideBtn);
        toggleWrap.appendChild(showBtn);

        window.bdpSetVariationsOpen = function(open) {
            varCard.classList.toggle('bdp-vars-collapsed', !open);
            try { localStorage.setItem(storageKey, open ? '1' : '0'); } catch(e) {}
        };

        showBtn.addEventListener('click', () => window.bdpSetVariationsOpen(true));
        hideBtn.addEventListener('click', () => window.bdpSetVariationsOpen(false));

        let shouldOpen = false;
        try { shouldOpen = localStorage.getItem(storageKey) === '1'; } catch(e) {}
        window.bdpSetVariationsOpen(shouldOpen);
    }
});
</script>




<style>
    .bdp-variation-toggle-fixed { min-width: 118px; }
</style>
<script>
(function () {
    function findVariationsCard() {
        var byId = document.getElementById('variations');
        if (byId) return byId;

        var cards = Array.from(document.querySelectorAll('.bdp-card, section, div'));
        return cards.find(function (card) {
            var title = card.querySelector('.bdp-card-title, h2, h3');
            return title && title.textContent.trim().toLowerCase() === 'variations';
        }) || null;
    }

    function findHeader(card) {
        return card.querySelector('.bdp-card-header') || card.querySelector('h2, h3')?.parentElement || card.firstElementChild;
    }

    function getBodyChildren(card, header) {
        return Array.from(card.children).filter(function (child) {
            return child !== header;
        });
    }

    function initVariationsToggle() {
        var card = findVariationsCard();
        if (!card || card.dataset.bdpVarsToggleFixed === '1') return;
        card.dataset.bdpVarsToggleFixed = '1';

        var header = findHeader(card);
        if (!header) return;

        var headerActions = header.querySelector('.bdp-card-actions, .bdp-list-header-actions, .bdp-actions') || header;

        // Remove duplicate old show/hide buttons inside the variations card header only.
        Array.from(header.querySelectorAll('button, a')).forEach(function (btn) {
            var text = (btn.textContent || '').trim().toLowerCase();
            if (text === 'show variations' || text === 'hide variations') {
                btn.remove();
            }
        });

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'bdp-btn light bdp-variation-toggle-fixed';
        btn.setAttribute('data-bdp-variation-toggle-fixed', '1');
        headerActions.appendChild(btn);

        var bodyChildren = getBodyChildren(card, header);

        function setExpanded(expanded) {
            bodyChildren.forEach(function (child) {
                child.style.display = expanded ? '' : 'none';
            });
            btn.textContent = expanded ? 'Hide variations' : 'Show variations';
            card.dataset.variationsExpanded = expanded ? '1' : '0';
        }

        // Always start collapsed on product edit pages.
        setExpanded(false);

        btn.addEventListener('click', function () {
            setExpanded(card.dataset.variationsExpanded !== '1');
        });

        // If top sticky/tab navigation clicks Variations, open it automatically.
        Array.from(document.querySelectorAll('a, button')).forEach(function (nav) {
            var text = (nav.textContent || '').trim().toLowerCase();
            var href = nav.getAttribute('href') || '';
            if (text === 'variations' || href === '#variations') {
                nav.addEventListener('click', function () {
                    setExpanded(true);
                    setTimeout(function () { card.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 50);
                });
            }
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        initVariationsToggle();
        setTimeout(initVariationsToggle, 400);
        setTimeout(initVariationsToggle, 1000);
    });
    window.addEventListener('load', function () {
        setTimeout(initVariationsToggle, 300);
    });
})();
</script>




<style>
    /* Final robust variation toggle fix */
    .bdp-force-vars-hidden { display: none !important; }
    .bdp-force-vars-toggle {
        border: 1px solid var(--bdp-border, #e5e7eb);
        background: #fff;
        color: var(--bdp-navy, #0f172a);
        border-radius: 10px;
        padding: 8px 12px;
        font-weight: 800;
        cursor: pointer;
    }
    .bdp-force-vars-toggle:hover { background: #f8fafc; }
</style>
<script>
(function () {
    function textOf(el) {
        return (el && el.textContent ? el.textContent : '').replace(/\s+/g, ' ').trim().toLowerCase();
    }

    function findVariationsCard() {
        // Prefer a card that has the Variations title.
        var titles = Array.from(document.querySelectorAll('h2,h3,h4,.bdp-card-title'));
        for (var i = 0; i < titles.length; i++) {
            if (textOf(titles[i]).indexOf('variations') === 0) {
                var card = titles[i].closest('.bdp-card') || titles[i].closest('section') || titles[i].parentElement;
                if (card) return card;
            }
        }

        // Fallback: find any variation input/table and use its card.
        var variationInput = document.querySelector('input[name*="variations"], select[name*="variations"], textarea[name*="variations"]');
        if (variationInput) return variationInput.closest('.bdp-card') || variationInput.closest('section');

        return null;
    }

    function getHeader(card) {
        return card.querySelector('.bdp-card-header') || card.firstElementChild;
    }

    function getBodies(card, header) {
        var children = Array.from(card.children);
        var bodies = children.filter(function (child) {
            return child !== header && !child.classList.contains('bdp-force-vars-toggle-holder');
        });

        // If previous patches wrapped content in a hidden body, include it too.
        Array.from(card.querySelectorAll('.bdp-variations-body,.bdp-vars-body,.bdp-variation-body,[data-variation-body]')).forEach(function (el) {
            if (bodies.indexOf(el) === -1 && el !== header) bodies.push(el);
        });

        return bodies;
    }

    function removeOldButtons(card) {
        Array.from(card.querySelectorAll('button,a')).forEach(function (btn) {
            var t = textOf(btn);
            if (t === 'show variations' || t === 'hide variations') {
                btn.remove();
            }
        });
    }

    function init() {
        var card = findVariationsCard();
        if (!card || card.dataset.bdpFinalVariationToggle === '1') return;
        card.dataset.bdpFinalVariationToggle = '1';
        card.id = card.id || 'variations';

        var header = getHeader(card);
        if (!header) return;

        removeOldButtons(card);

        // Make header able to hold the toggle button nicely.
        header.style.display = header.style.display || 'flex';
        header.style.alignItems = header.style.alignItems || 'center';
        header.style.justifyContent = header.style.justifyContent || 'space-between';
        header.style.gap = header.style.gap || '12px';

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'bdp-force-vars-toggle';
        btn.dataset.bdpVariationsToggle = '1';
        header.appendChild(btn);

        var open = false;

        function setOpen(nextOpen) {
            open = !!nextOpen;
            var bodies = getBodies(card, header);

            bodies.forEach(function (body) {
                body.classList.toggle('bdp-force-vars-hidden', !open);
                body.hidden = false;
                body.removeAttribute('hidden');
                body.classList.remove('hidden', 'is-hidden', 'bdp-hidden', 'bdp-variations-hidden');
                if (open) {
                    body.style.removeProperty('display');
                    body.style.removeProperty('visibility');
                    body.style.removeProperty('height');
                    body.style.removeProperty('max-height');
                    body.style.removeProperty('overflow');
                }
            });

            // Remove inline hiding from descendants when opening.
            if (open) {
                Array.from(card.querySelectorAll('[style]')).forEach(function (el) {
                    var style = (el.getAttribute('style') || '').toLowerCase();
                    if (style.indexOf('display: none') !== -1 || style.indexOf('display:none') !== -1) {
                        el.style.removeProperty('display');
                    }
                    el.hidden = false;
                    el.removeAttribute('hidden');
                });
            }

            btn.textContent = open ? 'Hide variations' : 'Show variations';
            card.classList.toggle('bdp-variations-open', open);
            card.classList.toggle('bdp-variations-closed', !open);
        }

        btn.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            setOpen(!open);
        });

        // Top Variations tab should open section and scroll to it.
        Array.from(document.querySelectorAll('a,button')).forEach(function (tab) {
            if (textOf(tab) === 'variations' && tab !== btn) {
                tab.addEventListener('click', function () {
                    setOpen(true);
                    setTimeout(function () { card.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 80);
                });
            }
        });

        // Default collapsed.
        setOpen(false);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Run again after other scripts finish, because older patches may modify the card later.
    window.addEventListener('load', function () {
        setTimeout(init, 300);
        setTimeout(init, 900);
    });
})();
</script>




<!-- BDP_VARIATIONS_TOGGLE_CLEAN_FINAL -->
<style>
    /* Final safe variations collapse/expand handling */
    #variations.bdp-vars-final-closed > *:not(:first-child) {
        display: none !important;
    }
    #variations.bdp-vars-final-open > *:not(:first-child) {
        display: block !important;
    }
    #variations .bdp-vars-final-toggle {
        white-space: nowrap;
        border: 1px solid var(--bdp-border, #dbe3ef);
        background: #fff;
        color: var(--bdp-navy, #0f1f3d);
        border-radius: 12px;
        padding: 9px 14px;
        font-weight: 800;
        cursor: pointer;
    }
    #variations .bdp-vars-final-toggle:hover {
        background: #f8fafc;
    }
</style>
<script>
(function () {
    function ready(fn) {
        if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
        else fn();
    }

    ready(function () {
        const card = document.getElementById('variations');
        if (!card) return;

        // Find the header. In this edit page, the first child is the variations header/summary row.
        const header = card.firstElementChild || card;

        // Remove all previous variation toggle buttons created by older patches.
        card.querySelectorAll('button, a').forEach(function (el) {
            const txt = (el.textContent || '').trim().toLowerCase();
            const isVariationToggle = txt === 'show variations' || txt === 'hide variations' ||
                el.matches('[data-bdp-vars-toggle], [data-bdp-variation-toggle], #bdp-final-variation-toggle, .bdp-vars-final-toggle');
            if (isVariationToggle) el.remove();
        });

        // Create one clean toggle button.
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'bdp-vars-final-toggle';

        // Put the button on the right side of the existing header.
        header.style.display = header.style.display || 'flex';
        header.style.alignItems = header.style.alignItems || 'center';
        header.style.justifyContent = header.style.justifyContent || 'space-between';
        header.appendChild(btn);

        function setExpanded(expanded) {
            card.classList.toggle('bdp-vars-final-open', expanded);
            card.classList.toggle('bdp-vars-final-closed', !expanded);
            card.classList.remove('bdp-variations-open', 'bdp-variations-closed', 'bdp-is-collapsed', 'bdp-is-expanded');
            card.dataset.variationsExpanded = expanded ? '1' : '0';
            btn.textContent = expanded ? 'Hide variations' : 'Show variations';
            btn.setAttribute('aria-expanded', expanded ? 'true' : 'false');

            // Hard override for all body children so old CSS/scripts cannot keep them hidden.
            Array.from(card.children).forEach(function (child, index) {
                if (index === 0) return;
                child.style.display = expanded ? '' : 'none';
                child.hidden = !expanded;
            });
        }

        // Always collapsed by default on first load.
        setExpanded(false);

        btn.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            setExpanded(card.dataset.variationsExpanded !== '1');
        }, true);

        // Top sticky tab should open the section.
        document.querySelectorAll('a[href="#variations"], button[data-target="#variations"], [data-scroll-target="variations"], [data-bdp-tab="variations"]').forEach(function (tab) {
            tab.addEventListener('click', function () {
                setExpanded(true);
                setTimeout(function () { card.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 50);
            }, true);
        });
    });
})();
</script>
<!-- /BDP_VARIATIONS_TOGGLE_CLEAN_FINAL -->
<!-- BDP_AI_UI_POLISH_START -->
<style>
    /* AI box button polish */
    #bdp-build-ai-prompt,
    #bdp-copy-ai-prompt,
    #bdp-apply-ai-output,
    #bdp-clear-ai-box,
    .bdp-ai-tools .bdp-btn,
    .bdp-ai-tools button,
    .bdp-ai-panel .bdp-btn,
    .bdp-ai-panel button {
        transition: background-color .16s ease, border-color .16s ease, color .16s ease, transform .16s ease, box-shadow .16s ease;
    }

    #bdp-build-ai-prompt:hover,
    #bdp-copy-ai-prompt:hover,
    .bdp-ai-tools .bdp-btn.light:hover,
    .bdp-ai-panel .bdp-btn.light:hover {
        background:#0f172a !important;
        border-color:#0f172a !important;
        color:#fff !important;
        transform:translateY(-1px);
        box-shadow:0 8px 18px rgba(15,23,42,.12);
    }

    #bdp-apply-ai-output:hover,
    .bdp-ai-tools .bdp-btn.orange:hover,
    .bdp-ai-panel .bdp-btn.orange:hover {
        background:#e8580c !important;
        border-color:#e8580c !important;
        color:#fff !important;
        transform:translateY(-1px);
        box-shadow:0 8px 18px rgba(255,107,26,.22);
    }

    #bdp-clear-ai-box:hover {
        background:#fee2e2 !important;
        border-color:#fecaca !important;
        color:#991b1b !important;
    }

    .bdp-ai-copied-state {
        background:#16a34a !important;
        border-color:#16a34a !important;
        color:#fff !important;
    }
</style>

<!-- BDP_AI_UI_POLISH_END -->


<!-- BDP_AI_TOOLS_CLEANUP_START -->
<style>
    /* AI tool button polish */
    #bdp-build-ai-prompt,
    #bdp-copy-ai-prompt,
    .bdp-build-ai-prompt,
    .bdp-copy-ai-prompt,
    button[data-bdp-ai-action="build"],
    button[data-bdp-ai-action="copy"] {
        transition: all .18s ease;
        cursor: pointer;
    }
    #bdp-build-ai-prompt:hover,
    .bdp-build-ai-prompt:hover,
    button[data-bdp-ai-action="build"]:hover {
        background: #0f172a !important;
        color: #ffffff !important;
        border-color: #0f172a !important;
        transform: translateY(-1px);
    }
    #bdp-copy-ai-prompt:hover,
    .bdp-copy-ai-prompt:hover,
    button[data-bdp-ai-action="copy"]:hover {
        background: #2563eb !important;
        color: #ffffff !important;
        border-color: #2563eb !important;
        transform: translateY(-1px);
    }
    #bdp-build-ai-prompt:active,
    #bdp-copy-ai-prompt:active,
    .bdp-build-ai-prompt:active,
    .bdp-copy-ai-prompt:active {
        transform: translateY(0) scale(.99);
    }
    .bdp-ai-generated-prompt-hidden {
        display: none !important;
    }
</style>

<!-- BDP_AI_TOOLS_CLEANUP_END -->


<!-- BDP_AI_BUILD_COPY_FIX_START -->
<style>
    .bdp-ai-tools button,
    .bdp-ai-panel button,
    aside button[id*="ai"],
    aside button[id*="prompt"],
    button[id*="bdp-build-ai"],
    button[id*="bdp-copy-ai"],
    button[id*="bdp-apply-ai"]{
        transition:all .18s ease!important;
    }
    .bdp-ai-tools button:hover,
    .bdp-ai-panel button:hover,
    aside button[id*="ai"]:hover,
    aside button[id*="prompt"]:hover,
    button[id*="bdp-build-ai"]:hover,
    button[id*="bdp-copy-ai"]:hover{
        background:#0f172a!important;
        border-color:#0f172a!important;
        color:#fff!important;
        transform:translateY(-1px);
    }
    button[id*="bdp-apply-ai"]:hover{
        background:#e84d13!important;
        border-color:#e84d13!important;
        color:#fff!important;
        transform:translateY(-1px);
    }
    .bdp-ai-prompt-wrap{display:none;margin-top:10px}
    .bdp-ai-prompt-wrap textarea{width:100%;min-height:140px;border:1px solid #d8e0ec;border-radius:10px;padding:10px;font-size:12px;line-height:1.45;background:#fff}
</style>

<!-- BDP_AI_BUILD_COPY_FIX_END -->


<!-- BDP_AI_PROMPT_SHOW_COPY_FIX_JS_START -->

<!-- BDP_AI_PROMPT_SHOW_COPY_FIX_JS_END -->


<!-- BDP_AI_EDIT_CLEAN_FINAL_START -->


<!-- BDP_AI_EDIT_CLEAN_FINAL_END -->



<style>
    .bdp-ai-generated-prompt-wrap{display:none;margin-top:10px}
    .bdp-ai-generated-prompt-wrap textarea{width:100%;min-height:160px;border:1px solid #dbe3ef;border-radius:12px;padding:12px;font-size:12px;line-height:1.55;background:#fff;color:#0f172a}
    .bdp-ai-tools-card .bdp-ai-hidden-setting{display:none!important}
    .bdp-ai-safe-btn{transition:all .16s ease!important;cursor:pointer!important}
    .bdp-ai-safe-btn:hover{background:#0f172a!important;color:#fff!important;border-color:#0f172a!important;transform:translateY(-1px)}
    .bdp-ai-safe-btn:active{transform:translateY(0);opacity:.88}
</style>
<script>
(function(){
    'use strict';

    function text(el){ return (el && (el.innerText || el.textContent) || '').trim(); }
    function byText(selector, needle){
        needle = String(needle).toLowerCase();
        return Array.from(document.querySelectorAll(selector)).find(function(el){ return text(el).toLowerCase().includes(needle); });
    }
    function closestCard(el){
        return el ? (el.closest('.bdp-card, aside, .bdp-edit-side, .bdp-ai-tools-card, .card, .widget, .box') || el.parentElement) : null;
    }
    function getValue(names){
        for (var i=0;i<names.length;i++) {
            var el = document.querySelector('[name="'+names[i]+'"], #'+names[i]);
            if (el && typeof el.value !== 'undefined' && String(el.value).trim()) return String(el.value).trim();
        }
        return '';
    }
    function getEditorValue(names){
        for (var i=0;i<names.length;i++) {
            var el = document.querySelector('[name="'+names[i]+'"], #'+names[i]);
            if (!el) continue;
            if (window.tinymce && el.id && tinymce.get(el.id)) {
                var v = tinymce.get(el.id).getContent({format:'text'}).trim();
                if (v) return v;
            }
            if (typeof el.value !== 'undefined' && String(el.value).trim()) return String(el.value).trim();
            if (el.innerText && el.innerText.trim()) return el.innerText.trim();
        }
        return '';
    }
    function getSetting(id, fallback){
        var el = document.getElementById(id);
        return el && el.value ? el.value : fallback;
    }
    function getBuyerIntent(card){
        var select = card ? Array.from(card.querySelectorAll('select')).find(function(s){
            var label = text(s.closest('label') || s.parentElement).toLowerCase();
            return label.includes('buyer') || Array.from(s.options || []).some(function(o){ return /everyday|party|office|casual|travel|summer|dressy/i.test(o.value || o.text); });
        }) : null;
        return select && select.value ? select.value : getSetting('bdp-ai-default-buyer-intent', 'Everyday wear');
    }
    function buildPrompt(card){
        var title = getValue(['title','name','product_title']) || 'Product title not provided';
        var sku = getValue(['sku']);
        var slug = getValue(['slug','url_slug']);
        var categories = getValue(['categories','category']);
        var tags = getValue(['tags','tag']);
        var shortDesc = getEditorValue(['short_description','description']);
        var longDesc = getEditorValue(['content','long_description']);
        var buyerIntent = getBuyerIntent(card);
        var shortWords = getSetting('bdp-ai-short-words', '40-60');
        var longWords = getSetting('bdp-ai-long-words', '180-230');
        var metaChars = getSetting('bdp-ai-meta-chars', '150-160');
        var tagsCount = getSetting('bdp-ai-tags-count', '6');

        return [
            'Act as a senior ecommerce SEO strategist, product content writer, and conversion optimization expert.',
            '',
            'Rewrite and optimize this product listing for Google SEO, buyer intent, and conversion.',
            '',
            'Important rules:',
            '- Use only the product facts provided.',
            '- Do not invent materials, comfort claims, medical claims, waterproof claims, warranty claims, shipping promises, or brand claims.',
            '- Do not mention supplier names, CJ, CJDropshipping, AliExpress, Alibaba, warehouse, factory, source product ID, or supplier SKU prefixes.',
            '- Do not expose supplier SKU prefixes in public slugs.',
            '- Use American English.',
            '- Target market: USA.',
            '- Buyer intent: '+ buyerIntent +'.',
            '- Write for real ecommerce buyers first, SEO second.',
            '- Avoid keyword stuffing.',
            '',
            'Slug rule:',
            '- If SKU contains CJ/CJNS prefix, remove the public prefix and use b + number at the end of slug.',
            '- Example CJNS1274506 becomes b1274506.',
            '',
            'Length rules:',
            '- Short description: '+ shortWords +' words.',
            '- Long description: '+ longWords +' words.',
            '- Meta description: '+ metaChars +' characters.',
            '- Tags count: '+ tagsCount +'.',
            '',
            'Product data:',
            'Title: '+ title,
            'SKU: '+ sku,
            'Current slug: '+ slug,
            'Categories: '+ categories,
            'Tags: '+ tags,
            'Short description: '+ shortDesc,
            'Long description/content: '+ longDesc,
            '',
            'Return only valid JSON with this exact structure:',
            '{',
            '  "title": "",',
            '  "slug": "",',
            '  "short_description": "",',
            '  "long_description": "",',
            '  "focus_keyword": "",',
            '  "seo_title": "",',
            '  "seo_description": "",',
            '  "tags": []',
            '}'
        ].join('\n');
    }
    function findAiCard(){
        var heading = Array.from(document.querySelectorAll('h1,h2,h3,h4,strong,.bdp-card-title')).find(function(el){ return text(el).toLowerCase().includes('ai seo tools'); });
        return closestCard(heading) || document.querySelector('.bdp-edit-side, aside') || document;
    }
    function ensurePromptBox(card){
        var box = document.getElementById('bdp-ai-generated-prompt');
        if (box) return box;
        var copyBtn = byText('button,a', 'Copy Prompt') || byText('button,a', 'Copied');
        var wrap = document.createElement('div');
        wrap.className = 'bdp-ai-generated-prompt-wrap';
        wrap.innerHTML = '<label style="display:block;margin:10px 0 6px;font-weight:800;color:#334155">Generated prompt</label><textarea id="bdp-ai-generated-prompt" readonly></textarea>';
        if (copyBtn && copyBtn.parentNode) copyBtn.parentNode.insertBefore(wrap, copyBtn.nextSibling);
        else (card || document.body).appendChild(wrap);
        return wrap.querySelector('textarea');
    }
    function hidePromptSettings(card){
        if (!card) return;
        Array.from(card.querySelectorAll('label,small,span,div')).forEach(function(el){
            var t = text(el).toLowerCase();
            if (['short description words','long description words','meta description chars','tags count','prompt settings'].some(function(k){ return t === k || t.includes(k); })) {
                var row = el.closest('.bdp-form-grid, .bdp-grid, .form-grid, .row, .bdp-ai-settings, .bdp-setting-row, div');
                if (row && !t.includes('buyer intent')) row.classList.add('bdp-ai-hidden-setting');
            }
        });
    }
    function init(){
        var card = findAiCard();
        hidePromptSettings(card);
        var promptBox = ensurePromptBox(card);
        var promptWrap = promptBox.closest('.bdp-ai-generated-prompt-wrap') || promptBox.parentElement;
        if (promptWrap) promptWrap.style.display = 'none';

        var buildBtn = byText('button,a', 'Build AI Prompt') || document.getElementById('bdp-build-ai-prompt');
        var copyBtn = byText('button,a', 'Copy Prompt') || byText('button,a', 'Copied') || document.getElementById('bdp-copy-ai-prompt');
        [buildBtn, copyBtn].forEach(function(btn){ if(btn) btn.classList.add('bdp-ai-safe-btn'); });

        if (buildBtn) {
            buildBtn.addEventListener('click', function(e){
                e.preventDefault();
                e.stopImmediatePropagation();
                promptBox.value = buildPrompt(card);
                if (promptWrap) promptWrap.style.display = 'block';
                if (copyBtn) copyBtn.textContent = 'Copy Prompt';
                return false;
            }, true);
        }
        if (copyBtn) {
            copyBtn.addEventListener('click', function(e){
                e.preventDefault();
                e.stopImmediatePropagation();
                if (!promptBox.value.trim()) promptBox.value = buildPrompt(card);
                function done(){
                    if (promptWrap) promptWrap.style.display = 'none';
                    copyBtn.textContent = 'Copied';
                    setTimeout(function(){ copyBtn.textContent = 'Copy Prompt'; }, 1300);
                }
                if (navigator.clipboard && window.isSecureContext) {
                    navigator.clipboard.writeText(promptBox.value).then(done).catch(function(){ promptBox.select(); document.execCommand('copy'); done(); });
                } else {
                    promptBox.style.display = 'block';
                    promptBox.select();
                    document.execCommand('copy');
                    done();
                }
                return false;
            }, true);
        }
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();
</script>



<!-- BDP_LONG_DESCRIPTION_AI_FIX_START -->
<script>
(function () {
    'use strict';

    function bdpText(el) {
        return (el && (el.innerText || el.textContent || '') || '').trim();
    }

    function bdpFindButtonByText(text) {
        text = String(text || '').toLowerCase();
        return Array.from(document.querySelectorAll('button, a, input[type="button"], input[type="submit"]')).find(function (el) {
            var label = (el.value || bdpText(el)).toLowerCase();
            return label.indexOf(text) !== -1;
        });
    }

    function bdpFindAiJsonBox() {
        var selectors = [
            '#bdp-ai-json-output',
            '#bdp-ai-output-json',
            '#bdp-ai-result',
            'textarea[name="ai_json"]',
            'textarea[name="ai_output"]',
            'textarea[id*="json" i]',
            'textarea[name*="json" i]'
        ];

        for (var i = 0; i < selectors.length; i++) {
            var found = document.querySelector(selectors[i]);
            if (found) return found;
        }

        return Array.from(document.querySelectorAll('textarea')).find(function (textarea) {
            var ph = (textarea.getAttribute('placeholder') || '').toLowerCase();
            var label = '';
            var parent = textarea.closest('div, section, aside, .bdp-card');
            if (parent) label = bdpText(parent).toLowerCase();
            return ph.indexOf('json') !== -1 || label.indexOf('paste ai json') !== -1 || label.indexOf('json output') !== -1;
        }) || null;
    }

    function bdpGetAiLongDescription() {
        var box = bdpFindAiJsonBox();
        if (!box || !box.value.trim()) return '';

        try {
            var data = JSON.parse(box.value.trim());
            return data.long_description || data.content || data.description_long || data.full_description || data.product_content || '';
        } catch (e) {
            console.warn('BDP: Cannot parse AI JSON for long description.', e);
            return '';
        }
    }

    function bdpSetTextareaValue(field, value) {
        if (!field) return false;
        field.value = value;
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
    }

    function bdpSetTinyMce(field, value) {
        if (!window.tinymce || !field) return false;
        var updated = false;

        if (field.id && window.tinymce.get(field.id)) {
            window.tinymce.get(field.id).setContent(value || '');
            window.tinymce.get(field.id).save();
            updated = true;
        }

        try {
            (window.tinymce.editors || []).forEach(function (editor) {
                if (editor && editor.targetElm === field) {
                    editor.setContent(value || '');
                    editor.save();
                    updated = true;
                }
            });
        } catch (e) {}

        return updated;
    }

    function bdpSetCkEditor(field, value) {
        if (!window.CKEDITOR || !field) return false;
        var updated = false;

        Object.keys(window.CKEDITOR.instances || {}).forEach(function (key) {
            var instance = window.CKEDITOR.instances[key];
            if (instance && instance.element && instance.element.$ === field) {
                instance.setData(value || '');
                instance.updateElement();
                updated = true;
            }
        });

        return updated;
    }

    function bdpSetQuillLikeLongEditor(value) {
        var updated = false;

        // In this Data Pilot screen there are usually two rich editors:
        // editor #1 = short description, editor #2 = long description/content.
        var editors = Array.from(document.querySelectorAll('.ql-editor, [contenteditable="true"]')).filter(function (el) {
            return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
        });

        var longEditor = null;

        // Prefer an editor inside/near a section that mentions long description or product content.
        editors.forEach(function (editor) {
            if (longEditor) return;
            var card = editor.closest('.bdp-card, .bdp-editor-card, .form-group, .mb-3, div');
            var text = card ? bdpText(card).toLowerCase() : '';
            if (text.indexOf('long description') !== -1 || text.indexOf('product content') !== -1 || text.indexOf('content') !== -1) {
                longEditor = editor;
            }
        });

        // Fallback: second editor is usually long description.
        if (!longEditor && editors.length > 1) {
            longEditor = editors[1];
        }

        if (longEditor) {
            longEditor.innerHTML = value || '';
            longEditor.dispatchEvent(new Event('input', { bubbles: true }));
            longEditor.dispatchEvent(new Event('change', { bubbles: true }));
            updated = true;
        }

        return updated;
    }

    function bdpApplyLongDescriptionFromAi() {
        var value = bdpGetAiLongDescription();
        if (!value) return;

        var field = document.querySelector('textarea[name="content"], textarea[name="long_description"], textarea[name="product_content"], [name="content"]');

        if (field) {
            bdpSetTextareaValue(field, value);
            bdpSetTinyMce(field, value);
            bdpSetCkEditor(field, value);
        }

        bdpSetQuillLikeLongEditor(value);
    }

    function bdpSyncLongEditorToTextareaBeforeSubmit() {
        var field = document.querySelector('textarea[name="content"], textarea[name="long_description"], textarea[name="product_content"], [name="content"]');
        if (!field) return;

        // If a visible Quill/editor exists for long description, copy its HTML back into the real textarea before save.
        var editors = Array.from(document.querySelectorAll('.ql-editor, [contenteditable="true"]')).filter(function (el) {
            return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
        });
        var longEditor = editors.length > 1 ? editors[1] : null;

        if (longEditor && longEditor.innerHTML.trim()) {
            bdpSetTextareaValue(field, longEditor.innerHTML.trim());
        }

        bdpSetTinyMce(field, field.value);
        bdpSetCkEditor(field, field.value);
    }

    document.addEventListener('click', function (event) {
        var btn = event.target.closest('button, a, input[type="button"], input[type="submit"]');
        if (!btn) return;

        var label = (btn.value || bdpText(btn)).toLowerCase();

        if (label.indexOf('apply ai output') !== -1 || label.indexOf('apply output') !== -1) {
            setTimeout(bdpApplyLongDescriptionFromAi, 80);
            setTimeout(bdpApplyLongDescriptionFromAi, 350);
        }

        if (label.indexOf('save product') !== -1 || label.indexOf('sync as draft') !== -1 || label.indexOf('sync to') !== -1) {
            bdpSyncLongEditorToTextareaBeforeSubmit();
        }
    }, true);

    document.addEventListener('submit', function () {
        bdpSyncLongEditorToTextareaBeforeSubmit();
    }, true);

    window.bdpApplyLongDescriptionFromAi = bdpApplyLongDescriptionFromAi;
})();
</script>
<!-- BDP_LONG_DESCRIPTION_AI_FIX_END -->


<!-- BDP_SYNC_CLOSE_JS_START -->
<script>
(function () {
    function normalizeText(el) {
        return (el && (el.innerText || el.value || el.textContent) || '').toLowerCase().trim();
    }

    document.addEventListener('click', function (event) {
        var btn = event.target.closest('button, input[type="submit"], a');
        if (!btn) return;

        var text = normalizeText(btn);
        var redirect = document.getElementById('bdp-redirect-after-sync');
        if (!redirect) return;

        // Only redirect when the user clicks the sync button, not normal Save Product.
        if (text.indexOf('sync') !== -1) {
            redirect.value = '1';
        } else {
            redirect.value = '0';
        }
    }, true);
})();
</script>
<!-- BDP_SYNC_CLOSE_JS_END -->

<?php $__env->stopSection(); ?>


<script>
(function () {
    function initBdpTinyMce() {
        if (!window.tinymce) return;
        const fields = document.querySelectorAll('textarea.bdp-rich-editor');
        if (!fields.length) return;

        tinymce.init({
            selector: 'textarea.bdp-rich-editor',
            height: 420,
            menubar: false,
            branding: false,
            promotion: false,
            convert_urls: false,
            entity_encoding: 'raw',
            plugins: 'advlist autolink lists link image charmap preview anchor searchreplace visualblocks code fullscreen insertdatetime media table help wordcount autoresize',
            toolbar: 'undo redo | blocks | bold italic underline | bullist numlist | alignleft aligncenter alignright | link image table | removeformat | code fullscreen',
            block_formats: 'Paragraph=p; Heading 2=h2; Heading 3=h3; Heading 4=h4',
            toolbar_mode: 'sliding',
            content_style: 'body{font-family:Inter,Arial,sans-serif;font-size:14px;line-height:1.65;color:#0f172a;} h2,h3,h4{line-height:1.25;margin:1em 0 .5em;} p{margin:0 0 .85em;} ul,ol{padding-left:1.35rem;} table{border-collapse:collapse;width:100%;} td,th{border:1px solid #e5e7eb;padding:8px;} img{max-width:100%;height:auto;}',
            images_upload_handler: function (blobInfo, progress) {
                return new Promise(function (resolve, reject) {
                    // Keep image uploads as URL-based for now. This prevents accidental local media uploads from Data Pilot.
                    reject('Please use image URLs or upload final gallery images in Balenco/Shofy media manager.');
                });
            },
            setup: function (editor) {
                editor.on('change keyup undo redo', function () {
                    editor.save();
                    const textarea = document.getElementById(editor.id);
                    if (textarea) textarea.dispatchEvent(new Event('input', { bubbles: true }));
                });
            }
        });

        document.querySelectorAll('form').forEach(function (form) {
            form.addEventListener('submit', function () {
                if (window.tinymce) window.tinymce.triggerSave();
            });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initBdpTinyMce);
    } else {
        initBdpTinyMce();
    }
})();
</script>




<!-- BDP_AI_PROMPT_SHOW_COPY_FIX_CSS_START -->
<style>
    .bdp-ai-generated-prompt-wrap,
    .bdp-ai-prompt-wrap {
        display: none;
        margin-top: 10px;
    }

    .bdp-ai-generated-prompt-wrap textarea,
    .bdp-ai-prompt-wrap textarea,
    #bdp-ai-generated-prompt {
        min-height: 180px;
        font-size: 12px;
        line-height: 1.5;
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
    }

    #bdp-build-ai-prompt,
    #bdp-copy-ai-prompt,
    .bdp-ai-btn {
        transition: all .16s ease;
        cursor: pointer;
    }

    #bdp-build-ai-prompt:hover,
    #bdp-copy-ai-prompt:hover,
    .bdp-ai-btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 8px 18px rgba(15, 23, 42, .10);
    }

    #bdp-build-ai-prompt:active,
    #bdp-copy-ai-prompt:active,
    .bdp-ai-btn:active {
        transform: translateY(0);
        box-shadow: none;
    }

    #bdp-build-ai-prompt.bdp-ai-copied,
    #bdp-copy-ai-prompt.bdp-ai-copied {
        background: #16a34a !important;
        border-color: #16a34a !important;
        color: #fff !important;
    }
</style>
<!-- BDP_AI_PROMPT_SHOW_COPY_FIX_CSS_END -->

<?php echo $__env->make('balenco-data-pilot.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/1556810.cloudwaysapps.com/rgxpgjudaw/public_html/resources/views/balenco-data-pilot/edit.blade.php ENDPATH**/ ?>