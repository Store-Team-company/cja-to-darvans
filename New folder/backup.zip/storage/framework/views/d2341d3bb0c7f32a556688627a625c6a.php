<?php $__env->startSection('content'); ?>
<style>
.bdp-sync-page {
    max-width: 1320px;
    margin: 0 auto;
    padding: 8px 0 40px;
}
.bdp-sync-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 18px;
    margin-bottom: 18px;
}
.bdp-sync-title h1 {
    margin: 0 0 6px;
    font-size: 28px;
    line-height: 1.15;
    color: #0f172a;
    font-weight: 900;
    letter-spacing: -0.03em;
}
.bdp-sync-title p {
    margin: 0;
    color: #64748b;
    font-size: 14px;
}
.bdp-sync-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    height: 40px;
    padding: 0 15px;
    border-radius: 10px;
    border: 1px solid #e2e8f0;
    background: #fff;
    color: #0f172a;
    font-size: 13px;
    font-weight: 800;
    text-decoration: none;
    cursor: pointer;
    white-space: nowrap;
}
.bdp-sync-btn:hover {
    background: #f8fafc;
}
.bdp-sync-btn.primary {
    background: #ff5b1a;
    border-color: #ff5b1a;
    color: #fff;
}
.bdp-sync-stats {
    display: grid;
    grid-template-columns: repeat(5, minmax(0, 1fr));
    gap: 14px;
    margin-bottom: 18px;
}
.bdp-sync-stat {
    display: block;
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 16px;
    padding: 15px 16px;
    text-decoration: none;
    box-shadow: 0 8px 26px rgba(15, 23, 42, .04);
}
.bdp-sync-stat span {
    display: block;
    margin-bottom: 9px;
    color: #64748b;
    font-size: 11px;
    font-weight: 900;
    letter-spacing: .06em;
    text-transform: uppercase;
}
.bdp-sync-stat strong {
    display: block;
    color: #0f172a;
    font-size: 25px;
    line-height: 1;
    font-weight: 900;
}
.bdp-sync-stat.active {
    border-color: #ff5b1a;
    box-shadow: 0 12px 30px rgba(255, 91, 26, .10);
}
.bdp-sync-panel {
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 18px;
    overflow: hidden;
    box-shadow: 0 12px 36px rgba(15, 23, 42, .05);
}
.bdp-sync-filter {
    display: grid;
    grid-template-columns: 210px 1fr auto auto;
    gap: 10px;
    align-items: end;
    padding: 16px;
    border-bottom: 1px solid #edf2f7;
}
.bdp-sync-field label {
    display: block;
    margin-bottom: 6px;
    color: #475569;
    font-size: 12px;
    font-weight: 900;
}
.bdp-sync-field input,
.bdp-sync-field select {
    width: 100%;
    height: 40px;
    border: 1px solid #dbe3ef;
    border-radius: 10px;
    background: #fff;
    padding: 0 12px;
    color: #0f172a;
    font-size: 13px;
}
.bdp-sync-table-wrap {
    overflow-x: auto;
}
.bdp-sync-table {
    width: 100%;
    border-collapse: collapse;
    table-layout: fixed;
}
.bdp-sync-table th {
    background: #f8fafc;
    color: #64748b;
    font-size: 11px;
    font-weight: 900;
    text-transform: uppercase;
    letter-spacing: .04em;
    text-align: left;
    padding: 12px 12px;
    border-bottom: 1px solid #e5e7eb;
}
.bdp-sync-table td {
    padding: 12px;
    border-bottom: 1px solid #edf2f7;
    vertical-align: top;
    font-size: 13px;
    color: #0f172a;
}
.bdp-sync-table tr:hover td {
    background: #fbfdff;
}
.bdp-col-product { width: 28%; }
.bdp-col-sku { width: 12%; }
.bdp-col-status { width: 10%; }
.bdp-col-attempts { width: 8%; }
.bdp-col-date { width: 11%; }
.bdp-col-note { width: 20%; }
.bdp-product-name {
    margin-bottom: 4px;
    color: #0f172a;
    font-weight: 900;
    line-height: 1.3;
}
.bdp-muted {
    color: #64748b;
    font-size: 12px;
    line-height: 1.35;
}
.bdp-status {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 74px;
    height: 24px;
    border-radius: 999px;
    font-size: 10px;
    font-weight: 900;
    text-transform: uppercase;
    letter-spacing: .03em;
}
.bdp-status.queued { background: #eff6ff; color: #1d4ed8; }
.bdp-status.processing { background: #fff7ed; color: #c2410c; }
.bdp-status.synced { background: #dcfce7; color: #166534; }
.bdp-status.failed { background: #fee2e2; color: #b91c1c; }
.bdp-note {
    max-width: 100%;
    color: #64748b;
    font-size: 12px;
    line-height: 1.45;
    word-break: break-word;
}
.bdp-note.error {
    color: #b91c1c;
}
.bdp-sync-empty {
    padding: 36px;
    text-align: center;
    color: #64748b;
}
.bdp-sync-pagination {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 14px;
    padding: 14px 16px;
    background: #fff;
}
.bdp-sync-pagination-info {
    color: #64748b;
    font-size: 12px;
}
.bdp-sync-pages {
    display: flex;
    align-items: center;
    gap: 6px;
    flex-wrap: wrap;
    justify-content: flex-end;
}
.bdp-sync-page-link,
.bdp-sync-page-current,
.bdp-sync-page-disabled {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 34px;
    height: 34px;
    padding: 0 10px;
    border-radius: 9px;
    border: 1px solid #e2e8f0;
    background: #fff;
    color: #0f172a;
    font-size: 12px;
    font-weight: 800;
    text-decoration: none;
}
.bdp-sync-page-current {
    background: #0f172a;
    border-color: #0f172a;
    color: #fff;
}
.bdp-sync-page-disabled {
    color: #cbd5e1;
    background: #f8fafc;
}
@media (max-width: 1100px) {
    .bdp-sync-stats { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    .bdp-sync-filter { grid-template-columns: 1fr; }
    .bdp-sync-table { min-width: 1050px; }
}
</style>

<div class="bdp-sync-page">
    <div class="bdp-sync-header">
        <div class="bdp-sync-title">
            <h1>Sync Queue</h1>
            <p>Products added here are synced by cron one by one. Variation images are copied to store.balencousa.com during sync.</p>
        </div>
        <a class="bdp-sync-btn" href="<?php echo e(route('bdp.products')); ?>">Back to Products</a>
    </div>

    <div class="bdp-sync-stats">
        <a class="bdp-sync-stat <?php echo e(($status ?? 'all') === 'all' ? 'active' : ''); ?>" href="<?php echo e(route('bdp.sync.queue.index', ['status' => 'all'])); ?>">
            <span>All</span>
            <strong><?php echo e($counts['all'] ?? 0); ?></strong>
        </a>
        <a class="bdp-sync-stat <?php echo e(($status ?? '') === 'queued' ? 'active' : ''); ?>" href="<?php echo e(route('bdp.sync.queue.index', ['status' => 'queued'])); ?>">
            <span>Queued</span>
            <strong><?php echo e($counts['queued'] ?? 0); ?></strong>
        </a>
        <a class="bdp-sync-stat <?php echo e(($status ?? '') === 'processing' ? 'active' : ''); ?>" href="<?php echo e(route('bdp.sync.queue.index', ['status' => 'processing'])); ?>">
            <span>Processing</span>
            <strong><?php echo e($counts['processing'] ?? 0); ?></strong>
        </a>
        <a class="bdp-sync-stat <?php echo e(($status ?? '') === 'synced' ? 'active' : ''); ?>" href="<?php echo e(route('bdp.sync.queue.index', ['status' => 'synced'])); ?>">
            <span>Synced</span>
            <strong><?php echo e($counts['synced'] ?? 0); ?></strong>
        </a>
        <a class="bdp-sync-stat <?php echo e(($status ?? '') === 'failed' ? 'active' : ''); ?>" href="<?php echo e(route('bdp.sync.queue.index', ['status' => 'failed'])); ?>">
            <span>Failed</span>
            <strong><?php echo e($counts['failed'] ?? 0); ?></strong>
        </a>
    </div>

    <div class="bdp-sync-panel">
        <form method="get" action="<?php echo e(route('bdp.sync.queue.index')); ?>" class="bdp-sync-filter">
            <div class="bdp-sync-field">
                <label>Status</label>
                <select name="status">
                    <option value="all" <?php if(($status ?? 'all') === 'all'): echo 'selected'; endif; ?>>All</option>
                    <option value="queued" <?php if(($status ?? '') === 'queued'): echo 'selected'; endif; ?>>Queued</option>
                    <option value="processing" <?php if(($status ?? '') === 'processing'): echo 'selected'; endif; ?>>Processing</option>
                    <option value="synced" <?php if(($status ?? '') === 'synced'): echo 'selected'; endif; ?>>Synced</option>
                    <option value="failed" <?php if(($status ?? '') === 'failed'): echo 'selected'; endif; ?>>Failed</option>
                </select>
            </div>
            <div class="bdp-sync-field">
                <label>Search</label>
                <input type="text" name="search" value="<?php echo e($search ?? ''); ?>" placeholder="Product title, SKU, or Data Pilot ID">
            </div>
            <button class="bdp-sync-btn primary" type="submit">Filter</button>
            <a class="bdp-sync-btn" href="<?php echo e(route('bdp.sync.queue.index')); ?>">Reset</a>
        </form>

        <div class="bdp-sync-table-wrap">
            <table class="bdp-sync-table">
                <thead>
                    <tr>
                        <th class="bdp-col-product">Product</th>
                        <th class="bdp-col-sku">SKU</th>
                        <th class="bdp-col-status">Status</th>
                        <th class="bdp-col-attempts">Attempts</th>
                        <th class="bdp-col-date">Queued</th>
                        <th class="bdp-col-date">Started</th>
                        <th class="bdp-col-date">Synced</th>
                        <th class="bdp-col-note">Last Error / Note</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <div class="bdp-product-name"><?php echo e($item->product_name ?: 'Product #' . $item->product_id); ?></div>
                                <div class="bdp-muted">
                                    Data Pilot ID: <?php echo e($item->product_id); ?>

                                    <?php if($item->shofy_product_id): ?>
                                        · Shofy ID: <?php echo e($item->shofy_product_id); ?>

                                    <?php endif; ?>
                                </div>
                            </td>
                            <td><?php echo e($item->sku ?: '—'); ?></td>
                            <td><span class="bdp-status <?php echo e($item->status); ?>"><?php echo e($item->status); ?></span></td>
                            <td><?php echo e($item->attempts); ?></td>
                            <td><span class="bdp-muted"><?php echo e($item->queued_at ?: '—'); ?></span></td>
                            <td><span class="bdp-muted"><?php echo e($item->started_at ?: '—'); ?></span></td>
                            <td><span class="bdp-muted"><?php echo e($item->synced_at ?: '—'); ?></span></td>
                            <td>
                                <?php if($item->last_error): ?>
                                    <div class="bdp-note error"><?php echo e(\Illuminate\Support\Str::limit((string) $item->last_error, 220)); ?></div>
                                <?php else: ?>
                                    <div class="bdp-note"><?php echo e(\Illuminate\Support\Str::limit((string) $item->shofy_push_note, 180) ?: '—'); ?></div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8">
                                <div class="bdp-sync-empty">No queue items found.</div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($items->hasPages()): ?>
            <div class="bdp-sync-pagination">
                <div class="bdp-sync-pagination-info">
                    Showing <?php echo e($items->firstItem()); ?> to <?php echo e($items->lastItem()); ?> of <?php echo e($items->total()); ?> results
                </div>

                <div class="bdp-sync-pages">
                    <?php if($items->onFirstPage()): ?>
                        <span class="bdp-sync-page-disabled">Previous</span>
                    <?php else: ?>
                        <a class="bdp-sync-page-link" href="<?php echo e($items->previousPageUrl()); ?>">Previous</a>
                    <?php endif; ?>

                    <?php
                        $current = $items->currentPage();
                        $last = $items->lastPage();
                        $start = max(1, $current - 2);
                        $end = min($last, $current + 2);
                    ?>

                    <?php if($start > 1): ?>
                        <a class="bdp-sync-page-link" href="<?php echo e($items->url(1)); ?>">1</a>
                        <?php if($start > 2): ?>
                            <span class="bdp-sync-page-disabled">...</span>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php for($page = $start; $page <= $end; $page++): ?>
                        <?php if($page === $current): ?>
                            <span class="bdp-sync-page-current"><?php echo e($page); ?></span>
                        <?php else: ?>
                            <a class="bdp-sync-page-link" href="<?php echo e($items->url($page)); ?>"><?php echo e($page); ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>

                    <?php if($end < $last): ?>
                        <?php if($end < $last - 1): ?>
                            <span class="bdp-sync-page-disabled">...</span>
                        <?php endif; ?>
                        <a class="bdp-sync-page-link" href="<?php echo e($items->url($last)); ?>"><?php echo e($last); ?></a>
                    <?php endif; ?>

                    <?php if($items->hasMorePages()): ?>
                        <a class="bdp-sync-page-link" href="<?php echo e($items->nextPageUrl()); ?>">Next</a>
                    <?php else: ?>
                        <span class="bdp-sync-page-disabled">Next</span>
                    <?php endif; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="bdp-sync-pagination">
                <div class="bdp-sync-pagination-info">
                    Showing <?php echo e($items->count()); ?> result<?php echo e($items->count() === 1 ? '' : 's'); ?>

                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('balenco-data-pilot.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/1556810.cloudwaysapps.com/rgxpgjudaw/public_html/resources/views/balenco-data-pilot/sync-queue.blade.php ENDPATH**/ ?>