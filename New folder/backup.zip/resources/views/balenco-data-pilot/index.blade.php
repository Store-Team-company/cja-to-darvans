@extends('balenco-data-pilot.layout')

@section('content')
<div class="card">
    <h2>Products</h2>
    <p>Select products, then either export a CSV or sync them directly into Balenco. Direct Sync bypasses Shofy CSV variation import problems.</p>
    <p style="background:#fff7ed;border:1px solid #fed7aa;padding:10px;border-radius:10px"><strong>Image rule:</strong> parent product images/gallery are not pushed automatically. Upload your final optimized 5–6 product images manually in Balenco. Variation images are copied into Balenco/Shofy storage when possible and reused by color across all sizes.</p>
    <div class="grid" style="margin:12px 0">
        <div>
            <label>Live sync status</label>
            <select form="bdp-products-form" name="sync_status">
                <option value="draft" selected>Sync as Draft - safest for live site</option>
                <option value="published">Sync as Published</option>
            </select>
            <small>Recommended: sync as Draft, upload parent/gallery images manually, review, then publish.</small>
        </div>
        <div>
            <label>Variation image mode</label>
            <label style="display:block;margin-top:8px">
                <input form="bdp-products-form" type="checkbox" name="copy_variation_images" value="1" checked>
                Copy CJ variation images into Balenco storage before sync
            </label>
            <small>Parent/gallery images are still manual. Variation images are copied once per color and reused across sizes.</small>
        </div>
    </div>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
        <button class="btn orange" type="submit" form="bdp-products-form" formaction="{{ route('bdp.push') }}" formmethod="post">Sync Selected to Balenco</button>
        <button class="btn" type="submit" form="bdp-products-form" formaction="{{ route('bdp.export') }}" formmethod="post">Export Selected CSV</button>
        <button class="btn light" type="submit" form="bdp-products-form" formaction="{{ route('bdp.bulk.edit') }}" formmethod="post">Bulk SEO / Content Edit</button>
        <a class="btn light" href="{{ route('bdp.categories.mapping') }}">Category Mapping</a>
    </div>

    @php($tabs = [
        'all' => 'All',
        'not_synced' => 'Not Synced',
        'synced' => 'Synced to Balenco',
        'needs_review' => 'Needs Review',
        'failed' => 'Sync Failed',
    ])
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:15px">
        @foreach($tabs as $key => $label)
            <a href="{{ route('bdp.index', ['sync' => $key]) }}" class="btn {{ ($sync ?? 'all') === $key ? 'orange' : 'light' }}" style="text-decoration:none">{{ $label }} ({{ $counts[$key] ?? 0 }})</a>
        @endforeach
    </div>
</div>


<div class="card">
    <h3>Quick Bulk Category</h3>
    <p>Select products below, enter a category name, then apply it inside Data Pilot. Use Category Mapping to connect that category to the real Balenco category before syncing.</p>
    <div class="grid">
        <div>
            <label>Category name</label>
            <input form="bdp-products-form" type="text" name="category" placeholder="Heels & Pumps">
        </div>
        <div>
            <label>Mode</label>
            <select form="bdp-products-form" name="mode">
                <option value="replace">Replace categories</option>
                <option value="append">Append category</option>
            </select>
        </div>
    </div>
    <div style="margin-top:10px">
        <button class="btn light" type="submit" form="bdp-products-form" formaction="{{ route('bdp.categories.bulk.assign') }}" formmethod="post">Apply Category to Selected</button>
    </div>

</div>

<div class="card">
    <h3>Bulk Pricing Calculator</h3>
    <p>Select products below, then calculate Balenco selling price using: <strong>CJ cost + CJ shipping + your margin</strong>. This updates Data Pilot prices before syncing to Balenco.</p>
    <div class="grid">
        <div>
            <label>Destination country</label>
            <select form="bdp-products-form" name="country_code">
                <option value="US" selected>United States (US)</option>
                <option value="GB">United Kingdom (GB)</option>
                <option value="CA">Canada (CA)</option>
                <option value="AU">Australia (AU)</option>
                <option value="DE">Germany (DE)</option>
                <option value="FR">France (FR)</option>
            </select>
        </div>
        <div>
            <label>Quantity for shipping</label>
            <input form="bdp-products-form" type="number" name="quantity" value="1" min="1" max="100">
        </div>
        <div>
            <label>Margin type</label>
            <select form="bdp-products-form" name="margin_type">
                <option value="fixed" selected>Fixed amount</option>
                <option value="percent">Percentage markup</option>
            </select>
        </div>
        <div>
            <label>Margin value</label>
            <input form="bdp-products-form" type="number" name="margin_value" value="20" step="0.01" min="0">
        </div>
        <div>
            <label>Minimum selling price</label>
            <input form="bdp-products-form" type="number" name="minimum_price" value="39.99" step="0.01" min="0">
        </div>
        <div>
            <label>Retail rounding</label>
            <select form="bdp-products-form" name="round_mode">
                <option value="99" selected>Round up to .99</option>
                <option value="95">Round up to .95</option>
                <option value="00">Round up to whole dollar</option>
                <option value="none">No rounding</option>
            </select>
        </div>
    </div>
    <label style="display:block;margin-top:10px">
        <input form="bdp-products-form" type="checkbox" name="refresh_shipping" value="1" checked>
        Refresh CJ inventory + product shipping first if needed. For many products this may take time because CJ limits shipping calls.
    </label>
    <div style="margin-top:10px">
        <button class="btn orange" type="submit" form="bdp-products-form" formaction="{{ route('bdp.bulk.pricing') }}" formmethod="post">Bulk Refresh Shipping + Calculate Price</button>
    </div>
    <p><small>Recommended Balenco rule: landed cost + $20 margin, rounded to .99, minimum $39.99.</small></p>
</div>
<div class="card" id="bulk-optimization-csv-card">
    <h3>Bulk SEO / Content CSV Workflow</h3>
    <p>Export all Data Pilot parent products, optimize content in Excel/Google Sheets, then import it back before syncing to Balenco.</p>
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
        <a class="btn orange" href="{{ route('bdp.bulk.optimization.export') }}">Export Products for Bulk Optimization</a>
        <form method="post" action="{{ route('bdp.bulk.optimization.import') }}" enctype="multipart/form-data" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin:0">
            @csrf
            <input type="file" name="file" accept=".csv,.txt" required style="max-width:320px">
            <button class="btn" type="submit">Import Optimized CSV Back</button>
        </form>
    </div>
    <p><small>Safe rule: keep <strong>row_type</strong> and <strong>product_id</strong> unchanged. This CSV only updates title, SKU, slug, short description, long description, tags, meta title, meta description, and focus keyword. Status, price, categories, images, and variations stay manual.</small></p>
</div>
<form id="bdp-products-form" method="post">
    @csrf
    <div class="card">
        <table>
            <thead>
            <tr><th></th><th>Image</th><th>Product</th><th>SKU</th><th>Variations</th><th>CJ Cost</th><th>Shipping</th><th>Landed</th><th>Selling Price</th><th>Stock</th><th>Status</th><th>Balenco Sync</th><th>Actions</th></tr>
            </thead>
            <tbody>
            @forelse($products as $product)
                <tr>
                    <td><input type="checkbox" name="products[]" value="{{ $product->id }}"></td>
                    <td>@if($product->featured_image)<img class="thumb" src="{{ $product->featured_image }}">@endif</td>
                    <td>{{ $product->name }}<br><small>{{ $product->categories }}</small></td>
                    <td>{{ $product->sku }}</td>
                    <td>{{ $product->variations_count }}</td>
                    <td>
                        @php($displayCost = $product->min_variation_cost ?: $product->cost_per_item ?: $product->min_variation_price ?: $product->price)
                        {{ $displayCost !== null && $displayCost !== '' ? '$' . number_format((float) $displayCost, 2) : '-' }}
                    </td>
                    <td>
                        @if($product->cj_shipping_fee !== null)
                            ${{ number_format((float)$product->cj_shipping_fee, 2) }}
                            @if($product->cj_shipping_country)<br><small>{{ $product->cj_shipping_country }}</small>@endif
                            @if($product->cj_shipping_method)<br><small>{{ \Illuminate\Support\Str::limit($product->cj_shipping_method, 24) }}</small>@endif
                        @else
                            <small>Refresh CJ</small>
                        @endif
                    </td>
                    <td>
                        {{ $product->landed_cost !== null ? '$' . number_format((float) $product->landed_cost, 2) : '—' }}
                    </td>
                    <td>
                        {{ $product->price !== null && $product->price !== '' ? '$' . number_format((float) $product->price, 2) : '—' }}
                    </td>
                    <td>{{ $product->variations_total_quantity !== null ? number_format((int)$product->variations_total_quantity) : '-' }}</td>
                    <td>{{ $product->status }}</td>
                    <td>
                        @if($product->balenco_sync_status === 'sync_failed')
                            <span style="display:inline-block;background:#fee2e2;color:#991b1b;border-radius:999px;padding:3px 8px;font-size:12px;font-weight:700">Sync Failed</span><br>
                            <small>{{ \Illuminate\Support\Str::limit($product->balenco_sync_message ?: $product->shofy_push_note, 80) }}</small>
                        @elseif(!empty($product->shofy_product_id))
                            <span style="display:inline-block;background:#dcfce7;color:#166534;border-radius:999px;padding:3px 8px;font-size:12px;font-weight:700">{{ $product->balenco_sync_status === 'updated_in_balenco' ? 'Updated in Balenco' : 'Synced to Balenco' }}</span><br>
                            <small>ID: {{ $product->shofy_product_id }}</small><br>
                            <small>{{ optional($product->balenco_synced_at ?: $product->shofy_pushed_at)->format('Y-m-d H:i') }}</small><br>
                            @if(!is_null($product->shofy_variations_count))<small>{{ $product->shofy_variations_count }} variations synced</small>@endif
                        @else
                            <span style="display:inline-block;background:#f3f4f6;color:#374151;border-radius:999px;padding:3px 8px;font-size:12px;font-weight:700">Not Synced</span>
                        @endif
                    </td>
                    <td><a class="btn light" href="{{ route('bdp.products.edit', $product) }}">Edit</a></td>
                </tr>
            @empty
                <tr><td colspan="13">No products yet. Import products first.</td></tr>
            @endforelse
            </tbody>
        </table>
        <div style="margin-top:15px">{{ $products->links() }}</div>
    </div>
</form>
@endsection
